// Create a JavaScript constant for the JSON data
const HistoryData = {
    QAcollection: [
        {
            HistoryItemID: "1",
            State: "active",
            UserQuestion: "Who is the president of USA",
            Title: "",
            BotResponse: "answers",
            DateCreated: "2023-10-09T12:00:00",
            DateUpdated: "2023-10-09T12:00:00",
            ResponseUpvoteButton: "none",
            Notes: "Sample note 1",
            Citation: [
                {
                    "01": "url to location",
                    "02": "url to location"
                }
            ]
        },
        {
            HistoryItemID: "2",
            State: "active",
            UserQuestion: "List famous poetry books",
            Title: "",
            BotResponse: "answers",
            DateCreated: "2023-10-09T12:00:00",
            DateUpdated: "2023-10-09T12:00:00",
            ResponseUpvoteButton: "none",
            Notes: "Sample note 1",
            Citation: [
                {
                    "01": "url to location",
                    "02": "url to location"
                }
            ]
        },
        {
            HistoryItemID: "3",
            State: "active",
            UserQuestion: "List famous english novels",
            Title: "",
            BotResponse: "answers",
            DateCreated: "2023-10-09T12:00:00",
            DateUpdated: "2023-10-09T12:00:00",
            ResponseUpvoteButton: "none",
            Notes: "Sample note 1",
            Citation: [
                {
                    "01": "url to location",
                    "02": "url to location"
                }
            ]
        },
        {
            HistoryItemID: "4",
            State: "active",
            UserQuestion: "List some american food",
            Title: "",
            BotResponse: "answers",
            DateCreated: "2023-10-09T12:00:00",
            DateUpdated: "2023-10-09T12:00:00",
            ResponseUpvoteButton: "none",
            Notes: "Sample note 1",
            Citation: [
                {
                    "01": "url to location",
                    "02": "url to location"
                }
            ]
        },
        {
            HistoryItemID: "5",
            State: "active",
            UserQuestion: "List of Asian Countries",
            Title: "",
            BotResponse: "answers",
            DateCreated: "2023-10-09T12:00:00",
            DateUpdated: "2023-10-09T12:00:00",
            ResponseUpvoteButton: "none",
            Notes: "Sample note 1",
            Citation: [
                {
                    "01": "url to location",
                    "02": "url to location"
                }
            ]
        },
        {
            HistoryItemID: "6",
            State: "active",
            UserQuestion: "ISV Success Program",
            Title: "",
            BotResponse: "answers",
            DateCreated: "2023-10-09T12:00:00",
            DateUpdated: "2023-10-09T12:00:00",
            ResponseUpvoteButton: "none",
            Notes: "Sample note 1",
            Citation: [
                {
                    "01": "url to location",
                    "02": "url to location"
                }
            ]
        },
        {
            HistoryItemID: "7",
            State: "active",
            UserQuestion: "who is the president of USA",
            Title: "",
            BotResponse: "answers",
            DateCreated: "2023-10-09T12:00:00",
            DateUpdated: "2023-10-09T12:00:00",
            ResponseUpvoteButton: "none",
            Notes: "Sample note 1",
            Citation: [
                {
                    "01": "url to location",
                    "02": "url to location"
                }
            ]
        },
        {
            HistoryItemID: "8",
            State: "active",
            UserQuestion: "list of all 50 US states",
            Title: "",
            BotResponse: "answers",
            DateCreated: "2023-10-09T12:00:00",
            DateUpdated: "2023-10-09T12:00:00",
            ResponseUpvoteButton: "none",
            Notes: "Sample note 1",
            Citation: [
                {
                    "01": "url to location",
                    "02": "url to location"
                }
            ]
        },
        {
            HistoryItemID: "9",
            State: "active",
            UserQuestion: "People who went to moon",
            Title: "",
            BotResponse: "answers",
            DateCreated: "2023-10-09T12:00:00",
            DateUpdated: "2023-10-09T12:00:00",
            ResponseUpvoteButton: "none",
            Notes: "Sample note 1",
            Citation: [
                {
                    "01": "url to location",
                    "02": "url to location"
                }
            ]
        }
    ]
};

export default HistoryData;
