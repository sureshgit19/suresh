import styles from "./header.module.css";
import { Link } from "react-router-dom";
import logoicon from "../../assets/images/logoicon.svg";
import marketplace from "../../assets/images/marketplace.svg";
import newfeatureImg from "../../assets/images/headerchatImg.svg";
import NotificationsMenu from "../../components/Popup/Notifications";
import { Chip } from "primereact/chip";
import { Toolbar } from "primereact/toolbar";
import { Menu } from "primereact/menu";
import { Button } from "primereact/button";
import { useEffect, useRef, useState } from "react";
import { useMediaQuery } from "@uidotdev/usehooks";
import { MenuItem } from "primereact/menuitem";
import seismicImg from "../../assets/images/seismic.svg";
import { Tooltip } from "primereact/tooltip";
import { useSelector } from "react-redux";
import { MultiSelect } from 'primereact/multiselect';

const items: MenuItem[] = [
    {
        label: 'MARKETPLACE INTELLIGENCE HUB',
        url: "https://aka.ms/MarketplaceIntelligenceHub",
        target: "_blank",
    },
    {
        label: 'STOREFRONT TELEMETRY',
        url: "https://aka.ms/EventsTableKPI",
        target: "_blank",
    },
    {
        label: 'MDEA NOTIFICATIONS',
        url: "https://aka.ms/mdeanotifications",
        target: "_blank",
    },
    {
        separator: true
    },
    {
        label: 'Seismic',
        url: "https://aka.ms/KBC/Seismic",
        target: "_blank",
        // icon: seismicImg,
    },
    {
        label: 'Walkthrough Guide',
        url: "https://aka.ms/MarketplaceGPT/WalkthroughGuide",
        target: "_blank"
    },
    {
        label: 'Support',
        url: "https://aka.ms/MarketplaceIntelligenceHub/ProductSupport",
        target: "_blank"
    }
];

export function Header() {
    const isXsDevice = useMediaQuery("only screen and (max-width : 380px)");
    const isSmallDevice = useMediaQuery("only screen and (max-width : 768px)");
    const isMediumDevice = useMediaQuery(
        "only screen and (min-width : 769px) and (max-width : 992px)"
    );
    const isLargeDevice = useMediaQuery(
        "only screen and (min-width : 993px) and (max-width : 1200px)"
    );
    const isExtraLargeDevice = useMediaQuery(
        "only screen and (min-width : 1201px)"
    );
    const [selectedGroup, setSelectedGroup] = useState<string[]>([]);

    const menuRight = useRef<Menu>(null);
    const userGroups: string[] = useSelector((state: any) => state.user.usergroups);

    const start = (
        <div className="w-full z-2 flex bg-blue-900 justify-content-between align-items-center sm:justify-content-center p-0">

            <div className="flex flex-1 flex-row font-normal m-0 text-white align-items-center gap-2">
                <div className="flex align--items-center" onClick={() => window.location.reload()}>
                    <Link to="/" className="flex align-center gap-2 align-items-center">
                        <img src={logoicon} alt="" />
                        {!isXsDevice ? (
                            <img src={marketplace} className="h-1rem" alt="" />
                        ) : <span className="text-xl text-white font-bold">KBC</span>}
                    </Link>
                </div>
                {!isSmallDevice && (
                    <h4 className="sm:hidden md:flex font-bold m-0 text-white"> &nbsp;|&nbsp; Azure OpenAI + AI Search for Marketplace</h4>
                )}
            </div>
        </div >
    )

    const end = (
        <>
            {!isSmallDevice ? (
                <div className="xs:hidden sm:hidden md:hidden lg:flex xl:flex flex-initial gap-2 justify-content-end align-items-center">

                    <div className={styles.seismicImage + " flex-content-width-col"}>
                        <a href="https://aka.ms/KBC/Seismic" target="_blank">
                            <img src={seismicImg} alt="Seismic DocCenter" />
                        </a>
                    </div>
                    <Chip label="Walkthrough guide" onClick={() => {
                        window.open("https://aka.ms/MarketplaceGPT/WalkthroughGuide", "_blank");
                    }} className="bg-black-alpha-40 border-black-alpha-30 text-white-alpha-50 cursor-pointer text-xs border-1">

                    </Chip>
                    {/* <MultiSelect value={selectedGroup} filter={true} options={userGroups.map(x => { return { name: x, code: x } })}
                        optionLabel="name" optionValue="code" onChange={(e) => setSelectedGroup(e.value)}
                        maxSelectedLabels={3} className="w-10rem" tooltip={selectedGroup.join(", ")} tooltipOptions={{ position: "bottom" }} /> */}
                    <Chip id="grouplabel" className={`${styles.bgfield} ${styles.grouplabel} text-xs cursor-pointer`} label={userGroups?.length > 0 ? userGroups.join(", ") : "Field"}
                        data-pr-tooltip={userGroups?.length > 0 ? userGroups.join(", ") : "Field"}>
                    </Chip>
                    <Tooltip target="#grouplabel" position="bottom"></Tooltip>
                    <a href="https://aka.ms/MarketplaceIntelligenceHub/ProductSupport" target="_blank" className={styles.contactImage}>
                        <img src={newfeatureImg} alt="New content New Feature" />
                    </a>
                    <NotificationsMenu />

                </div>
            ) : (

                <div className="flex-initial sm:flex md:flex lg:hidden xl:hidden">
                    <Menu model={items} popup ref={menuRight} id="popup_menu_right" popupAlignment="right" className="" />
                    <Button icon="pi pi-bars" className="bg-blue-900 text-white active:border-white focus:border-white" onClick={(event) => menuRight?.current?.toggle(event)} aria-controls="popup_menu_right" aria-haspopup />
                </div>
            )}
        </>
    )

    return (
        <Toolbar start={start} end={end} className="w-full text-white bg-blue-900 border-transparent border-noround" />
    );
}
