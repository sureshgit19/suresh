import { useMediaQuery } from "@uidotdev/usehooks";
import styles from "./UniversalHeader.module.css";
import { NavLink } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { setUserGroup } from "../../store/reducer-slice/user.slice";
import { getUserGroup } from "../../api";
import { useEffect } from "react";

export function UniversalHeader() {
    const isSmallDevice = useMediaQuery("only screen and (max-width : 768px)");
    const isMediumDevice = useMediaQuery(
        "only screen and (min-width : 769px) and (max-width : 992px)"
    );
    const isLargeDevice = useMediaQuery(
        "only screen and (min-width : 993px) and (max-width : 1200px)"
    );
    const isExtraLargeDevice = useMediaQuery(
        "only screen and (min-width : 1201px)"
    );

    const dispatch = useDispatch();

    const getUserGroups = async () => {
        try {
            const response = await getUserGroup()
            if (response.ok) {
                const data = await response.json();
                if (Array.isArray(data)) {
                    dispatch(setUserGroup(data.length ? data : ['Field']));
                } else {
                    dispatch(setUserGroup(data.length ? data : ['Field']));
                }
            }

        } catch (error) {
            dispatch(setUserGroup(['Field']));
            console.error("Error fetching user group", error);
        }
    };

    useEffect(() => {
        getUserGroups();
    }, []);
    return (
        <>
            {!isSmallDevice && (<div className="bg-black-alpha-90 w-full z-2 xs:hidden sm:hidden md:flex lg:flex xl:flex h-3rem font-medium text-sm">
                <div className="bg-black-alpha-20 flex align-items-center justify-content-center text-white">
                    <a href="https://aka.ms/MarketplaceIntelligenceHub" target="_blank " className="text-400">
                        MARKETPLACE INTELLIGENCE HUB
                    </a>
                </div>

                <div className="bg-blue-900 flex align-items-center justify-content-center text-white">
                    <NavLink to="https://aka.ms/KnowledgeBaseChat" className="text-400">
                        KNOWLEDGE BASE CHAT
                    </NavLink>
                </div>

                <div className="bg-black-alpha-20 flex align-items-center justify-content-center text-white">
                    <a href="https://aka.ms/EventsTableKPI " target="_blank " className="text-400">
                        STOREFRONT TELEMETRY
                    </a>
                </div>
                <div className="bg-black-alpha-20 flex align-items-center justify-content-center text-white">
                    <a href="https://aka.ms/mdeanotifications" target="_blank " className="text-400">
                        MDEA NOTIFICATIONS
                    </a>
                </div>
            </div>
            )}
        </>
    )

}
