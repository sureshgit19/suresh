import { useRef, useState, useEffect, useReducer } from "react";
import readNDJSONStream from "ndjson-readablestream";
import logoheadertext from "../../assets/images/logoheadertext.svg";
import styles from "./Chat.module.css";
import plusicon from "../../assets/images/plusicon.svg";
import { History } from "../../components/History/History";
import { ReaskQuestion } from "../../components/Reask/ReaskQuestion";

import {
    chatApi,
    RetrievalMode,
    Approaches,
    AskResponse,
    ChatRequest,
    ChatTurn,
    getUserId,
    ChatItem,
    getRelatedTopics,
    reaskApi,
    UpdateHistoryRequest,
    RelatedTopicsRequest,
    createHistoryItem,
    regenerateAnswer
} from "../../api";
import { Answer, AnswerError, AnswerLoading } from "../../components/Answer";
import { QuestionInput } from "../../components/QuestionInput";
import { ExampleList } from "../../components/Example";
import { UserChatMessage } from "../../components/UserChatMessage";
import { AnalysisPanel, AnalysisPanelTabs } from "../../components/AnalysisPanel";
import { Notes } from "../../components/Notes/Notes";
import { useSelector, useDispatch } from "react-redux";
import { parseBoolean, splitNestedBrackets } from "../../shared/common";
import { useMap } from "@uidotdev/usehooks";
import { useAppInsightsContext } from "@microsoft/applicationinsights-react-js";
import LeftSidePanel from "../../containers/left-side-panel";
import Trending from "../../components/Queries/Trending/trending";
import Documents from "../../components/Queries/Documents/Documents";
import { FavouritesList } from "../../components/Favourite/Favourite";
import { disableNewChat } from "../../store/reducer-slice/newchat.slice";
import { Info16Regular } from "@fluentui/react-icons";
import { Tooltip } from "primereact/tooltip";
import { Dialog } from "primereact/dialog";
import { Button } from "primereact/button";
import { BentoBox } from "../../components/BentoBox/BentoBox";
import { useMutationObserver, useScroll, useScrollIntoView } from '@react-hooks-library/core'
import { a } from "@react-spring/web";

const Chat = () => {
    const dispatch = useDispatch();
    const appInsights = useAppInsightsContext();
    const userGroups: string[] = useSelector((state: any) => state.user.usergroups);
    const kbcinfo = "Knowledge Base Chat is our new secure and internal AI platform designed to answer any questions you may have regarding Commercial Marketplace data and motions."
    const [isConfigPanelOpen, setIsConfigPanelOpen] = useState(false);
    const [promptTemplate, setPromptTemplate] = useState<string>("");
    const [retrieveCount, setRetrieveCount] = useState<number>(3);
    const [retrievalMode, setRetrievalMode] = useState<RetrievalMode>(RetrievalMode.Hybrid);
    const [useSemanticRanker, setUseSemanticRanker] = useState<boolean>(true);
    const [shouldStream, setShouldStream] = useState<boolean>(true);
    const [useSemanticCaptions, setUseSemanticCaptions] = useState<boolean>(false);
    const [excludeCategory, setExcludeCategory] = useState<string>("");
    const [useSuggestFollowupQuestions, setUseSuggestFollowupQuestions] = useState<boolean>(false);

    const lastQuestionRef = useRef<string>("");

    const chatInputRef = useRef<HTMLDivElement | null>(null);

    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [isStreaming, setIsStreaming] = useState<boolean>(false);
    const [error, setError] = useState<unknown>();

    const [activeCitation, setActiveCitation] = useState<string>();
    const [activeAnalysisPanelTab, setActiveAnalysisPanelTab] = useState<AnalysisPanelTabs | undefined>(undefined);

    const [selectedAnswer, setSelectedAnswer] = useState<number>(0);
    const [answers, setAnswers] = useState<[user: string, response: AskResponse][]>([]);
    const [streamedAnswers, setstreamedAnswers] = useState<[user: string, response: AskResponse][]>([]);
    const [historyClick, setHistoryClick] = useState<boolean>(false);
    /* Notes */
    const [isEditing, setIsEditing] = useState(false);
    const [openNoteDialog, setOpenNoteDialog] = useState(false);

    const [noteValue, setNoteValue] = useState("");
    const [selectedHistoryItemId, setSelectedHistoryItemId] = useState<string | null>(null);

    const relatedTopicsMap = useMap();

    //answerloading

    const [answerLoading, setAnswerLoading] = useState<boolean>(false);

    // favourites
    const [favRefresh, setFavRefresh] = useState(false);
    const [historyLast30DaysRefresh, setHistoryLast30DaysRefresh] = useState(false);

    /*toggle Menu */
    const isPanelOpen = useSelector((state: any) => state.toggleSideBar.value);

    // new chat click from sidebar    
    const newChatClick = useSelector((state: any) => state.newChatClick.value);
    useEffect(() => { clearChat() }, [newChatClick])

    // Regerate icon loading
    const [regenerateLoading, setRegenerateLoading] = useState("pi pi-sync");

    const scrollContainerRef = useRef<HTMLDivElement | null>(null);
    const bottomRef = useRef<HTMLDivElement | null>(null);
    const answerLoadingRef = useRef<HTMLDivElement | null>(null);
    const [scrollHeight, setScrollHeight] = useState(0);
    const [, forceUpdate] = useReducer(x => x + 1, 0);
    const [stickyScroll, setStickyScroll] = useState(true);
    const inputRef = useRef<HTMLInputElement>(null);
    const [hasFocus, setHasFocus] = useState(true);
    const [scrollProgress, setScrollProgress] = useState(0);
    const [scrolling, setScrolling] = useState(false);
    const [isScrolledToBottom, setIsScrolledToBottom] = useState(true);
    const [scroll, setScroll] = useState(0)

    const stickyScrollRef = useRef(stickyScroll);
    const isScrolledToBottomRef = useRef(isScrolledToBottom);
    const isAtBottom = scrollContainerRef?.current ?
        scrollContainerRef?.current?.scrollHeight -
        scrollContainerRef?.current?.clientHeight -
        scrollContainerRef?.current?.scrollTop < 10 : true;


    useScroll(scrollContainerRef, ({ scrollX, scrollY }) => {
        setScroll(scrollY)
        if (scrollY == 1) {
            setScrolling(false)
        } else {
            setScrolling(true)
        }
    });

    useEffect(() => {
        if (stickyScroll) {
            setTimeout(() => {
                bottomRef?.current?.scrollIntoView({ behavior: "smooth" });
                scrollContainerRef?.current?.scrollTo({ top: scrollContainerRef?.current.scrollHeight, behavior: "smooth" });
            }, 100)
        }
    }, [answers, isLoading, streamedAnswers])

    useEffect(() => {
        if (scroll > 0.98 && !stickyScroll) {
            setStickyScroll(true);
        }
    }, [scroll])


    useEffect(() => {
        stickyScrollRef.current = stickyScroll;
        isScrolledToBottomRef.current = isScrolledToBottom;
    }, [stickyScroll, isScrolledToBottom])

    useEffect(() => {
        const handleWheel = (event: WheelEvent) => {
            if (stickyScrollRef.current && event.deltaY < 0) {
                console.log('removing sticky scroll');
                setStickyScroll(false);
            } else if (!stickyScrollRef.current && event.deltaY > 0 && isAtBottom) {
                console.log('adding sticky scroll');
                setStickyScroll(true);
            }
        };

        const scrollContainer = scrollContainerRef.current;
        if (scrollContainer) {
            scrollContainer.addEventListener('wheel', handleWheel);

            // Cleanup the event listener on component unmount
            return () => {
                scrollContainer.removeEventListener('wheel', handleWheel);
            };
        }
    }, []);

    /**
     * Save these commments for now would like to experiment more on managing scrolling
     * 
     */

    // useEffect(() => {
    //     if (stickyScroll) scrollContainerRef?.current?.scrollTo({ top: scrollContainerRef?.current.scrollHeight, behavior: "smooth" });
    // }, [scrollContainerRef.current?.scrollHeight]);


    // useEffect(() => {
    //     if (isScrolledToBottom) {
    //         setStickyScroll(true);
    //     }

    //     if (stickyScroll) {
    //         setTimeout(() => {
    //             bottomRef?.current?.scrollIntoView({ behavior: "smooth" });
    //             scrollContainerRef?.current?.scrollTo({ top: scrollContainerRef?.current.scrollHeight, behavior: "smooth" });
    //         }, 200)
    //     }
    // }, [isScrolledToBottom, stickyScroll])

    // useEffect(() => {
    //     setIsScrolledToBottom(isAtBottom);
    // }, [isLoading, scrollContainerRef.current?.scrollHeight, answers, streamedAnswers]);

    // useMutationObserver(
    //     scrollContainerRef,
    //     (mutations: any) => {
    //         console.log("mutation observer", mutations);
    //         setIsScrolledToBottom(isAtBottom);
    //     },
    //     { childList: true, subtree: true }
    // )

    const checkFocus = () => {
        if (inputRef.current) {
            setHasFocus(document.activeElement === inputRef.current);
        }
    };

    useEffect(() => {
        // Initial check
        checkFocus();

        // Event listeners for focus and blur
        const handleFocus = () => checkFocus();
        const handleBlur = () => checkFocus();

        const inputElement = inputRef.current;
        if (inputElement) {
            inputElement.addEventListener('focus', handleFocus);
            inputElement.addEventListener('blur', handleBlur);
        }

        // Cleanup event listeners
        return () => {
            if (inputElement) {
                inputElement.removeEventListener('focus', handleFocus);
                inputElement.removeEventListener('blur', handleBlur);
            }
        };
    }, []);




    const fetchRelatedTopics = async (question: string, parsedResponse: AskResponse) => {
        //console.log("question: ", question);
        if (relatedTopicsMap.has(question)) {
            return relatedTopicsMap.get(question);
        }
        try {
            const history: ChatTurn[] = answers.map(a => ({ user: a[0], bot: a[1].answer, date: new Date() }));
            const request: RelatedTopicsRequest = {
                history: [...history, { user: question, bot: "", date: new Date() }],
                approach: Approaches.ReadRetrieveRead,
                overrides: {
                    top: retrieveCount,
                    retrievalMode: retrievalMode,
                    semanticRanker: useSemanticRanker,
                    semanticCaptions: useSemanticCaptions,
                    suggestFollowupQuestions: useSuggestFollowupQuestions
                },
                parsedResponse: parsedResponse,
                question,
                user_security_group: userGroups
            };
            let relatedTopicsFromApi = await getRelatedTopics(request);
            relatedTopicsMap.set(question, relatedTopicsFromApi);
            return relatedTopicsFromApi;
        } catch (e) {
            console.error("Error while fetching related topics:", e);
        }
    };

    const handleAsyncRequest = async (question: string, answers: [string, AskResponse][], setAnswers: Function, responseBody: ReadableStream<any>) => {
        let answer: string = "";
        let askResponse: AskResponse = {} as AskResponse;
        let hhid: string = "";
        setIsStreaming(true);
        setAnswerLoading(true);
        const updateState = (newContent: string) => {
            return new Promise(resolve => {
                setTimeout(() => {
                    answer += newContent;
                    const latestResponse: AskResponse = { ...askResponse, answer };
                    setstreamedAnswers([[question, latestResponse]]);
                    resolve(null);
                }, 33);
            });
        };
        try {
            for await (const event of readNDJSONStream(responseBody)) {
                hhid = "";
                if (event["history_item_id"]) {
                    //console.log("**********");
                    hhid = event["history_item_id"];
                    //console.log(event["history_item_id"]);
                }

                if (event["data_points"]) {
                    askResponse = event as AskResponse;
                    askResponse.arhistory_id = hhid;
                } else if (event["choices"] && event["choices"][0] && event["choices"][0]["delta"]["content"]) {
                    await updateState(event["choices"][0]["delta"]["content"]);
                    setIsLoading(false);
                }
            }
        } finally {
            setIsStreaming(false);
            setAnswerLoading(false);
        }
        const fullResponse: AskResponse = { ...askResponse, answer };
        fullResponse.arhistory_id = hhid;
        return fullResponse;
    };

    const makeApiRequest = async (question: string) => {
        lastQuestionRef.current = question;

        error && setError(undefined);
        setIsLoading(true);
        dispatch(disableNewChat(true));
        setActiveCitation(undefined);
        setActiveAnalysisPanelTab(undefined);
        let parsedResponse: AskResponse = {} as AskResponse;
        try {
            const history: ChatTurn[] = answers.map(a => ({ user: a[0], bot: a[1].answer, date: new Date() }));
            const request: ChatRequest = {
                history: [...history, { user: question, bot: "", date: new Date() }],
                approach: Approaches.ReadRetrieveRead,
                shouldStream: shouldStream,
                overrides: {
                    promptTemplate: promptTemplate.length === 0 ? undefined : promptTemplate,
                    excludeCategory: excludeCategory.length === 0 ? undefined : excludeCategory,
                    top: retrieveCount,
                    retrievalMode: retrievalMode,
                    semanticRanker: useSemanticRanker,
                    semanticCaptions: useSemanticCaptions,
                    suggestFollowupQuestions: useSuggestFollowupQuestions
                },
                user_security_group: userGroups
            };

            const response = await chatApi(request);
            if (!response.body) {
                throw Error("No response body");
            }
            if (shouldStream) {
                parsedResponse = await handleAsyncRequest(question, answers, setAnswers, response.body);

                setHistoryLast30DaysRefresh(!historyLast30DaysRefresh);
                if (parsedResponse.data_points?.length) {
                    const lastObject = request.history[request.history.length - 1];
                    lastObject.bot = parsedResponse.answer;
                    const reaskRequestOptions = {
                        question: question,
                        parsedResponse: parsedResponse,
                        approach: Approaches.ReadRetrieveRead,
                        request,
                        user_security_group: userGroups
                    };
                    const historyPayload = { question: question, parsedResponse: parsedResponse, userid: getUserId(), user_security_group: userGroups };
                    createHistoryItem(historyPayload);
                    reaskApi(reaskRequestOptions)
                        .then(res => res.json())
                        .then(async data => {
                            if (data?.newquestion && data.newquestion.trim() != "") {
                                const questionArray = data.newquestion.split("?");
                                const formattedArray = splitNestedBrackets(questionArray[0] + "?", false);
                                parsedResponse.reask_question = formattedArray.join(" ");
                                setAnswers([...answers, [question, parsedResponse]]);
                            }
                        });
                }

                // To do: add relatedTopics from api
                if (!parsedResponse.relatedTopics) {
                    fetchRelatedTopics(question, parsedResponse).then(result => {
                        parsedResponse.relatedTopics = result;
                        parsedResponse.showRegenerate = true;
                        setAnswers([...answers, [question, parsedResponse]]);
                    }).catch(err => { parsedResponse.showRegenerate = true; });
                }
                setAnswers([...answers, [question, parsedResponse]]);
            } else {
                const parsedResponse: AskResponse = await response.json();
                if (response.status > 299 || !response.ok) {
                    throw Error(parsedResponse.error || "Unknown error");
                }
                // To do: add relatedTopics from api
                if (!parsedResponse.relatedTopics) {
                    parsedResponse.relatedTopics = await fetchRelatedTopics(question, parsedResponse);
                }
                setAnswers([...answers, [question, parsedResponse]]);
                setIsLoading(false);
            }
        } catch (e) {
            setError(e);
        } finally {
            setIsLoading(false);
            dispatch(disableNewChat(false));
        }
    };
    const handleRegenerate = async (history_item_id: string) => {
        error && setError(undefined);
        setRegenerateLoading("pi pi-sync pi-spin");
        let askResponse: AskResponse = {} as AskResponse;
        try {
            const history: ChatTurn[] = [];
            let question: string = "";
            for (let i = 0; i < answers.length; i++) {
                const answer = answers[i];

                history.push({ user: answer[0], bot: answer[1].answer, date: new Date() });
                if (answer[1].new_answer_av && answer[1].new_answer_av.trim() != "") {
                    history.push({ user: answer[0], bot: answer[1].new_answer_av, date: new Date() });
                }

                // break the loop when history id matched, this is to create history upto the regenerate answer
                if (answer[1].arhistory_id === history_item_id) {
                    question = answer[0]
                    askResponse = answer[1]
                    break;
                }
            }

            const request: any = {
                history: [...history, { user: question, bot: "", date: new Date() }],
                approach: Approaches.ReadRetrieveRead,
                shouldStream: shouldStream,
                overrides: {
                    promptTemplate: promptTemplate.length === 0 ? undefined : promptTemplate,
                    excludeCategory: excludeCategory.length === 0 ? undefined : excludeCategory,
                    top: retrieveCount,
                    retrievalMode: retrievalMode,
                    semanticRanker: useSemanticRanker,
                    semanticCaptions: useSemanticCaptions,
                    suggestFollowupQuestions: useSuggestFollowupQuestions
                },
                history_item_id: history_item_id,
                user_security_group: userGroups
            };

            const response = await regenerateAnswer(request);

            askResponse.new_answer_av = response.regenerated_response;
            askResponse.new_answer_date = new Date().toJSON();
            const updatedAnswer = answers.map(x => {
                let currentitem: [user: string, resposne: AskResponse];
                if (x[1].arhistory_id == history_item_id) {
                    currentitem = [question, askResponse];
                    return currentitem;
                }
                return x
            })
            setAnswers(JSON.parse(JSON.stringify(updatedAnswer)));
            appInsights.trackEvent({ name: "re-generate", properties: { question: question, Operation: "click" } });
        } catch (e) {
            setError(e);
        } finally {
            setRegenerateLoading("pi pi-sync");
        }
    }
    const clearChat = () => {
        lastQuestionRef.current = "";
        error && setError(undefined);
        setActiveCitation(undefined);
        setActiveAnalysisPanelTab(undefined);
        setAnswers([]);
    };

    const onExampleClicked = (example: string) => {
        appInsights.trackEvent({ name: "bentobox", properties: { question: example, Operation: "click" } });
        //trackBentoBoxClick({question:example});
        makeApiRequest(example);
    };

    const onShowCitation = (citation: string, index: number) => {
        if (activeCitation === citation && activeAnalysisPanelTab === AnalysisPanelTabs.CitationTab && selectedAnswer === index) {
            setActiveAnalysisPanelTab(undefined);
        } else {
            setActiveCitation(citation);
            setActiveAnalysisPanelTab(AnalysisPanelTabs.CitationTab);
        }

        setSelectedAnswer(index);
    };

    const onToggleTab = (tab: AnalysisPanelTabs, index: number) => {
        if (activeAnalysisPanelTab === tab && selectedAnswer === index) {
            setActiveAnalysisPanelTab(undefined);
        } else {
            setActiveAnalysisPanelTab(tab);
        }

        setSelectedAnswer(index);
    };

    const onHistoryOrFavItemClick = async (savedChatItem: ChatItem, source: string) => {
        const chatItem: ChatItem = await getHistoryByid(savedChatItem.history_item_id) ?? savedChatItem;
        setHistoryClick(!historyClick);
        const askResponse = {} as AskResponse;
        askResponse.arhistory_id = chatItem.history_item_id;
        askResponse.answer = chatItem.bot;
        askResponse.new_answer_av = savedChatItem.new_answer;
        askResponse.data_points = [];
        askResponse.thoughts = null;
        askResponse.created = chatItem.created;
        askResponse.updated = chatItem.updated;
        askResponse.new_answer_date = savedChatItem.new_answer_date;
        askResponse.response_vote_feedback = chatItem.response_vote_feedback;
        const question = chatItem.user || chatItem.title;
        lastQuestionRef.current = question;

        askResponse.vote = chatItem.response_upvote_button;
        const noteText = chatItem.notes ?? "Write your Notes here";
        askResponse.isFavourite = false;
        if (source === "Favourite") {
            askResponse.isFavourite = true;
        } else {
            if (Array.isArray(chatItem.favorites)) if (chatItem.favorites.length > 0) askResponse.isFavourite = true;
        }
        setNoteValue(noteText);

        setAnswers([...answers, [question, askResponse]]);
        appInsights.trackEvent({ name: source, properties: { question: question, Operation: "click" } });
    };

    const onTrendingClicked = async (trending: string) => {
        /* lastQuestionRef.current = "";
        error && setError(undefined);
        setActiveCitation(undefined);
        setActiveAnalysisPanelTab(undefined); */
        setAnswers([]);
        try {
            await makeApiRequest(trending);
        } catch (e) {
            console.error("Error while processing trending item:", e);
        }

        //console.log("on trending clicked is called");
    };

    const onShareClick = async (history_item_id: string, newAnswer: boolean) => {
        if (history_item_id) {
            setShareNewAnswer(newAnswer);
            const history = await getHistoryByid(history_item_id);
            if (history) {
                const sharedText = `Question: ${history.user}\n\nAnswer: ${newAnswer ? history.new_answer : history.bot}\nNotes: ${history.notes}`;
                copyTextToClipboard(sharedText);
                setShareContent(history);
                showShareDialog();
            }
        }
    };

    const onFavShareClick = (chatItem: ChatItem) => {
        const sharedText = `Question: ${chatItem.user}\nAnswer: ${parseBoolean(chatItem.new_answer_av) ? chatItem.new_answer : chatItem.bot}\nNotes: ${chatItem.notes}`;
        copyTextToClipboard(sharedText);
        setShareContent(chatItem);
        showShareDialog();
    }

    const onNotesClick = async (history_item_id: string) => {
        setNoteValue("");
        setOpenNoteDialog(true);
        setSelectedHistoryItemId(history_item_id);
        if (history_item_id) {
            const history = await getHistoryByid(history_item_id);
            if (history) {
                setNoteValue(history.notes ?? "");
            }
        }
    };

    const copyTextToClipboard = (text: string) => {
        navigator.clipboard
            .writeText(text)
            .then(() => {
                //console.log("Text copied to clipboard:", text);
            })
            .catch(error => {
                console.error("Error copying text to clipboard:", error);
            });
    };

    const showShareDialog = () => {
        setShareDialogVisible(true);
        setTimeout(() => setShareDialogVisible(false), 500000);
    };

    const getHistoryByid = async (history_item_id: string) => {
        let data: ChatItem | null = null;
        try {
            const response = await fetch(`/get_history_item/${history_item_id}`);
            if (response.ok) {
                const responseData = await response.json();
                //console.log(responseData, " this is the response data ");
                if (Array.isArray(responseData)) {
                    data = responseData[0];
                }
            } else {
                console.error("Failed to fetch chat history");
            }
        } catch (error) {
            console.error("Error fetching chat history", error);
        }
        return data;
    };

    useEffect(() => {
        getUpDownVoteOption();
    }, []);

    const getUpDownVoteOption = async () => {
        try {
            const response = await fetch("/vote_options");
            if (response.ok) {
                const responseData = await response.json();
                // console.log(responseData);
                setVoteOptions(responseData);
            } else {
                console.error("Failed to fetch vote options");
            }
        } catch (error) {
            console.error("Error fetching vote options", error);
        }
    };

    const onLikeDislikeClick = (data: UpdateHistoryRequest) => {
        setHistoryUpdatedData(data);
    };

    const [shareContent, setShareContent] = useState<ChatItem | null>(null);
    const [shareNewAnswer, setShareNewAnswer] = useState<boolean>(false);
    const [shareDialogVisible, setShareDialogVisible] = useState<boolean>(false);
    const [voteOptions, setVoteOptions] = useState<any>({});
    const [historyUpdatedData, setHistoryUpdatedData] = useState<UpdateHistoryRequest>();

    return (
        <div className={`${styles.container}`}>
            <Dialog onHide={() => setShareDialogVisible(false)} visible={shareDialogVisible}
                header="Item copied to clipboard! You can share it now"
                resizable={false}
                draggable={false}
                footer={<div className="h-3rem"></div>}>

                <p>
                    <b>Question:</b> {shareContent?.user}
                </p>
                <p className="word-break-all">
                    <b>Answer:</b> {shareNewAnswer ? shareContent?.new_answer : shareContent?.bot}
                </p>
                <p>
                    <b>Notes:</b> {shareContent?.notes}
                </p>
            </Dialog>
            <Notes
                historyItemId={selectedHistoryItemId || null}
                openDialog={openNoteDialog}
                closeDialog={() => setOpenNoteDialog(false)}
                noteValue={noteValue}
            />

            <LeftSidePanel options={{ noPaddingTop: true }}>
                <History
                    refreshComponent={favRefresh}
                    refreshLast30DaysComponent={historyLast30DaysRefresh}
                    historyUpdatedData={historyUpdatedData}
                    onItemClick={onHistoryOrFavItemClick}
                />

                <FavouritesList className=""
                    onShare={onFavShareClick}
                    onItemClick={onHistoryOrFavItemClick}
                    refreshComponent={favRefresh} />

                <Trending onTrendingClick={onTrendingClicked}></Trending>

                <Documents className="pt-5"></Documents>

            </LeftSidePanel>
            <div className={`flex flex-column w-full h-full max-w-full`}>
                <div className={`${styles.chatContainer} flex flex-1 flex-column w-full max-w-full`} ref={scrollContainerRef}>
                    <>
                        <div className="flex flex-column flex-grow-1 m-4 gap-4 justify-content-evenly align-content-center align-items-center">
                            <img src={logoheadertext} alt="logo" className={styles.homelogtext} />
                            <Info16Regular className="md:hidden kbcinfoicon" data-pr-tooltip={kbcinfo} />
                            <Tooltip target=".kbcinfoicon" position="bottom" pt={{ arrow: { className: 'hidden' } }}></Tooltip>
                            <h2 className={`w-50 flex align-items-center justify-center ${styles.chatEmptyStateSubtitle} sm:hidden md:flex`}>
                                {kbcinfo}
                            </h2>
                        </div>
                    </>
                    {!lastQuestionRef.current ? (
                        <div className={`${styles.chatEmptyState} flex-grow-1`}>
                            <BentoBox onBentoClicked={onExampleClicked} />
                        </div>
                    ) : (
                        <div className="flex justify-content-end flex-grow-1 pb-8 md:pb-0 flex-column align-items-center w-12 lg:w-9 xl:w-9">

                            {answers.map((answer, index) => (
                                <>
                                    <section className={`${styles.chatMessageStream} w-full`} key={`section${index}`}>
                                        <UserChatMessage message={answer[0]} />
                                        <div className={styles.chatMessageGpt}>
                                            <Answer
                                                isStreaming={isStreaming}
                                                key={`answer${index}`}
                                                answer={answer[1]}
                                                isSelected={selectedAnswer === index && activeAnalysisPanelTab !== undefined}
                                                onCitationClicked={c => onShowCitation(c, index)}
                                                onThoughtProcessClicked={() => onToggleTab(AnalysisPanelTabs.ThoughtProcessTab, index)}
                                                onSupportingContentClicked={() => onToggleTab(AnalysisPanelTabs.SupportingContentTab, index)}
                                                onFollowupQuestionClicked={q => makeApiRequest(q)}
                                                showFollowupQuestions={useSuggestFollowupQuestions && answers.length - 1 === index}
                                                favListRefresh={() => setFavRefresh(!favRefresh)}
                                                openNoteDialog={() => setOpenNoteDialog(true)}
                                                shareClick={newAnswer => onShareClick(answer[1].arhistory_id ?? "", newAnswer)}
                                                onNotesClick={() => onNotesClick(answer[1].arhistory_id ?? "")}
                                                answerLoading={answerLoading}
                                                loadingStream={index === streamedAnswers.length - 1 && answer[0] === lastQuestionRef.current}
                                                voteOptions={voteOptions}
                                                onLikeDislikeClick={data => {
                                                    onLikeDislikeClick(data);
                                                }}
                                            />
                                        </div>

                                        <div className={styles.relatedTopicContainer}>
                                            {answer[1].relatedTopics?.newquestions?.map(topic => (
                                                <div
                                                    className={styles.relatedTopic}
                                                    onClick={() => {
                                                        appInsights.trackEvent({
                                                            name: "relatedtopic",
                                                            properties: { question: topic.question, keyword: topic.keyword, Operation: "click" }
                                                        });
                                                        makeApiRequest(topic.question);

                                                    }}
                                                >
                                                    {topic.keyword}
                                                </div>
                                            ))}
                                            {answer[1].showRegenerate && (

                                                <Button rounded className={styles.regenerateIcon}
                                                    icon={regenerateLoading}
                                                    label="Regenerate"
                                                    type="button"
                                                    onClick={() => handleRegenerate(answer[1].arhistory_id ?? '')}>
                                                </Button>
                                            )}
                                        </div>
                                    </section>

                                    {!!answer[1].reask_question && answer[1].reask_question?.trim() != "" ? (
                                        <ReaskQuestion
                                            onReaskQuestionClicked={newquestion => {
                                                appInsights.trackEvent({ name: "reask", properties: { question: newquestion, Operation: "click" } });
                                                makeApiRequest(newquestion);
                                            }}
                                            key={"reask_" + index}
                                            suggested_question={answer[1].reask_question ?? ""}
                                        ></ReaskQuestion>
                                    ) : null}
                                </>
                            ))}
                            {isStreaming && streamedAnswers.map((streamedAnswer, index) => (
                                <section className={`${styles.chatMessageStream} w-full`} key={`section${index}`}>
                                    <UserChatMessage message={streamedAnswer[0]} />
                                    <div className={styles.chatMessageGpt}>
                                        <Answer
                                            isStreaming={true}
                                            key={`answer${index}`}
                                            answer={streamedAnswer[1]}
                                            isSelected={false}
                                            onCitationClicked={c => onShowCitation(c, index)}
                                            onThoughtProcessClicked={() => onToggleTab(AnalysisPanelTabs.ThoughtProcessTab, index)}
                                            onSupportingContentClicked={() => onToggleTab(AnalysisPanelTabs.SupportingContentTab, index)}
                                            onFollowupQuestionClicked={q => makeApiRequest(q)}
                                            showFollowupQuestions={useSuggestFollowupQuestions && answers.length - 1 === index}
                                            favListRefresh={() => setFavRefresh(!favRefresh)}
                                            openNoteDialog={() => setOpenNoteDialog(true)}
                                            shareClick={newAnswer => onShareClick(streamedAnswer[1].arhistory_id ?? "", newAnswer)}
                                            onNotesClick={() => onNotesClick(streamedAnswer[1].arhistory_id ?? "")}
                                            answerLoading={answerLoading}
                                            loadingStream={index === streamedAnswers.length - 1 && streamedAnswer[0] === lastQuestionRef.current}
                                            voteOptions={voteOptions}
                                        />
                                    </div>
                                </section>
                            ))}
                            {isLoading && (
                                <div className={styles.chatMessageGptMinWidth} ref={answerLoadingRef}>
                                    <UserChatMessage message={lastQuestionRef.current} />
                                    <div ref={answerLoadingRef} className={styles.chatMessageGptMinWidth}>
                                        <AnswerLoading />
                                    </div>
                                </div>
                            )}
                            {error ? (
                                <>
                                    <UserChatMessage message={lastQuestionRef.current} />
                                    <div className={styles.chatMessageGptMinWidth}>
                                        <AnswerError error={error.toString()} onRetry={() => makeApiRequest(lastQuestionRef.current)} />
                                    </div>
                                </>
                            ) : null}


                        </div>
                    )}
                </div>
                <div id="chatInput" ref={chatInputRef} className={`${styles.chatInput} flex p-5 pt-0 m-0 w-full flex align-items-center justify-content-center`}>
                    <QuestionInput
                        clearOnSend
                        placeholder="Type a new question about Commercial Marketplace...."
                        disabled={isLoading}
                        onSend={question => makeApiRequest(question)}
                        onFocus={() => setHasFocus(true)}
                        onBlur={() => setHasFocus(false)}
                    />
                    <div className={`${styles.disclaimerContainer} hidden md:flex`}>
                        <div className={styles.disclaimer}>
                            Knowledge Base Chat is trained on an extensive archive of secure, high-quality data and files curated by the Marketplace Data,
                            Experimentation, and Analytics (MDEA) team within the Global Demand Center (GDC). The full content list can be found{" "}
                            <a href="https://aka.ms/KBCIngestionList" target="_blank">
                                here
                            </a>
                            . If you would like to contribute to, ask questions about, or correct citations made by Knowledge Base Chat, please contact
                            <a href="mailto:MDEA-support@microsoft.com" style={{ marginLeft: "5px" }}>
                                MDEA-support@microsoft.com
                            </a>
                            .
                        </div>

                        {!lastQuestionRef.current || isLoading ? null : (
                            <button
                                type="button"
                                onClick={clearChat}
                                disabled={!lastQuestionRef.current || isLoading}
                                className={`${styles.chatbutton} ${!lastQuestionRef.current || isLoading ? "newchatdisable" : "newchatenable"}`}
                            >
                                <img src={plusicon} className={styles.plusIcon} alt="New chat Icon" />
                                New Chat
                            </button>
                        )}
                    </div>
                </div>




                {answers.length > 0 && activeAnalysisPanelTab && (
                    <AnalysisPanel
                        className={styles.chatAnalysisPanel}
                        activeCitation={activeCitation}
                        onActiveTabChanged={x => onToggleTab(x, selectedAnswer)}
                        citationHeight="810px"
                        answer={answers[selectedAnswer][1]}
                        activeTab={activeAnalysisPanelTab}
                    />
                )}
            </div>

        </div >
    );
};

export default Chat;
