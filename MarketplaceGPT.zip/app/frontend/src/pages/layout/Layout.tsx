import { Outlet, useNavigate } from "react-router-dom";
import { Header } from "../header/header";
import { PublicClientApplication } from "@azure/msal-browser";
import { AuthenticatedTemplate, MsalProvider, UnauthenticatedTemplate, useMsal } from "@azure/msal-react";
import { loginRequest } from "../../authConfig";

import { UniversalHeader } from "../UniversalHeader/UniversalHeader";
import { ProgressSpinner } from "primereact/progressspinner";
import { getUserId } from "../../api";
import { UnauthenticatedState } from "../../components/UnauthenticatedState/UnauthenticatedState";
import { UserProvider } from "../../Authentication/UserProvider";

const originalFetch = window.fetch;
function modifyUrl(resource: RequestInfo | URL) {
    const domain = window.location.origin;
    if (resource.toString().includes("login.microsoftonline.com")) {
        return resource;
    }
    if (domain.includes("localhost")) {
        return "http://127.0.0.1:50505" + resource;
    }
    return resource;
}

const Layout = ({ pca }: { pca: PublicClientApplication }) => {

    window.fetch = async (...args) => {
        let [resource, config] = args;

        if (!resource.toString().includes("login.microsoftonline.com")) {
            if (!config || !config.headers || Object.keys(config.headers).length == 0) {
                config = {
                    ...config, headers: {
                        "Content-Type": "application/json",
                        "X-User-Email": getUserId()
                    }
                };
            }
            config = {
                ...config,
                headers: {
                    ...config?.headers,
                    "Authorization": "Bearer " + sessionStorage.getItem("accesstoken"),
                    "X-User-Email": getUserId()
                }
            };
        }
        // Intercept the request and modify the URL
        resource = modifyUrl(resource);

        try {

            const response = await originalFetch(resource, config);
            if (response.status == 401) {
                const token = await pca.acquireTokenSilent(loginRequest)
                sessionStorage.setItem("accesstoken", token.accessToken);
                config = {
                    ...config,
                    headers: {
                        ...config?.headers,
                        "Authorization": "Bearer " + sessionStorage.getItem("accesstoken")
                    }
                };
                return await originalFetch(resource, config);
            }
            return response;
        } catch (error) {
            throw error;
        }
    };
    return (
        <MsalProvider instance={pca}>
            <AuthenticatedTemplate>
                <UserProvider>
                    <div className="flex flex-column h-screen w-screen">
                        <div className="flex flex-column flex-initial w-full sticky top-0 z-5">
                            <div>
                                <UniversalHeader />
                            </div>
                            <div className="shadow-3">
                                <Header />
                            </div>
                        </div>
                        <div className="flex flex-1 w-full overflow-auto">
                            <Outlet />
                        </div>
                    </div>
                </UserProvider>
            </AuthenticatedTemplate>
            <UnauthenticatedTemplate>
                <div className="h-screen w-screen" style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <UnauthenticatedState title="Attempting to Authenticate..." text="You need to sign in to access this page." placement="center" />
                </div>
            </UnauthenticatedTemplate>
        </MsalProvider>
    );
};

export default Layout;
