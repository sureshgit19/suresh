export enum ComponentStatus {
    Loaded = "loaded",
    NoContent = "no-content",
    Loading = "loading",
    Error = "error",
}