import { useState, useEffect } from 'react';
import { fetchResourceGroups } from '../api';

const useResourceGroups = (username: string) => {
  const [resourceGroups, setResourceGroups] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);


  useEffect(() => {
    setLoading(true);
    if (!username) return;
    fetchResourceGroups(username).then((data) => {
      setResourceGroups(data);
    }).catch((error) => {
      setError(error);
    }).finally(() => {
      setLoading(false);
    });
  }, [username]);

  return { resourceGroups, loading, error };
};

export default useResourceGroups;
