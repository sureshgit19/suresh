import { UpdateHistoryRequest, updateHistoryDetail } from "../api";
import { ThumbsDownIssue, VoteDirection } from "../components/Answer";

export interface UpdateHistoryResponse {
    historyId: string;
    vote: VoteDirection;
    issue: ThumbsDownIssue;
    voteFeedback: string;
}

export const useFeedback = () => {

    const upvoteRequest = (historyId: string): Promise<UpdateHistoryResponse> => {
        return historyUpdateRequest(historyId, VoteDirection.UpVote, "");
    }

    const downvoteRequest = (historyId: string, issue: ThumbsDownIssue, reason: string): Promise<UpdateHistoryResponse> => {
        return historyUpdateRequest(historyId, `${VoteDirection.DownVote}:${issue}`, reason || "");
    }

    const clearVoteRequest = (historyId: string): Promise<UpdateHistoryResponse> => {
        return historyUpdateRequest(historyId, VoteDirection.NoVote, "");
    }


    const historyUpdateRequest = (historyId: string, vote: string, voteFeedback: string, notes: string | null = null, title: string | null = null, state: string | null = null): Promise<UpdateHistoryResponse> => {
        var historyupdate_request: UpdateHistoryRequest = {
            history_item_id: historyId,
            response_upvote_button: vote,
            response_vote_feedback: voteFeedback,
            notes,
            title,
            state
        };

        return updateHistoryDetail(historyupdate_request).then((response) => {
            return <UpdateHistoryResponse>{
                historyId: historyId,
                vote: vote?.split(':')[0] as VoteDirection ?? VoteDirection.NoVote,
                issue: vote?.split(':')[1]?.toLowerCase() ?? ThumbsDownIssue.None,
                voteFeedback: voteFeedback,
            }
        });

    }
    return { upvoteRequest, downvoteRequest, clearVoteRequest };
}


export default useFeedback;