import { ChatItem } from "../api/models";
export function sortChatHistoryDate(chatData: ChatItem[]): ChatItem[] {
    return chatData.sort((a, b) => {
        const dateA = new Date(a.created);
        const dateB = new Date(b.created);

        if (!isNaN(dateA.getTime()) && !isNaN(dateB.getTime())) {
            return dateB.getTime() - dateA.getTime();
        } else {
            return 0;
        }
    });
}

export function parseBoolean(value: string | boolean) {
    if (typeof value === "boolean") return value;

    return value?.toLowerCase() === "true" ? true : false;
}

export function splitNestedBrackets(str: string, returnContentInBracket = true) {
    let result = [];
    let bracketCount = 0;
    let currentSegment = "";
    let bracketresult = [];
    let bracketSegment = "";
    let isNestedBrackets = false;

    for (let i = 0; i < str.length; i++) {
        let char = str.charAt(i);
        if (char === "[") {
            bracketSegment += char;
            if (bracketCount === 0) {
                result.push(currentSegment);
                currentSegment = "";
            }
            bracketCount++;
        } else if (char === "]") {
            if (!isNestedBrackets) {
                isNestedBrackets = bracketCount > 1;
            }
            bracketCount--;
            bracketSegment += char;
            if (bracketCount === 0) {
                result.push(currentSegment);
                currentSegment = "";
                bracketresult.push({ bracketSegment, isNestedBrackets });
                bracketSegment = "";
                isNestedBrackets = false;
            }
        } else {
            if (bracketCount === 0) {
                currentSegment += char;
            } else {
                bracketSegment += char;
            }
        }
    }

    if (currentSegment) {
        result.push(currentSegment);
    }
    //console.log(result);
    //console.log(bracketresult);
    return returnContentInBracket ? bracketresult : result;
}

export function isTabularData(data: string) {
    // Split the data into rows
    const rows = data.trim().split("\n");

    // Check if there are at least two rows
    if (rows.length < 2 || !rows[0].includes("|")) {
        return false;
    }

    // Check if each row contains the same number of columns (split by '|')
    const numColumns = rows[0].split("|").length;
    for (let i = 1; i < rows.length; i++) {
        if (rows[i].split("|").length !== numColumns) {
            return false;
        }
    }

    // If all rows have the same number of columns, it's likely tabular data
    return true;
}

export function tabularToHtml(tabularData: string) {
    if (!isTabularData(tabularData)) {
        return tabularData;
    }
    // remove last dot from content
    const lastDotIndex = tabularData.lastIndexOf(".");
    if (lastDotIndex !== -1) {
        tabularData = tabularData.slice(0, lastDotIndex) + tabularData.slice(lastDotIndex + 1);
    }
    // Split the data into rows
    const rows = tabularData.trim().split("\n");

    // Split each row into columns
    const table = rows.map(row => row.split("|"));

    // Generate HTML table
    let htmlTable = "<table>\n";

    // Add table headers
    htmlTable += "<tr>\n";
    for (const header of table[0]) {
        if (header.trim() != "") htmlTable += `<th>${header.trim()}</th>`;
    }
    htmlTable += "</tr>\n";

    // Add table data
    for (let i = 1; i < table.length; i++) {
        htmlTable += "<tr>\n";
        for (const cell of table[i]) {
            if (cell.trim() != "" && !isOnlyHyphens(cell.trim())) htmlTable += `<td>${cell.trim()}</td>`;
        }
        htmlTable += "</tr>\n";
    }

    htmlTable += "</table>";

    return htmlTable;
}

export function createHyperlink(inputString: string, index: number, name: string) {
    const endIndex = inputString.indexOf(")", index);
    const link = inputString.substring(index, endIndex);
    const formattedname = name.replace("[", "").replace("]", "").trim();
    let namearray = formattedname.split("~")[0].split(".");
    if (namearray.length > 1) {
        namearray.pop();
    }
    const hyperlink = "<a class='chat-link' target='_blank' href='" + link + "'>" + namearray.join("") + "</a>";
    let formattedData = inputString;
    formattedData = formattedData.replace(`(${link})`, "").replace(`${name}`, hyperlink);

    return formattedData;
}

function isOnlyHyphens(inputString: string) {
    return /^-+$/.test(inputString);
}

export async function decryptData(encryptedData: string, iv: any, key: any) {
    const ivArray = Uint8Array.from(atob(iv), c => c.charCodeAt(0));
    const encryptedDataArray = Uint8Array.from(atob(encryptedData), c => c.charCodeAt(0));
    const keyBuffer = Uint8Array.from(atob(key), c => c.charCodeAt(0));
    const cryptoKey = await window.crypto.subtle.importKey("raw", keyBuffer, { name: "AES-CBC" }, false, ["decrypt"]);

    const decryptedData = await window.crypto.subtle.decrypt(
        {
            name: "AES-CBC",
            iv: ivArray
        },
        cryptoKey,
        encryptedDataArray
    );

    const decoder = new TextDecoder();
    return decoder.decode(decryptedData);
}
