import { createSlice, PayloadAction } from "@reduxjs/toolkit";

const initialState = {
    value: false,
    disableNewChat: false,
};

const newChatSlice = createSlice({
    name: "newchatclick",
    initialState,
    reducers: {
        newchatclick: state => {
            state.value = !state.value;
        },
        disableNewChat: (state, action) => {
            state.disableNewChat = action.payload;
        },
    }
});

export const { newchatclick, disableNewChat } = newChatSlice.actions;
export default newChatSlice.reducer;
