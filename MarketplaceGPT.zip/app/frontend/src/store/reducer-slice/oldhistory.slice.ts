import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { ChatItem } from "../../api";

const initialState: {
    data: ChatItem[];
} = {
    data: []
};

const historyAbove30Days = createSlice({
    name: "historyabove30days",
    initialState,
    reducers: {
        setHistoryAbove30Days: (state, action) => {
            state.data = action.payload;
        },
        updateHistoryItem: (state, action) => {
            const updatedItem = action.payload; // Assuming payload contains the updated item
            const index = state.data.findIndex(item => item.history_item_id === updatedItem.history_item_id);
            if (index !== -1) {
                state.data[index] = updatedItem;
            }
        }
    }
});

export const { setHistoryAbove30Days, updateHistoryItem } = historyAbove30Days.actions;
export default historyAbove30Days.reducer;
