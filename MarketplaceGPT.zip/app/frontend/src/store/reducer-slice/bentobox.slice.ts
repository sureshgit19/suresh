import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { IBentoModel } from "../../api";

const initialState: {
    data: IBentoModel[];
} = {
    data: []
};

const bentoBoxSlice = createSlice({
    name: "bentoboxdata",
    initialState,
    reducers: {
        setBentoBoxData: (state, action) => {
            state.data = action.payload;
        }
    }
});

export const { setBentoBoxData } = bentoBoxSlice.actions;
export default bentoBoxSlice.reducer;
