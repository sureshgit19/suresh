import { createSlice, PayloadAction } from "@reduxjs/toolkit";

const initialState = {
    value: false
};

const sideBarToggleSlice = createSlice({
    name: "toggleSideBar",
    initialState,
    reducers: {
        toggleSidebarState: state => {
            state.value = !state.value;
        },
        setSideBarOpenState: (state, action) => {
            state.value = action.payload;
        }
    }
});

export const { toggleSidebarState, setSideBarOpenState } = sideBarToggleSlice.actions;
export default sideBarToggleSlice.reducer;
