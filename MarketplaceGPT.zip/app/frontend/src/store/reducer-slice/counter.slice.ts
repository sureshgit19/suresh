import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface CounterState {
    value: number;
    originalvalue: number;
}

const initialState: CounterState = {
    value: 0,
    originalvalue: 2
};

const counterSlice = createSlice({
    name: "counter",
    initialState,
    reducers: {
        increment: state => {
            state.value += 1;
            state.originalvalue -= 1;
        },
        decrement: state => {
            state.value -= 1;
            state.originalvalue += 1;
        }
    }
});

export const { increment, decrement } = counterSlice.actions;
export default counterSlice.reducer;
