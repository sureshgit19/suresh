import { createSlice, PayloadAction } from "@reduxjs/toolkit";

const initialState = {
    usergroups: [],
};

const newChatSlice = createSlice({
    name: "user",
    initialState,
    reducers: {
        setUserGroup: (state, action) => {
            state.usergroups = action.payload;
        },
    }
});

export const { setUserGroup } = newChatSlice.actions;
export default newChatSlice.reducer;