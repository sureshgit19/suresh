import { createSlice, PayloadAction } from "@reduxjs/toolkit";

const initialState = {
    hasScroll: false
};

const scrollSlice = createSlice({
    name: "scroll",
    initialState,
    reducers: {
        setHasScroll: (state, action) => {
            state.hasScroll = action.payload;
        }
    }
});

export const { setHasScroll } = scrollSlice.actions;
export default scrollSlice.reducer;
