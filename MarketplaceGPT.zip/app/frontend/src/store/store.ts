import { configureStore } from "@reduxjs/toolkit";
import counterReducer from "./reducer-slice/counter.slice";
import toggleSideBarReducer from "./reducer-slice/sidebar.slice";
import scrollReducer from "./reducer-slice/chat.slice";
import bentoBoxReducer from "./reducer-slice/bentobox.slice";
import historyAbove30Days from "./reducer-slice/oldhistory.slice";
import newChatClick from "./reducer-slice/newchat.slice";
import user from "./reducer-slice/user.slice";

const store = configureStore({
    reducer: {
        counter: counterReducer,
        toggleSideBar: toggleSideBarReducer,
        chatHasSroll: scrollReducer,
        bentoBoxData: bentoBoxReducer,
        historyAbove30Days: historyAbove30Days,
        newChatClick: newChatClick,
        user: user,
    }
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export default store;
