import React, { Suspense, useEffect } from "react";
import ReactDOM from "react-dom/client";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import { Provider, useSelector } from "react-redux";
import { reactPlugin } from "./appInsights";

import "./index.css";
import "primeflex/primeflex.css";
import "primereact/resources/primereact.min.css";
import "primereact/resources/themes/saga-blue/theme.css";
// import "primereact/resources/themes/bootstrap4-dark-blue/theme.css";
import "primeicons/primeicons.css";
import "./prime-component.css";
import Layout from "./pages/layout/Layout";
import Chat from "./pages/chat/Chat";
import store from "./store/store";
import { AppInsightsContext } from "@microsoft/applicationinsights-react-js";
import { PrimeReactProvider } from "primereact/api";

import { PublicClientApplication, EventType, EventMessage, AuthenticationResult } from "@azure/msal-browser";
import { msalConfig } from "./authConfig";
import { setUserid } from "./api";
import { EmptyState } from "./components/EmptyState/EmptyState";
import { UnauthenticatedState } from "./components/UnauthenticatedState/UnauthenticatedState";

const App: React.FC = () => {
    // Instantiate MSAL outside the component tree
    const msalInstance = new PublicClientApplication(msalConfig);
    useEffect(() => {

        msalInstance.initialize().then(() => {
            console.log(import.meta.env.VITE_APP_MODE)
            // Default to using the first account if no account is active on page load
            if (!msalInstance.getActiveAccount() && msalInstance.getAllAccounts().length > 0) {
                // Account selection logic is app dependent. Adjust as needed for different use cases.
                msalInstance.setActiveAccount(msalInstance.getActiveAccount());
                setUserid(msalInstance.getActiveAccount()?.username ?? "");

            }

            // Listen for sign-in event and set active account
            msalInstance.addEventCallback((event: EventMessage) => {
                if (event.eventType === EventType.LOGIN_SUCCESS && event.payload) {
                    const payload = event.payload as AuthenticationResult;

                    setUserid(payload.account?.username ?? "");

                    msalInstance.setActiveAccount(payload.account);
                }
                if (event.eventType === EventType.HANDLE_REDIRECT_END) {
                    setUserid(msalInstance.getActiveAccount()?.username ?? "");
                }
            });
        });
    }, [])

    //enable account storage event
    msalInstance.enableAccountStorageEvents();
    const Chat = React.lazy(() => import("./pages/chat/Chat"));
    const router = createBrowserRouter([
        {
            path: "/",
            element: <Layout pca={msalInstance} />,

            children: [
                {
                    index: true,
                    element:
                        <Suspense fallback={<EmptyState title="Loading..." text="" placement="center"></EmptyState>}>
                            <Chat />
                        </Suspense>
                },
                {
                    path: "qa",
                    lazy: () => import("./pages/oneshot/OneShot")
                },
                {
                    path: "*",
                    lazy: () => import("./pages/NoPage")
                }
            ]
        }
    ]);
    const primeConfig = {
        hideOverlaysOnDocumentScrolling: true
    };

    return (
        <React.StrictMode>
            <PrimeReactProvider value={primeConfig}>
                <AppInsightsContext.Provider value={reactPlugin}>
                    <RouterProvider router={router} ></RouterProvider>
                </AppInsightsContext.Provider>
            </PrimeReactProvider>
        </React.StrictMode>
    );

}
ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(<Provider store={store}>
    <App />
</Provider>)

