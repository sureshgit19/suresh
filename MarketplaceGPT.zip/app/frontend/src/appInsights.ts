import { ApplicationInsights } from "@microsoft/applicationinsights-web";
import { ReactPlugin } from "@microsoft/applicationinsights-react-js";
import { createBrowserHistory } from "history";
import { decryptData } from "./shared/common";

// Initialize React plugin
const reactPlugin = new ReactPlugin();
let appInsights;
async function initializeChatApi() {
    await getConnectionString();
}

// Function to fetch the connection string from the server
async function getConnectionString() {
    try {
        const response = await fetch("/get_telemetry_client_key");
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        const encrypted_client_endpoint = data?.encrypted_client_endpoint ?? "";
        const connectionString = await decryptData(encrypted_client_endpoint, data?.iv, data?.key);
        //console.log("appinsight", connectionString);
        // Initialize Application Insights with the retrieved connection string
        initializeAppInsights(connectionString);
    } catch (error) {
        console.error("Error:", error);
    }
}

// Initialize Application Insights with the provided connection string
function initializeAppInsights(connectionString: string) {
    if (connectionString) {
        appInsights = new ApplicationInsights({
            config: {
                connectionString: connectionString,
                extensions: [reactPlugin],
                enableAutoRouteTracking: true,
                disableAjaxTracking: true,
                autoTrackPageVisitTime: true,
                enableCorsCorrelation: true,
                enableRequestHeaderTracking: true,
                enableResponseHeaderTracking: true
            }
        });
        appInsights.loadAppInsights();
    } else {
        console.error("Connection string is missing.");
    }
}

// Initialize the chat API
initializeChatApi();
export { reactPlugin, appInsights };
