import * as React from 'react';

import "/node_modules/primeflex/primeflex.css"
import './left-side-panel.css';
import { useMediaQuery } from '@uidotdev/usehooks';
import { Sidebar } from 'primereact/sidebar';
import { AddCircleRegular, ChatRegular, DocumentMultipleRegular, FireRegular, StarRegular } from '@fluentui/react-icons';
import { useDispatch, useSelector } from 'react-redux';
import { newchatclick } from '../store/reducer-slice/newchat.slice';
import { TabMenu } from 'primereact/tabmenu';
import { MenuItem } from 'primereact/menuitem';
import { useEffect } from 'react';

interface VerticalTabWithDrawerProps {
    // Add props here
    children: React.ReactNode[];
    options: {
        noPaddingTop: boolean;
    }
}

enum LeftPanelTabItem {
    ChatHistory = 'Chat History',
    Favorites = 'Favorites',
    Trending = 'Trending',
    Documents = 'Documents',
    NewChat = 'New Chat',
}

enum AccordionItemType {
    Last30Days = 'Last 30 Days',
    Older = 'Older',
    Favorites = 'Favorites',
    Trending = 'Trending',
    Week = 'Week',
    Month = 'Month',
}

const LeftSidePanel = (props: VerticalTabWithDrawerProps) => {
    const [openPanel, setOpenPanel] = React.useState(false);
    const [selectedTab, setSelectedTab] = React.useState(LeftPanelTabItem.ChatHistory);
    const [activeIndex, setActiveIndex] = React.useState<number>(-1);
    const [menu, setMenu] = React.useState<MenuItem[]>([]);
    const dispatch = useDispatch();
    const disableNewChat = useSelector((state: any) => state.newChatClick.disableNewChat);
    const isSmallDevice = useMediaQuery("only screen and (max-width : 768px)");
    const isMediumDevice = useMediaQuery(
        "only screen and (min-width : 769px) and (max-width : 992px)"
    );
    const isLargeDevice = useMediaQuery(
        "only screen and (min-width : 993px) and (max-width : 1200px)"
    );
    const isExtraLargeDevice = useMediaQuery(
        "only screen and (min-width : 1201px)"
    );



    const tabs: MenuItem[] = [
        {
            id: LeftPanelTabItem.ChatHistory,
            label: 'Chat History',
            icon: <ChatRegular />,
            className: "leftmenuitem",
        },
        {
            id: LeftPanelTabItem.Favorites,
            label: 'Favorites',
            icon: <StarRegular />,
            className: "leftmenuitem",
        },
        {
            id: LeftPanelTabItem.Trending,
            label: 'Trending',
            icon: <FireRegular />,
            className: "leftmenuitem",
        },
        {
            id: LeftPanelTabItem.Documents,
            label: 'Documents',
            icon: <DocumentMultipleRegular />,
            className: "leftmenuitem",
        },
        {
            id: LeftPanelTabItem.NewChat,
            label: 'New Chat',
            icon: <AddCircleRegular />,
            className: "leftmenuitem",
        },
        // Add more tabs as needed
    ];
    useEffect(() => {
        if (disableNewChat) {
            tabs.forEach((tab) => {
                if (tab.id == LeftPanelTabItem.NewChat) {
                    tab.disabled = true;
                }
            })
        }
    }, [disableNewChat])
    useEffect(() => {
        if (isSmallDevice) {
            setMenu(tabs);
        } else {
            setMenu(tabs.filter(x => x.id !== LeftPanelTabItem.NewChat));
        }
    }, [isSmallDevice])

    const handleTabClick = (tabId: any, index: number) => {

        if (tabId === LeftPanelTabItem.NewChat) {
            if (openPanel)
                setOpenPanel(false);
            dispatch(newchatclick())
            return;
        }
        setSelectedTab(tabId);
        setActiveIndex(index);
        if (selectedTab === tabId && openPanel) {
            setOpenPanel(false);
            setActiveIndex(-1)
        } else {
            setOpenPanel(true);
        }
    };

    return (
        <div
            className={`left-side-panel-container shadow-3 sticky top-0 z-2 ${props?.options?.noPaddingTop ? 'pt-0' : 'pt-5'}`}
            style={{ display: 'flex' }}
        >
            <TabMenu activeIndex={activeIndex} className='tablist gap-2 z-5 vertical-tabmenu bg-transparent' model={menu}
                style={{ width: "80px" }} onTabChange={(event) => { handleTabClick(event.value.id, event.index) }}>

            </TabMenu>
            <Sidebar
                className={`left-panel-drawer-container ${(isSmallDevice || isMediumDevice) ? '' : 'shadow-none'}`}
                appendTo={isSmallDevice || isMediumDevice ? document.body : "self"}
                visible={openPanel}
                onHide={() => setOpenPanel(false)}

                modal={isSmallDevice || isMediumDevice}
                content={<div className="w-full h-full overflow-hidden">
                    {selectedTab === LeftPanelTabItem.ChatHistory ? props?.children[0] : null}
                    {selectedTab === LeftPanelTabItem.Favorites ? props?.children[1] : null}
                    {selectedTab === LeftPanelTabItem.Trending ? props?.children[2] : null}
                    {selectedTab === LeftPanelTabItem.Documents ? props?.children[3] : null}
                </div>}
                dismissable={(isSmallDevice || isMediumDevice) ? true : false}
                maskClassName={(isSmallDevice || isMediumDevice) ? '' : 'left-panel-drawermask'}
            >

            </Sidebar>
        </div>
    );
};

export default LeftSidePanel;
