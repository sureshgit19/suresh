import * as React from 'react';

import './left-side-panel.css';



const LeftPanelTab = ({ icon, text }: { icon: JSX.Element, text: string }) => {
    return (
        <div className='w-full h-3rem flex flex-column align-items-center justify-content-center line-height-1'>
            <div className='text-md'>{icon}</div>
            <div style={{ color: "rgb(120, 125, 145)" }} className="text-xs line-height-1">{text}</div>
        </div>

    );
};

export default LeftPanelTab;
