import { ProgressSpinner } from "primereact/progressspinner";
import { useEffect, useState } from "react";

interface LoadingProps {
    placement?: "top" | "bottom" | "center";
}

export const Loading1 = ({ placement }: LoadingProps) => {
    const [flexPlacement, setFlexPlacement] = useState("flex align-items-center");

    useEffect(() => {
        switch (placement) {
            case "top":
                setFlexPlacement("flex align-items-start");
                break;
            case "bottom":
                setFlexPlacement("flex align-items-end");
                break;
            case "center":
                setFlexPlacement("flex align-items-center");
                break;
            default:
                setFlexPlacement("flex align-items-center");
                break;
        }
    }, [placement]);



    return (
        <div className={`h-full w-full flex justify-content-center bg-transparent ${flexPlacement}`}>
            <ProgressSpinner className="bg-transparent" />
        </div>
    );
};
