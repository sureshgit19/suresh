import React, { useState, useEffect } from "react";
import editbutton from "../../assets/images/notesicon.svg";
import styles from "./Notes.module.css";
import { updateHistoryDetail, UpdateHistoryRequest } from "../../api";
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { InputTextarea } from 'primereact/inputtextarea';



interface Props {
    historyItemId: string | null;
    openDialog?: boolean;
    closeDialog?: () => void;
    noteValue: string;
}

export const Notes = ({ historyItemId, openDialog, closeDialog, noteValue }: Props) => {

    const [visible, setVisible] = useState(false);

    useEffect(() => {
        setIsEditing(true);
        setVisible(openDialog ?? false);
    }, [openDialog]);

    // Update noteValue when historyItemId changes
    useEffect(() => {
        setTextareaValue(noteValue);
    }, [noteValue]);

    const dateval: Date = new Date();

    const formattedDate = (date: Date) => {
        return new Date(date).toLocaleDateString("en-US", {
            year: "numeric",
            month: "long",
            day: "numeric"
        });
    };

    const [dateValue, setDateValue] = useState(formattedDate(dateval));
    const [textareaValue, setTextareaValue] = useState(noteValue);
    const [isEditing, setIsEditing] = useState(false);

    const handleOpenChange = (_: any, data: any) => {
        if (!data.open) {
            setVisible(false);
        } else if (data.open) {
            setVisible(true);
        }
    }

    const handleTextareaChange = (event: { target: { value: any } }) => {
        setTextareaValue(event.target.value);
        // Update dateValue when the textarea changes
        setDateValue(new Date().toLocaleDateString());
    };

    const handleEditClick = () => {
        setIsEditing(true);
    };

    const handleSaveClick = () => {
        if (isEditing && textareaValue !== noteValue) {
            // Save the updated textareaValue
            const editedDateValue = new Date().toLocaleDateString();
            setDateValue(editedDateValue);

            // Save edited text in state management or API
            var historyupdate_request: UpdateHistoryRequest = {
                history_item_id: historyItemId,
                response_upvote_button: null,
                response_vote_feedback: null,
                state: null,
                title: null,
                notes: textareaValue,
            };

            const response = updateHistoryDetail(historyupdate_request);
        }

        // Close the modal without resetting editing state
        setVisible(false);
        closeDialog && closeDialog();
    };

    return (
        <Dialog onShow={() => handleOpenChange(null, { open: true })} header="Notes"
            visible={visible} draggable={false} resizable={false}
            onHide={() => { setVisible(false); closeDialog && closeDialog() }}

            footer={<div className="h-3rem"></div>}>
            <div className="grid">
                {
                    <div className="dialog-content col-12">
                        <div>{formattedDate(dateval)}</div>
                        <div className='col-12'>
                            <InputTextarea
                                placeholder={'Please Tell Us More'}
                                value={textareaValue}
                                onChange={handleTextareaChange}
                                className="feedback-textarea w-full"
                            />
                        </div>

                        <div className='grid ml-auto p-3'>
                            <Button
                                className="submit-button"
                                severity='success'
                                rounded
                                onClick={handleSaveClick}
                                label='Submit'
                            />
                        </div>
                    </div>

                }

            </div>
        </Dialog>
    );
};
