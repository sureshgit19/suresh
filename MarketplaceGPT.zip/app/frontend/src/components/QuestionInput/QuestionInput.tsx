import { useState } from "react";
import questionArrowIcon from "../../assets/images/questionarrow.svg";
import styles from "./QuestionInput.module.css";
import { InputText } from "primereact/inputtext";

import { ChatRegular } from "@fluentui/react-icons";
interface Props {
    onSend: (question: string) => void;
    disabled: boolean;
    placeholder?: string;
    clearOnSend?: boolean;
    onFocus?: () => void;
    onBlur?: () => void;
}

export const QuestionInput = ({ onSend, disabled, placeholder, clearOnSend, onFocus, onBlur }: Props) => {
    const [question, setQuestion] = useState<string>("");

    const sendQuestion = () => {
        if (disabled || !question.trim()) {
            return;
        }

        onSend(question);

        if (clearOnSend) {
            setQuestion("");
        }
    };

    const onEnterPress = (ev: React.KeyboardEvent<Element>) => {
        if (ev.key === "Enter" && !ev.shiftKey) {
            ev.preventDefault();
            sendQuestion();
        }
    };

    const onQuestionChange = (newValue?: string) => {
        if (!newValue) {
            setQuestion("");
        } else if (newValue.length <= 1000) {
            setQuestion(newValue);
        }
    };

    const sendQuestionDisabled = disabled || !question.trim();

    return (
        <div className={`grid align-items-center  ${styles.questionInputContainer}`}>
            <ChatRegular className={`col-fixed text-4xl cursor-pointer p-0 ${sendQuestionDisabled ? styles.questionInputSendButtonDisabled : ""}`} />

            <InputText
                className={`col ${styles.questionInputTextArea}`}
                placeholder={placeholder}
                value={question}
                onChange={e => onQuestionChange(e.target.value)}
                onKeyDown={onEnterPress}
                onFocus={() => onFocus && onFocus()}
                onBlur={() => onBlur && onBlur()}
                onClick={() => onFocus && onFocus()}
            />
            <div
                className={`${styles.questionInputSendButton} ${sendQuestionDisabled ? styles.questionInputSendButtonDisabled : ""}`}
                aria-label="Ask question button"
                onClick={sendQuestion}
            >
                <img src={questionArrowIcon} alt="Ask a question" className={styles.askquestionbtn} />
            </div>
        </div>
    );
};
