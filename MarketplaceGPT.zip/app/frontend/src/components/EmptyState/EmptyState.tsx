import { CloudWords48Regular } from "@fluentui/react-icons";
import { useEffect, useState } from "react";

interface EmptyStateProps {
    title?: string;
    text?: string;
    placement?: "top" | "bottom" | "center";
}

export const EmptyState = ({ title, text, placement }: EmptyStateProps) => {
    const [flexPlacement, setFlexPlacement] = useState(" align-items-center");


    useEffect(() => {
        switch (placement) {
            case "top":
                setFlexPlacement(" justify-content-start");
                break;
            case "bottom":
                setFlexPlacement(" justify-content-end");
                break;
            case "center":
                setFlexPlacement(" justify-content-center");
                break;
            default:
                setFlexPlacement(" justify-content-center");
                break;
        }
    }, [placement]);



    return (

        <div className={`grid m-0 w-full`}>
            <div className={`col-12 flex-column align-items-center text-center ${flexPlacement}`}>
                <div >
                    <CloudWords48Regular className=" text-gray-400" />
                </div>
                <h2 className="text-lg font-semibold text-gray-800">{title ?? "No data found"}</h2>
                <p className="text-sm text-gray-500">{text ?? "There is no data to display"}</p>
            </div>

        </div>

    );
};
