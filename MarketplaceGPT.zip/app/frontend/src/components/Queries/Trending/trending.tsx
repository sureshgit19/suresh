import React, { useEffect, useState } from "react";
import styles from "./trending.module.css";
import { ProgressSpinner } from "primereact/progressspinner";
import { Tooltip } from "primereact/tooltip";
import { Loading1 } from "../../Loading/loading-1";
import { EmptyState } from "../../EmptyState/EmptyState";
import { ErrorState } from "../../ErrorState/ErrorState";
import useResourceGroups from "../../../hooks/useResourceGroups";
import { useUser } from "../../../Authentication/UserProvider";
import { Accordion, AccordionTab } from "primereact/accordion";

interface ITrendingQuestion {
    questions: string[];
}

interface TrendingProps {
    className?: string;
    onTrendingClick: (value: string) => void;
}

const Trending: React.FC<TrendingProps> = ({ className, onTrendingClick }) => {
    const [trendingQuestion, setTrendingQuestion] = useState<ITrendingQuestion>({ questions: [] });
    const [showAll, setShowAll] = useState(false);
    const [activeIndex, setActiveIndex] = useState<number | null>(null);
    const [loadingTrending, setLoadingTrending] = useState(false);
    const [errorLoadingTrending, setErrorLoadingTrending] = useState<string>("");
    const [expanded, setExpanded] = useState(true);

    const user = useUser();


    useEffect(() => {

        getTrending();

    }, [user.resourceGroups]);

    const getTrending = async () => {
        setErrorLoadingTrending('');
        setLoadingTrending(true);
        try {
            const options = {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ user_security_group: user.resourceGroups }),
            };
            const response = await fetch("/trending_question", options);
            if (response.ok) {
                const responseData = await response.json();
                //console.log(responseData);
                if (Array.isArray(responseData.questions)) {
                    setTrendingQuestion(responseData);
                }
            } else {
                console.error("Failed to fetch chat history");
            }
        } catch (error) {
            console.error("Error fetching chat history", error);
            setErrorLoadingTrending(error as string);
        } finally {
            setLoadingTrending(false);
        }
    };

    const visibleQuestions = trendingQuestion.questions; //showAll ? trendingQuestion.questions : trendingQuestion.questions.slice(0, 3);

    const handleChangeActiveIndex = (index: number) => {
        setActiveIndex(index);
    };

    const handleQuestionClick = (question: string, index: number) => {
        onTrendingClick(question);
        handleChangeActiveIndex(index);
    };

    return (
        <div className={`h-full w-full`}>

            <Accordion onTabChange={() => setExpanded((last) => !last)} multiple activeIndex={expanded ? [0] : []} className="noiconaccordion w-full h-full">
                <AccordionTab
                    header={<div className="w-full">
                        Trending
                        {expanded === true ? <i className="pi pi-angle-down ml-2" /> :
                            <i className="pi pi-angle-right ml-2" />
                        }</div>}>
                    {visibleQuestions?.length > 0 && !loadingTrending && errorLoadingTrending.length === 0 ? (

                        <div className={`cursor-pointer`}>
                            {visibleQuestions.length > 0 && visibleQuestions.map((question: string, index: number) => (
                                <div
                                    key={index}
                                    className={`flex flex-column justify-content-center align-items-start p-2 h-4rem rt-list ${styles.trendinglinkline} ${index === activeIndex ? "active" : ""}`}
                                    onClick={() => handleQuestionClick(question, index)}
                                >

                                    <div id={"trending" + index} data-pr-tooltip={question} className={`${styles.clamp3} cursor-pointer line-height-1 flex flex-column justify-content-center align-items-start`}>
                                        <Tooltip target={`#${"trending" + index}`} />
                                        {question}
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : loadingTrending ? (
                        <Loading1 placement="top" />
                    ) : errorLoadingTrending.length !== 0 ? (
                        <ErrorState title="Something Went Wrong" text={errorLoadingTrending.toString() ?? "Failed To Load Trending Questions"} />
                    ) : (
                        <EmptyState placement="top" />
                    )}
                </AccordionTab>
            </Accordion>


        </div >
    );
};
export default Trending;
