import * as React from "react";
import styles from "./Queries.module.css";
import trendingDeactive from "../../assets/images/trending-deactive.svg";
import trendingActive from "../../assets/images/trending-active.svg";
import documentsDeactive from "../../assets/images/documents-deactive.svg";
import documentsActive from "../../assets/images/documents-active.svg";
import activeArrow from "../../assets/images/trending-arrow-active.svg";
import inActiveArrow from "../../assets/images/trending-arrow-deactive.svg";
import { useState } from "react";
import Trending from "./Trending/trending";
import Documents from "./Documents/Documents";
import { useSelector } from "react-redux";
interface Props {
    onTrendingClicked: (value: string) => void;
}

const Queries = ({ onTrendingClicked }: Props) => {
    const [activeIndexTrending, setActiveIndexTrending] = useState<number | null>(null);
    const [activeIndexDocuments, setActiveIndexDocuments] = useState<number | null>(null);

    const handleClickTrending = (index: number) => {
        setActiveIndexTrending(prevIndex => (prevIndex === index ? null : index));
    };

    const handleClickDocuments = (index: number) => {
        setActiveIndexDocuments(prevIndex => (prevIndex === index ? null : index));
    };

    //const hasScroll = useSelector((state: any) => state.chatHasSroll.hasScroll);
    return (
        <div className={styles.querydiv}>
            <div className={styles.title}>QUERIES</div>
            <div className={styles.querySection}>
                <div className="rt-accordion trending">
                    <div className="rt-accordion-item">
                        <div className={`rt-accordion-header ${activeIndexTrending === 0 ? "active" : ""}`} onClick={() => handleClickTrending(0)}>
                            <img className="arrow-icon" src={activeIndexTrending === 0 ? trendingActive : trendingDeactive} alt="" />
                            <span className="rt-title">Trending</span>
                            <img className="arrow-icon" src={activeIndexTrending === 0 ? activeArrow : inActiveArrow} alt="" />
                        </div>
                        {activeIndexTrending === 0 && <Trending onTrendingClick={onTrendingClicked}></Trending>}
                    </div>
                </div>
            </div>
            <div className={styles.querySection}>
                <div className="rt-accordion document">
                    <div className="rt-accordion-item">
                        <div className={`rt-accordion-header ${activeIndexDocuments === 1 ? "active" : ""}`} onClick={() => handleClickDocuments(1)}>
                            <img className="arrow-icon" src={activeIndexDocuments === 1 ? documentsActive : documentsDeactive} alt="Documents Icon" />
                            <span className="rt-title">Documents</span>
                            <img className="arrow-icon" src={activeIndexDocuments === 1 ? activeArrow : inActiveArrow} alt="" />
                        </div>
                        {activeIndexDocuments === 1 && <Documents></Documents>}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Queries;
