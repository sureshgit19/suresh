import React, { PropsWithChildren, useEffect, useState } from "react";
import styles from "./Documents.module.css";
import { getdocuments } from "../../../api";
import { DocumentsModel } from "../../../api/models";
import { Loading1 } from "../../Loading/loading-1";
import useResourceGroups from "../../../hooks/useResourceGroups";
import { ErrorState } from "../../ErrorState/ErrorState";
import { EmptyState } from "../../EmptyState/EmptyState";
import { useUser } from "../../../Authentication/UserProvider";

interface DateRangeModel {
    FirstDate: Date;
    LastDate: Date;
}
export const Documents = (props: { className?: string }) => {
    const [isMonthClicked, setMonthClicked] = useState(false);
    const [isWeekClicked, setWeekClicked] = useState(false);
    const [documentlist, setDocumentList] = useState<DocumentsModel[] | null>(null);
    const [apiresponse, setDocumentApiResponse] = useState<DocumentsModel[]>();
    const [loadingDocuments, setLoadingDocuments] = useState(false);
    const [errors, setErrors] = useState<string[]>([]);

    const user = useUser();

    useEffect(() => {
        toggleFilterButton("ALL");
    }, [apiresponse]);

    useEffect(() => {
        setLoadingDocuments(true);
        if (user.resourceGroups) {
            getdata();
        }
    }, [user.resourceGroups]);

    const getdata = async () => {

        try {
            const responseData = await getdocuments(user.resourceGroups);
            setDocumentApiResponse(responseData);
            setDocumentApiResponse(responseData ?? []);
        } catch (error) {
            console.error("Error fetching Documents", error);
            setErrors(["Failed to load documents"]);
        } finally {
            setLoadingDocuments(false);
        }
    };
    const toggleFilterButton = (operation: string) => {
        if (operation == "ALL") {
            setDocumentList(apiresponse ?? []);
        } else {
            var daterange = GetRangeOfDates(operation);

            const filterlist = apiresponse?.filter(md => {
                const mod_date = new Date(md["Modified On"]);
                return mod_date >= daterange.FirstDate && mod_date <= daterange.LastDate;
            })
                .map(x => {
                    return x;
                });

            setDocumentList(filterlist ?? []);
        }
        if (operation === "WEEK") {
            setWeekClicked(true);
            setMonthClicked(false);
        } else if (operation === "MONTH") {
            setWeekClicked(false);
            setMonthClicked(true);
        } else {
            setWeekClicked(false);
            setMonthClicked(false);
        }
    };

    function GetRangeOfDates(operation: string) {
        if (operation === "WEEK") {
            var currentdate = new Date();
            var first = currentdate.getDate() - currentdate.getDay();
            var last = first + 6;
            var firstday = new Date(currentdate.setDate(first));
            var lastday = new Date(currentdate.setDate(last));
            firstday.setHours(0, 0, 0, 0);
            lastday.setHours(23, 59, 59, 0);
            const response: DateRangeModel = { FirstDate: firstday, LastDate: lastday };
            return response;
        } else {
            var currentdate = new Date();
            var firstday = new Date(currentdate.getFullYear(), currentdate.getMonth(), 1);
            firstday.setHours(0, 0, 0, 0);
            currentdate.setHours(23, 59, 59, 0);
            const response: DateRangeModel = { FirstDate: firstday, LastDate: currentdate };
            return response;
        }
    }

    return (
        <>
            <div className={` h-full ${styles.documentsContainer} rt-accordion-content-documents h-full w-full pr-3 pl-3 pt-3`}>
                <div className={styles.filterDiv}>
                    <button className={isWeekClicked ? styles.filterItemClicked : styles.filterItem} onClick={() => toggleFilterButton(!isWeekClicked ? "WEEK" : "ALL")}>
                        Week
                    </button>
                    <button className={isMonthClicked ? styles.filterItemClicked : styles.filterItem} onClick={() => toggleFilterButton(!isMonthClicked ? "MONTH" : "ALL")}>
                        Month
                    </button>
                </div>
                {documentlist && documentlist.length > 0 ? (
                    <div>

                        <div className="h-full w-full">
                            {documentlist?.map((file, i) => (
                                <div>
                                    <hr className={styles.documentlinkline}></hr>
                                    <div className={styles.documentlinksItem}>
                                        <a href={file.PathURL} target="_blank">
                                            {" "}
                                            {file.FileName}{" "}
                                        </a>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                ) : loadingDocuments ? (
                    <Loading1 placement="top" />
                ) : errors.length !== 0 ? (
                    <ErrorState title="Something Went Wrong" text={errors[0] ?? "Failed To Load Trending Questions"} />
                ) : (
                    <EmptyState placement="top" />
                )
                }
            </div>
        </>

    );
};

export default Documents;
