import React, { useEffect, useRef } from "react";
import notificationImage from "../../assets/images/notification.svg";
import notificationActiveImage from "../..//assets/images/notification-active.svg";
import styles from "./Notifications.module.css";
import { NotificationData } from "../../api/models";
import { getNotifications } from "../../api";
import { Menu } from "primereact/menu";
import { MenuItem } from "primereact/menuitem";

export default function NotificationsMenu() {
    const [notificationsLoaded, setNotificationsLoaded] = React.useState(false);
    const [hasNotifications, setHasNotifications] = React.useState(false);
    const [menuItems, setNotificationItems] = React.useState<MenuItem[]>([]);

    const getNotificationsData = async () => {
        var notifications: NotificationData[] = await getNotifications();
        const items: MenuItem[] = [];

        notifications.forEach((element: NotificationData, idx: number) => {
            const itemkey = "Item" + idx;
            const item: MenuItem = {
                label: element.title,
                template: itemRenderer,
                data: element,
                id: itemkey,
                url: element.url,
                target: "_blank",
                icon: 'pi pi-file',
            };
            items.push(item);
        });
        if (items.length > 0) {
            setHasNotifications(true);
        }

        setNotificationItems(items);
        setNotificationsLoaded(true);
    };

    useEffect(() => {
        if (!notificationsLoaded) {
            getNotificationsData();
        }
    }, [notificationsLoaded]);

    const itemRenderer = (item: any) => (
        <div className="grid p-menuitem-link pt-2 gap-3 grid-nogutter p-menuitem-content" onClick={() => {
            window.open(item.url, item.target);
        }}>
            {(item.icon != "" || item.image != "") && <div className="col-1 pl-1">
                {(item.icon && item.icon != "") && <i className={`${item.icon} text-2xl`} />}
                {(item.image && item.image != "" && item.icon == "") && <img src={item.image} />}
            </div>
            }
            <div className="col-10">
                <div className="text-overflow-ellipsis white-space-nowrap overflow-hidden font-bold text-black-alpha-90 text-sm">{item.label}</div>
                <div className="text-overflow-ellipsis white-space-nowrap overflow-hidden text-sm">{item.data?.content}</div>
                <small>{item.data?.notificationDate}</small>
            </div>
        </div>
    );
    const menuRight = useRef<Menu>(null);
    return (
        <>
            <img
                src={hasNotifications ? notificationActiveImage : notificationImage}
                className={styles.notificationImage}
                alt="Notifications"
                onClick={(event) => {
                    menuItems.length && menuRight?.current?.toggle(event)
                }} aria-controls="popup_menu_right" aria-haspopup
            />
            <Menu className={styles.notificationwidth} model={menuItems} popup ref={menuRight} id="popup_menu_right" popupAlignment="right" />
        </>
    );
}
