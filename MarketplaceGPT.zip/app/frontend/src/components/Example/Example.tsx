import styles from "./Example.module.css";

interface Props {
    text: string;
    value: string;
    badgeText?: string;
    documentUrl?: string;
    onClick: (value: string) => void;
}

export const Example = ({ text, value, badgeText, documentUrl, onClick }: Props) => {
    const isDocument = badgeText === "Documents";
    return (
        <>
            {isDocument ? (
                <p className={styles.exampleText}>
                    <a href={documentUrl} target="_blank" rel="noopener noreferrer">
                        {text}
                    </a>
                </p>
            ) : (
                <div className="textdivbox" onClick={() => onClick(value)}>
                    <p className={styles.exampleText}>{text}</p>
                </div>
            )}
            ;
        </>
    );
};
