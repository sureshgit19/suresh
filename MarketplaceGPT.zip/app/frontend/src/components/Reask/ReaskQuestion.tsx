import styles from "./ReaskQuestion.module.css";
import reaskImage from "../../assets/images/reaskicon.svg";

interface Props {
    suggested_question: string;
    onReaskQuestionClicked: (value: string) => void;
}

export const ReaskQuestion = ({ suggested_question, onReaskQuestionClicked }: Props) => {
    return (
        <div className={styles.reaskquestion}>
            <img src={reaskImage} alt="" className={styles.reaskimage} />
            <div className={styles.reaskquestioncontent} onClick={() => onReaskQuestionClicked(suggested_question)}>
                Are you looking for {suggested_question}
            </div>
        </div>
    );
};

export default ReaskQuestion;
