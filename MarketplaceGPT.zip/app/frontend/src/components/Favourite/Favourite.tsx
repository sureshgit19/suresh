import React, { useState, useEffect, useRef } from "react";
import styles from "./Favourite.module.css";
import icondelete from "../../assets/images/icondelete.svg";
import iconshare from "../../assets/images/iconshare.svg";
import iconwrite from "../../assets/images/iconwrite.svg";
import { ChatItem, HistoryProps } from "../../api/models";
import { updateOriginalResponse, getUserId } from "../../api/api";
import { parseBoolean } from "../../shared/common";
import { Tooltip } from "primereact/tooltip";
import { EmptyState } from "../EmptyState/EmptyState";
import { Loading1 } from "../Loading/loading-1";
import { Accordion, AccordionTab } from "primereact/accordion";
import HeaderTemplate from "../History/accordion-header";

export function FavouritesList(props: HistoryProps) {
    const [favourites, setFavourites] = useState<ChatItem[]>([]);
    const [editedItems, setEditedItems] = useState<Record<string, boolean>>({});
    const textBoxRef = useRef<HTMLInputElement | null>(null);
    const [initialChatHistory, setInitialChatHistory] = useState<ChatItem[]>([]);
    const [loadingFavorites, setLoadingFavorites] = useState(false);
    const [openItems, setOpenItems] = useState<number[]>([0]);
    const [toggleFavSort, setToggleFavSort] = useState<boolean>(true);

    useEffect(() => {
        getFavouriteList();
    }, [props.refreshComponent]);

    useEffect(() => {
        setfilterChat();
    }, [toggleFavSort, initialChatHistory]);

    const getFavouriteList = async () => {
        setLoadingFavorites(true);
        try {
            const response = await fetch(`/get_user_favorites/${getUserId()}`);
            if (response.ok) {
                const responseData = await response.json();
                if (Array.isArray(responseData)) {
                    responseData.forEach(x => {
                        x["new_answer_av"] = parseBoolean(x["new_answer_av"]);
                    });
                    setInitialChatHistory(responseData);
                }
            } else {
                console.error("Failed to fetch favourites");
            }
        } catch (error) {
            console.error("Error fetching favourites", error);
        } finally {
            setLoadingFavorites(false);
        }
    };

    function setfilterChat() {
        if (initialChatHistory.length) {
            if (toggleFavSort) {
                const sortedarray = initialChatHistory.filter(x => x.new_answer_av);
                sortedarray.push(...initialChatHistory.filter(x => !x.new_answer_av));
                setFavourites(sortedarray);
            } else {
                setFavourites(initialChatHistory);
            }
        }
    }
    const updateChatItem = (id: string, newTitle: string, status: string, notes: string) => {
        const updatedChatHistory = favourites.map(chatItem =>
            chatItem.history_item_id === id ? { ...chatItem, title: newTitle, state: status, notes: notes } : chatItem
        );

        setFavourites(updatedChatHistory);
        setEditedItems({ ...editedItems, [id]: false });

        sendUpdateRequest(id, newTitle, status, notes);
    };

    const sendUpdateRequest = (id: string, newTitle: string, status: string, notes: string) => {
        fetch(`/update_history_detail`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                history_item_id: id,
                title: newTitle,
                state: status,
                notes: notes,
                response_upvote_button: "NOVOTE"
            })
        })
            .then(response => {
                if (response.ok) {
                    //console.log("Item Updated Successfully");
                } else {
                    console.error("Failed to update data. Status", response.status);
                }
                return response.json();
            })
            .catch(error => {
                console.error("Error updating data:", error);
            });
    };

    const handleEditClick = (id: string) => {
        setEditedItems({ ...editedItems, [id]: true });
        textBoxRef.current?.focus();
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, id: string) => {
        if (e.key === "Enter") {
            const editedTitle = (e.target as HTMLInputElement).value;
            const chatItem = favourites.find(item => item.history_item_id === id);
            if (chatItem) {
                updateChatItem(id, editedTitle, chatItem.state, chatItem.notes || "");
            }
        }
    };

    const handleDelete = (id: string) => {
        const chatItem = favourites.find(item => item.history_item_id === id);
        if (chatItem) {
            const updatedChatHistory = favourites.map(chatItem => (chatItem.history_item_id === id ? { ...chatItem, state: "deleted" } : chatItem));

            setFavourites(updatedChatHistory);
            setEditedItems({ ...editedItems, [id]: false });

            sendUpdateRequest(id, chatItem.title, "deleted", chatItem.notes || "");
        }
    };

    const handleTextBoxBlur = (id: string) => {
        if (editedItems[id]) {
            const editedTitle = textBoxRef.current?.value || "";
            const chatItem = favourites.find(item => item.history_item_id === id);
            if (chatItem) {
                updateChatItem(id, editedTitle, chatItem.state, chatItem.notes || "");
            }
        }
    };
    const handleShareClick = (chatItem: ChatItem) => {
        props.onShare && props.onShare(chatItem);
    };

    const handleClick = (chatItem: ChatItem) => {
        if (chatItem.new_answer_av === true) {
            updateOriginalResponse(chatItem.history_item_id);
            chatItem.new_answer_av = false;
        }
        props.onItemClick && props.onItemClick(chatItem, "Favourite");
    };

    return (
        <div className={` ${props.className} w-full h-full`}>
            {favourites.length > 0 && !loadingFavorites ? (
                <>

                    <Accordion multiple activeIndex={openItems} className="noiconaccordion favaccordion w-full" onTabChange={e => setOpenItems(e.index as any)}>
                        <AccordionTab
                            header={
                                <HeaderTemplate
                                    headerText="Favorites"
                                    openItems={openItems.includes(0)}
                                    toggleSort={toggleFavSort}
                                    setToggleSort={setToggleFavSort}
                                ></HeaderTemplate>
                            }
                        >
                            {
                                favourites.map((item, index) => {
                                    if (item.state === "deleted") return null;
                                    return (
                                        <div className={`${styles.chathistorydata} ${item.new_answer_av ? styles.greenborder : ""}`} key={item.history_item_id}>
                                            <i className="pi pi-star-fill" style={{ color: '#787D91', stroke: '#787D91', fontSize: '0.8rem', marginRight: '3px' }} />
                                            <div className={styles.chatlist}>
                                                {editedItems[item.history_item_id] ? (
                                                    <input
                                                        type="text"
                                                        ref={textBoxRef}
                                                        defaultValue={item.title || item.user}
                                                        onBlur={() => handleTextBoxBlur(item.history_item_id)}
                                                        onKeyDown={e => handleKeyDown(e, item.history_item_id)}
                                                        className={styles.editField}
                                                    />
                                                ) : (
                                                    <>
                                                        <Tooltip target={`#${"fav" + index}`} />
                                                        <span id={"fav" + index} className={styles.elipsis} onClick={() => handleClick(item)} data-pr-tooltip={item.title || item.user}>
                                                            {item.title || item.user}
                                                        </span>
                                                    </>
                                                )}
                                            </div>

                                            {!editedItems[item.history_item_id] && (
                                                <div className={styles.iconlist}>
                                                    <img src={iconwrite} alt="Edit" onClick={() => handleEditClick(item.history_item_id)} />
                                                    <img src={iconshare} alt="Share" onClick={() => handleShareClick(item)} />
                                                    <img src={icondelete} alt="Delete" onClick={() => handleDelete(item.history_item_id)} />
                                                </div>
                                            )}
                                        </div>
                                    );
                                })

                            }
                        </AccordionTab>
                    </Accordion>
                </>
            ) : loadingFavorites ? (
                <Loading1 placement="top" />
            ) : (
                <EmptyState placement="center" title={"No Favorites Yet"} text={"Favorite Chat Responses To See Them Here"} />
            )}
        </div>
    );
}
