import { useMsal } from "@azure/msal-react";
import { CloudWords48Regular } from "@fluentui/react-icons";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { loginRequest } from "../../authConfig";

interface UnauthenticatedStateProps {
    title?: string;
    text?: string;
    placement?: "top" | "bottom" | "center";
}

export const UnauthenticatedState = ({ title, text, placement }: UnauthenticatedStateProps) => {
    const [flexPlacement, setFlexPlacement] = useState(" align-items-center");

    const { instance } = useMsal();
    const navigate = useNavigate();
    instance.handleRedirectPromise().then(response => {
        if (response && response.account) {
            sessionStorage.setItem("accesstoken", response.accessToken);
        }
    });
    if (instance.getAllAccounts().length === 0) {
        instance.loginRedirect(loginRequest).catch(error => console.error(error));
    }


    useEffect(() => {
        switch (placement) {
            case "top":
                setFlexPlacement(" justify-content-start");
                break;
            case "bottom":
                setFlexPlacement(" justify-content-end");
                break;
            case "center":
                setFlexPlacement(" justify-content-center");
                break;
            default:
                setFlexPlacement(" justify-content-center");
                break;
        }
    }, [placement]);





    return (

        <div className={`grid m-0 w-full`}>
            <div className={`col-12 flex-column align-items-center ${flexPlacement}`}>
                <div>
                    <CloudWords48Regular style={{ transform: "scale(2)" }} className="fadeinleft text-gray-400" />
                </div>
                < h2 className="text-lg font-semibold text-gray-800" > {title}</h2>
                < p className="text-sm text-gray-500" > {text}</p>
            </div>
        </div>
    );
};
