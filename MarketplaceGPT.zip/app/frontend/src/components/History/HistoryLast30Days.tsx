import React, { useState, useEffect, useRef } from "react";
import styles from "./History.module.css";
import icondelete from "../../assets/images/icondelete.svg";
import iconshare from "../../assets/images/iconshare.svg";
import iconwrite from "../../assets/images/iconwrite.svg";
import { ChatItem, HistoryProps } from "../../api/models";
import { updateOriginalResponse, getUserId } from "../../api/api";
import { parseBoolean } from "../../shared/common";
import { Tooltip } from "primereact/tooltip";
import { ProgressSpinner } from "primereact/progressspinner";
import { EmptyState } from "../EmptyState/EmptyState";
import { ComponentStatus } from "../../models/models";
import { ErrorState } from "../ErrorState/ErrorState";

export function HistoryLast30Days(props: HistoryProps) {
    const [chatHistory, setChatHistory] = useState<ChatItem[] | null>(null);
    const [editedItems, setEditedItems] = useState<Record<string, boolean>>({});
    const textBoxRef = useRef<HTMLInputElement | null>(null);
    const [initialChatHistory, setInitialChatHistory] = useState<ChatItem[] | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [componentStatus, setComponentStatus] = useState<ComponentStatus>(ComponentStatus.Loading);

    useEffect(() => {
        if (chatHistory === null) setComponentStatus(ComponentStatus.Loading);
        if (chatHistory !== null && chatHistory.length === 0) setComponentStatus(ComponentStatus.NoContent);
        if (chatHistory !== null && chatHistory.length > 0) setComponentStatus(ComponentStatus.Loaded);
        if (error !== null) setComponentStatus(ComponentStatus.Error);
    }, [chatHistory, error]);

    useEffect(() => {
        last30daysChatHistory();
    }, [props.refreshLast30DaysComponent]);

    useEffect(() => {
        const item = initialChatHistory?.find(x => x.history_item_id == props.historyUpdatedData?.history_item_id);
        if (item) {
            item.response_upvote_button = props.historyUpdatedData?.response_upvote_button ?? undefined;
            setInitialChatHistory([...initialChatHistory ?? []]);
        }
    }, [props.historyUpdatedData?.history_item_id, props.historyUpdatedData?.response_upvote_button]);

    useEffect(() => {
        setfilterChat();
    }, [props.toggleFilter, initialChatHistory]);

    const last30daysChatHistory = async () => {
        try {
            const response = await fetch(`/get_login_data/${getUserId()}/last30days`);
            if (response.ok) {
                const responseData = await response.json();
                if (Array.isArray(responseData)) {
                    responseData.forEach(x => {
                        x["new_answer_av"] = parseBoolean(x["new_answer_av"]);
                    });

                    setInitialChatHistory(responseData);
                }
            } else {
                setError("Failed to fetch chat history");
                console.error("Failed to fetch chat history");
            }
        } catch (error) {
            setInitialChatHistory([]);
            setError(error as string);
            console.error("Error fetching chat history", error);
        } finally {
            setfilterChat();
        }
    };

    function setfilterChat() {
        if (props.toggleFilter && initialChatHistory) {
            const sortedarray = initialChatHistory.filter(x => x.new_answer_av);
            sortedarray.push(...initialChatHistory.filter(x => !x.new_answer_av));
            setChatHistory(sortedarray);
        } else if (initialChatHistory) {
            setChatHistory(initialChatHistory);
        }

    }

    const updateChatItem = (id: string, newTitle: string, status: string, notes: string) => {
        const updatedChatHistory = chatHistory?.map(chatItem =>
            chatItem.history_item_id === id ? { ...chatItem, title: newTitle, state: status, notes: notes } : chatItem
        );

        setChatHistory(updatedChatHistory || []);
        setEditedItems({ ...editedItems, [id]: false });

        sendUpdateRequest(id, newTitle, status, notes);
    };

    const sendUpdateRequest = (id: string, newTitle: string, status: string, notes: string) => {
        fetch(`/update_history_detail`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                history_item_id: id,
                title: newTitle,
                state: status,
                notes: notes,
                response_upvote_button: "NOVOTE"
            })
        })
            .then(response => {
                if (response.ok) {
                    //console.log("Item Updated Successfully");
                } else {
                    console.error("Failed to update data. Status", response.status);
                }
                return response.json();
            })
            .catch(error => {
                console.error("Error updating data:", error);
            });
    };

    const handleEditClick = (id: string) => {
        setEditedItems({ ...editedItems, [id]: true });
        textBoxRef.current?.focus();
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, id: string) => {
        if (e.key === "Enter") {
            const editedTitle = (e.target as HTMLInputElement).value;
            const chatItem = chatHistory?.find(item => item.history_item_id === id);
            if (chatItem) {
                updateChatItem(id, editedTitle, chatItem.state, chatItem.notes || "");
            }
        }
    };

    const handleDelete = (id: string) => {
        const chatItem = chatHistory?.find(item => item.history_item_id === id);
        if (chatItem) {
            const updatedChatHistory = chatHistory?.map(chatItem => (chatItem.history_item_id === id ? { ...chatItem, state: "deleted" } : chatItem));

            setChatHistory(updatedChatHistory ?? []);
            setEditedItems({ ...editedItems, [id]: false });

            sendUpdateRequest(id, chatItem.title, "deleted", chatItem.notes || "");
        }
    };

    const handleTextBoxBlur = (id: string) => {
        if (editedItems[id]) {
            const editedTitle = textBoxRef.current?.value || "";
            const chatItem = chatHistory?.find(item => item.history_item_id === id);
            if (chatItem) {
                updateChatItem(id, editedTitle, chatItem.state, chatItem.notes || "");
            }
        }
    };

    const handleShareClick = (chatItem: ChatItem) => {
        const sharedText = `Question: ${chatItem.user}\nAnswer: ${parseBoolean(chatItem.new_answer_av) ? chatItem.new_answer : chatItem.bot}\nNotes: ${chatItem.notes
            }`;
        props.onShare && props.onShare(sharedText);
    };

    const handleClick = (chatItem: ChatItem) => {
        if (chatItem.new_answer_av === true) {
            updateOriginalResponse(chatItem.history_item_id);
            chatItem.new_answer_av = false;
        }

        props.onItemClick && props.onItemClick(chatItem, "historylast30days");
    };

    return (
        <div className={styles.scrollablelast30}>
            {componentStatus === ComponentStatus.Loaded ? chatHistory?.map((chatItem, index) => {
                if (chatItem.state === "deleted") return null;

                return (
                    <div className={`${styles.chathistorydata} ${chatItem.new_answer_av ? styles.greenborder : ""}`} key={chatItem.history_item_id}>
                        <div className={styles.chatlist}>
                            {editedItems[chatItem.history_item_id] ? (
                                <input
                                    type="text"
                                    ref={textBoxRef}
                                    defaultValue={chatItem.title || chatItem.user}
                                    onBlur={() => handleTextBoxBlur(chatItem.history_item_id)}
                                    onKeyDown={e => handleKeyDown(e, chatItem.history_item_id)}
                                    className={styles.editField}
                                />
                            ) : (
                                <>
                                    <span
                                        id={"history30days" + index}
                                        className={styles.elipsis}
                                        onClick={() => handleClick(chatItem)}
                                        data-pr-tooltip={chatItem.title || chatItem.user}
                                    >
                                        {chatItem.title || chatItem.user}
                                    </span>
                                    <Tooltip target={`#${"history30days" + index}`} />
                                </>
                            )}
                        </div>

                        {!editedItems[chatItem.history_item_id] && (
                            <div className={styles.iconlist}>
                                <img src={iconwrite} alt="Edit" onClick={() => handleEditClick(chatItem.history_item_id)} />
                                <img src={iconshare} alt="Share" onClick={() => handleShareClick(chatItem)} />
                                <img src={icondelete} alt="Delete" onClick={() => handleDelete(chatItem.history_item_id)} />
                            </div>
                        )}
                    </div>
                );
            }) : componentStatus === ComponentStatus.NoContent ? (
                <EmptyState placement="top" title={"No Recent History"} text={""} />
            ) : componentStatus === ComponentStatus.Loading ? (
                <div className="flex align-items-center">
                    <ProgressSpinner />
                </div>
            ) : componentStatus === ComponentStatus.Error ? (
                <ErrorState title="Something Went Wrong" text={error ?? "Failed To Load History"} />
            ) : null
            }
        </div>
    );
}
