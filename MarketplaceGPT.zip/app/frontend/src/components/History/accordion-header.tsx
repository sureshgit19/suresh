import React from "react";

interface HeaderProps {
    headerText: string;
    openItems: boolean;
    toggleSort: boolean;
    setToggleSort: React.Dispatch<React.SetStateAction<boolean>>;
}

const HeaderTemplate: React.FC<HeaderProps> = ({ headerText, openItems, toggleSort, setToggleSort }) => {
    return (
        <div style={{ display: "flex", alignItems: "center" }}>
            <span>{headerText}</span>

            {openItems ? (
                <>
                    <i className="pi pi-angle-down ml-2"></i>
                    <div
                        style={{ paddingLeft: ".5rem", paddingRight: ".5rem", cursor: "default" }}
                        onClick={event => {
                            event.preventDefault();
                            event.stopPropagation();
                        }}
                    >
                        <i
                            className="pi pi-sliders-h ml-2 cursor-pointer"
                            onClick={event => {
                                setToggleSort(!toggleSort);
                                event.preventDefault();
                                event.stopPropagation();
                            }}
                        ></i>
                    </div>
                </>
            ) : (
                <i className="pi pi-angle-right ml-2"></i>
            )}
        </div>
    );
};

export default HeaderTemplate;
