import React, { useState, useEffect, useRef } from "react";
import styles from "./History.module.css";
import "./History.css";

import { HistoryAbove30Days } from "./HistoryAbove30Days";
import { HistoryLast30Days } from "./HistoryLast30Days";
import { ChatItem } from "../../api";
import { HistoryProps, SideBarIcon } from "../../api/models";
import { FavouritesList } from "../Favourite/Favourite";
import sliderIcon from "../../assets/images/slider.svg";
import sidebarcloseicon from "../../assets/images/sidebar-collapse.svg";
import { useDispatch, useSelector } from "react-redux";
import { setSideBarOpenState } from "../../store/reducer-slice/sidebar.slice";
import { Accordion, AccordionTab } from "primereact/accordion";
import HeaderTemplate from "./accordion-header";
import { Dialog, DialogProps } from "primereact/dialog";

export function History(props: HistoryProps) {
    const dispatch = useDispatch();

    const [sharedText, setSharedText] = useState<string>("");
    const [isMessageVisible, setMessageVisible] = useState<boolean>(false);
    const [chatHistory, setChatHistory] = useState<ChatItem[]>([]);
    const [openItems, setOpenItems] = useState<number[]>([0]);
    const [toggleHistorySort, setToggleHistorySort] = useState<boolean>(true);
    const [toggleFavSort, setToggleFavSort] = useState<boolean>(true);
    const [toggleOlderHistorySort, setToggleOlderHistorySort] = useState<boolean>(true);

    const copyTextToClipboard = (text: string) => {
        navigator.clipboard
            .writeText(text)
            .then(() => {
                //console.log("Text copied to clipboard:", text);
                setSharedText(text);
                showMessage();
            })
            .catch(error => {
                console.error("Error copying text to clipboard:", error);
            });
    };
    const showMessage = () => {
        setMessageVisible(true);
        setTimeout(() => setMessageVisible(false), 5000);
    };

    const onItemClick = (chatItem: ChatItem, source: string) => {
        props.onItemClick && props.onItemClick(chatItem, source);
    };

    return (
        <div className={styles.historydiv}>

            {isMessageVisible && (
                <Dialog
                    header="Item copied to clipboard! You can share it now"
                    visible={isMessageVisible}
                    resizable={false}
                    draggable={false}
                    style={{ width: "50vw" }}
                    onHide={() => setMessageVisible(false)}
                    footer={<div className="h-3rem"></div>}
                >
                    {sharedText}
                </Dialog>
            )}
            {(
                <div className={styles.ChatListhistory}>
                    <Accordion multiple activeIndex={openItems} className="noiconaccordion border-none" onTabChange={e => setOpenItems(e.index as any)}>
                        <AccordionTab contentClassName="accordion-tab-content"
                            header={
                                <HeaderTemplate
                                    headerText="Last 30 Days"
                                    openItems={openItems.includes(0)}
                                    toggleSort={toggleHistorySort}
                                    setToggleSort={setToggleHistorySort}
                                ></HeaderTemplate>
                            }
                        >
                            <HistoryLast30Days
                                onShare={copyTextToClipboard}
                                onItemClick={onItemClick}
                                toggleFilter={toggleHistorySort}
                                refreshLast30DaysComponent={props.refreshLast30DaysComponent}
                                historyUpdatedData={props.historyUpdatedData}
                            ></HistoryLast30Days>
                        </AccordionTab>
                        <AccordionTab
                            header={
                                <HeaderTemplate
                                    headerText="Older"
                                    openItems={openItems.includes(1)}
                                    toggleSort={toggleOlderHistorySort}
                                    setToggleSort={setToggleOlderHistorySort}
                                ></HeaderTemplate>
                            }
                        >
                            <HistoryAbove30Days
                                onShare={copyTextToClipboard}
                                onItemClick={onItemClick}
                                toggleFilter={toggleOlderHistorySort}
                                historyUpdatedData={props.historyUpdatedData}
                            ></HistoryAbove30Days>
                        </AccordionTab>
                    </Accordion>
                </div>
            )}
        </div>
    );
}
