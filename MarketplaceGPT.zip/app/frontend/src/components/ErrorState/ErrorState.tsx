import { ErrorCircle48Regular } from "@fluentui/react-icons";
import { useEffect, useState } from "react";

interface ErrorStateProps {
    title?: string;
    text?: string;
    placement?: "top" | "bottom" | "center";
}

export const ErrorState = ({ title, text, placement }: ErrorStateProps) => {
    const [flexPlacement, setFlexPlacement] = useState("flex align-items-center");


    useEffect(() => {
        switch (placement) {
            case "top":
                setFlexPlacement("flex justify-content-start");
                break;
            case "bottom":
                setFlexPlacement("flex justify-content-start");
                break;
            case "center":
                setFlexPlacement("flex justify-content-start");
                break;
            default:
                setFlexPlacement("flex justify-content-start");
                break;
        }
    }, [placement]);



    return (

        <div className={`flex flex-column ${flexPlacement} align-items-center h-full w-full line-height-1`}>
            <div>
                <ErrorCircle48Regular style={{ width: '30px', height: '30px' }} className="w-full h-full text-gray-400" />
            </div>
            <h2 className="text-lg font-semibold text-gray-800">{title ?? "Something Went Wrong"}</h2>
            <p className="text-sm text-gray-500">{text}</p>
        </div>

    );
};
