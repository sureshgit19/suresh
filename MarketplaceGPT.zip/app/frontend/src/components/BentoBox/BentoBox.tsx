
import { useEffect, useState } from "react";
import { IBentoModel, fetchBentoBoxData } from "../../api";
import { Bento } from "./Bento";
import { useUser } from "../../Authentication/UserProvider";


interface Props {
    onBentoClicked: (value: string) => void;
}

export const BentoBox = ({ onBentoClicked: onBentoClicked }: Props) => {
    const [bentoData, setBentoData] = useState<IBentoModel[]>([]);

    const user = useUser();

    useEffect(() => {
        if (user.resourceGroups) {
            fetchBentoBoxData(user.resourceGroups).then((data) => {
                setBentoData(data);
            }).catch((error) => {
                console.error("Error fetching Bento Box data", error);
            });
        }
    }, [user.resourceGroups]);


    const bgColors = [
        "bg-blue-50",
        "bg-green-50",
        "bg-yellow-50",
        "bg-red-50",
        "bg-purple-50",
        "bg-indigo-50",
    ]

    const badgeColors = [
        "bg-blue-100",
        "bg-green-100",
        "bg-yellow-100",
        "bg-red-100",
        "bg-purple-100",
        "bg-indigo-100",
    ]

    const badgeBorderColors = [
        "border-blue-400",
        "border-green-400",
        "border-yellow-400",
        "border-red-400",
        "border-purple-300",
        "border-indigo-300",
    ]

    const badgeTextColor = [
        "text-blue-800",
        "text-green-800",
        "text-yellow-800",
        "text-red-800",
        "text-purple-800",
        "text-indigo-800",
    ]


    return (
        <div className="grid gap-3 md:w-full bento-box justify-content-center w-full">
            {
                [1, 2, 3, 4, 5, 6].map((x, i) => (
                    <div key={i} className={"w-3 md:w-3 sm:w-12 xs:w-12 cursor-pointer"}>
                        <Bento key={i}
                            text={bentoData[i]?.text ?? ''}
                            type={bentoData[i]?.badgeText ?? 'none'}
                            value={bentoData[i]?.text ?? ''}
                            badgeText={bentoData[i]?.badgeText ?? ''}
                            documentUrl={bentoData[i]?.documentUrl ?? ''}
                            bgColor={bgColors[i] ?? 'white'}
                            badgeBorderColor={badgeBorderColors[i]}
                            badgeColor={badgeColors[i]}
                            badgeTextColor={badgeTextColor[i]}
                            onClick={onBentoClicked} />
                    </div>
                ))
            }

        </div>
    );
};
