import { Chip } from 'primereact/chip';
import styles from './Bento.module.css';
import { ProgressSpinner } from 'primereact/progressspinner';
interface Props {
    text: string;
    value: string;
    type: string;
    badgeText: string;
    documentUrl?: string;
    bgColor?: string;
    badgeColor?: string;
    badgeBorderColor?: string;
    badgeTextColor?: string;
    onClick: (value: string) => void;
}

export const Bento = ({ text, value, type, badgeText, documentUrl, bgColor, badgeBorderColor, badgeColor, badgeTextColor, onClick }: Props) => {

    return (
        <>
            {(() => {
                switch (type) {
                    case "Trending":
                        return (
                            <div className={`${styles.bento} w-full h-full text-black-alpha-80 flex flex-column align-items-center justify-content-start p-2 ${bgColor}`} onClick={() => onClick(value)}>
                                {text ? (
                                    <>
                                        <Chip className={`flex align-self-start ${badgeColor} ${badgeBorderColor} ${badgeTextColor} border-1`} label={badgeText?.length > 0 ? badgeText : "-"} icon={() =>
                                            <svg width="20" height="20" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M4.8505 0.5C4.90503 1.28162 5.08681 1.99417 5.39582 2.63764C5.70483 3.28112 6.13018 3.88278 6.67186 4.44264C7.11175 4.90071 7.44803 5.3915 7.6807 5.915C7.91337 6.43851 8.03152 7.02381 8.03516 7.67092C8.03516 8.22715 7.93155 8.74701 7.72433 9.23053C7.5171 9.71404 7.23172 10.1376 6.86818 10.5011C6.50463 10.8647 6.0811 11.15 5.59759 11.3573C5.11407 11.5645 4.59239 11.6681 4.03253 11.6681C3.66171 11.6681 3.30544 11.6208 2.9637 11.5263C2.62197 11.4318 2.30387 11.2973 2.0094 11.1228C1.71493 10.9483 1.44591 10.7392 1.20233 10.4957C0.958755 10.2521 0.751534 9.98125 0.580668 9.68314C0.409802 9.38504 0.275291 9.06512 0.177134 8.72338C0.0789764 8.38165 0.0317156 8.02538 0.035351 7.65456C0.035351 7.29465 0.0826118 6.94202 0.177134 6.59665C0.271655 6.25128 0.415255 5.92591 0.607934 5.62053C0.684279 5.77322 0.766076 5.92409 0.853327 6.07314C0.940578 6.2222 1.04055 6.35489 1.15325 6.47122C1.26595 6.58756 1.39683 6.6839 1.54588 6.76024C1.69493 6.83659 1.86398 6.87294 2.05302 6.86931C2.21662 6.86931 2.37113 6.8384 2.51654 6.7766C2.66196 6.7148 2.7892 6.62937 2.89827 6.5203C3.00733 6.41124 3.09458 6.284 3.16002 6.13858C3.22546 5.99316 3.25818 5.83866 3.25818 5.67506C3.25818 5.52964 3.23636 5.40058 3.19274 5.28789C3.14911 5.17519 3.08731 5.05885 3.00733 4.93888C2.83283 4.66986 2.69468 4.40447 2.59289 4.14272C2.4911 3.88097 2.4402 3.58468 2.4402 3.25385C2.4402 2.90848 2.502 2.57948 2.62561 2.26683C2.74921 1.95418 2.91826 1.67425 3.13275 1.42704C3.34724 1.17983 3.60173 0.974426 3.8962 0.810831C4.19067 0.647236 4.50877 0.543625 4.8505 0.5ZM4.03253 10.9701C4.3379 10.9701 4.63238 10.9319 4.91594 10.8556C5.19951 10.7792 5.46308 10.6684 5.70665 10.5229C5.95023 10.3775 6.17199 10.2066 6.37194 10.0103C6.57189 9.81402 6.74457 9.59226 6.88999 9.34505C7.03541 9.09784 7.14447 8.83427 7.21718 8.55434C7.28989 8.27441 7.32988 7.97994 7.33715 7.67092C7.33715 7.13651 7.23899 6.64209 7.04268 6.18766C6.84636 5.73323 6.55916 5.31333 6.18108 4.92798C5.69029 4.43719 5.2813 3.89914 4.95411 3.31384C4.62692 2.72853 4.39789 2.09233 4.26701 1.40523C4.09615 1.49611 3.94164 1.60699 3.80349 1.73787C3.66535 1.86875 3.54538 2.01598 3.44358 2.17958C3.34179 2.34317 3.26545 2.51586 3.21455 2.69763C3.16365 2.8794 3.13639 3.06844 3.13275 3.26476C3.13275 3.4429 3.15275 3.60286 3.19274 3.74464C3.23273 3.88642 3.28362 4.0173 3.34543 4.13727C3.40723 4.25724 3.47267 4.37357 3.54174 4.48627C3.61081 4.59897 3.67807 4.71348 3.74351 4.82982C3.80895 4.94615 3.85984 5.07339 3.8962 5.21154C3.93255 5.34969 3.95255 5.5042 3.95618 5.67506C3.95618 5.93681 3.9071 6.18221 3.80895 6.41124C3.71079 6.64027 3.57446 6.84022 3.39996 7.01109C3.22546 7.18195 3.02369 7.31828 2.79466 7.42008C2.56562 7.52187 2.31841 7.57095 2.05302 7.56731C1.57315 7.56731 1.15143 7.40553 0.787889 7.08198C0.75517 7.27466 0.73881 7.46734 0.73881 7.66002C0.73881 8.11808 0.824243 8.54707 0.995109 8.94697C1.16598 9.34686 1.40046 9.69769 1.69857 9.99943C1.99668 10.3012 2.34568 10.5375 2.74558 10.7083C3.14548 10.8792 3.57446 10.9665 4.03253 10.9701Z"
                                                    fill="#07133F"
                                                />
                                            </svg>} />
                                        <div className='p-1 flex align-items-center justify-content-center flex-1 text-center'>
                                            <p className={`text-sm ${badgeTextColor}`}>{text}</p>
                                        </div>
                                    </>
                                ) :
                                    <ProgressSpinner strokeWidth='2' />
                                }
                            </div>
                        )

                    case "Documents":
                        return (<a href={documentUrl} target="_blank" rel="noopener noreferrer">
                            <div className={`${styles.bento} w-full h-full text-black-alpha-80 flex flex-column align-items-center justify-content-start p-2 ${bgColor}`} >

                                <Chip className={`flex align-self-start ${badgeColor} ${badgeBorderColor} ${badgeTextColor} border-1`} label={badgeText?.length > 0 ? badgeText : "-"} icon={'pi pi-file'} />
                                <div className='p-1 flex align-items-center justify-content-center flex-1 text-center'>
                                    <p className={`text-sm ${badgeTextColor}`}>{text}</p>
                                </div>
                            </div>

                        </a>)

                    case "Popular":
                        return (<div rel="noopener noreferrer">
                            <div className={`${styles.bento} w-full h-full text-black-alpha-80 flex flex-column align-items-center justify-content-start p-2 ${bgColor}`} onClick={() => onClick(value)}>

                                <Chip className={`flex align-self-start ${badgeColor} ${badgeBorderColor} ${badgeTextColor} border-1`} label={badgeText?.length > 0 ? badgeText : "-"} icon="pi pi-star" />
                                <div className='p-1 flex align-items-center justify-content-center flex-1 text-center'>
                                    <p className={`text-sm ${badgeTextColor}`}>{text}</p>
                                </div>
                            </div>

                        </div>)

                    default:
                        return (<div className="h-full w-full">
                            <div className={`${styles.bento} w-full h-full flex flex-column align-items-center justify-content-start p-2 ${bgColor}`} onClick={() => onClick(value)}>
                                {text ? (
                                    <>
                                        <Chip className={`flex align-self-start ${badgeColor} ${badgeBorderColor} ${badgeTextColor} border-1`} label={badgeText?.length > 0 ? badgeText : "-"} icon="pi pi-info-circle" />
                                        <div className='p-1 flex align-items-center justify-content-center flex-1 text-center'>
                                            <p className={`text-sm ${badgeTextColor}`}>{text}</p>
                                        </div>
                                    </>
                                ) :
                                    <div className='w-full h-full flex align-items-center justify-content-center'>
                                        <ProgressSpinner style={{ width: '240px', height: '150px' }} className='flex ' strokeWidth='2' />
                                    </div>
                                }
                            </div>
                        </div>
                        )


                }
            })()}
        </>
    );
};
