import styles from "./UserChatMessage.module.css";
import personIcon from "../../assets/images/personicon.svg";
interface Props {
    message: string;
}

export const UserChatMessage = ({ message }: Props) => {
    return (
        <div className={styles.questioncontainer}>
            <img src={personIcon} alt="" className="imagequestion" />
            <div className={styles.message}>{message}</div>
        </div>
    );
};
