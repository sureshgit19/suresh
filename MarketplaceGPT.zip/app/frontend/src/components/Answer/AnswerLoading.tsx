import { animated, useSpring } from "@react-spring/web";

import styles from "./Answer.module.css";
import { AnswerIcon } from "./AnswerIcon";

export const AnswerLoading = () => {
    const animatedStyles = useSpring({
        from: { opacity: 0 },
        to: { opacity: 1 }
    });

    return (
        <animated.div style={{ ...animatedStyles }}>
            <div className={`${styles.answerContainer} 'space-between'`}>
                {/*  <AnswerIcon /> */}
                <div>
                    {/*    <p className={styles.answerText}>
                        Generating answer
                        <span className={styles.loadingdots} />
                    </p> */}

                    <div className={styles.loadingtext}>
                        <div className={styles.loadingAnimation}>
                            <svg width="156" height="18" viewBox="0 0 156 18" fill="none">
                                <circle cx="9" cy="9" r="9" fill="#7B919C" />
                                <circle cx="32" cy="9" r="9" fill="#7B919C" />
                                <circle cx="55" cy="9" r="9" fill="#A0B0B8" />
                                <circle cx="78" cy="9" r="9" fill="#A0B0B8" fillOpacity="0.68" />
                                <circle cx="101" cy="9" r="9" fill="#CED7DB" />
                                <circle cx="124" cy="9" r="9" fill="#CED7DB" fillOpacity="0.58" />
                                <circle cx="147" cy="9" r="9" fill="#E3E8EA" fillOpacity="0.53" />
                            </svg>
                        </div>
                        Generating answer
                    </div>
                </div>
            </div>
        </animated.div>
    );
};
