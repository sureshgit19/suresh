import { useEffect, useState } from "react";
import ThumbsDownDialog, { DialogState, ThumbsDownIssue, VoteDirection } from "./ThumbsDownDialog";
import { AskResponse } from "../../api";
import likeActiveImage from "../../assets/images/thumsupactive.svg";
import likeInactiveImage from "../../assets/images/thumsup.svg";
import { ThumbsUpVote } from "./ThumbsUp";
import useFeedback, { UpdateHistoryResponse } from "../../hooks/useFeedback";
import { set } from "immer/dist/internal";

interface Props {
    answer: AskResponse;
    newAnswerStyles: boolean
}

export const FeedbackVotes = ({
    answer,
    newAnswerStyles
}: Props) => {
    const answerId = answer.arhistory_id!;
    const previousVoteDirection = answer?.vote?.split(':')[0] as VoteDirection;
    const previouslySelectedRadio = answer?.vote?.split(':')[1]?.toLowerCase() as ThumbsDownIssue;
    const [vote, setVote] = useState<VoteDirection>(previousVoteDirection ?? VoteDirection.NoVote);
    const [issue, setIssue] = useState<ThumbsDownIssue>(previouslySelectedRadio ?? ThumbsDownIssue.None);
    const [comment, setComment] = useState<string>(answer?.response_vote_feedback ?? "");

    const { upvoteRequest, downvoteRequest, clearVoteRequest } = useFeedback();

    // Immediately set the state then change it to reflect the server response
    const submitVote = (vote: VoteDirection, issue?: ThumbsDownIssue, comment?: string): Promise<UpdateHistoryResponse> => {
        if (vote) setVote(vote);
        if (issue) setIssue(issue);
        if (comment) setComment(comment);

        let result;
        if (vote === VoteDirection.UpVote) {
            result = upvoteRequest(answerId);
        } else if (vote === VoteDirection.DownVote) {
            result = downvoteRequest(answerId, issue ?? ThumbsDownIssue.None, comment ?? "");
        } else if (vote === VoteDirection.NoVote) {
            result = clearVoteRequest(answerId);
        } else {
            console.error("Invalid Vote Direction");
            result = Promise.reject("Invalid Vote Direction");
        }

        return result.then((response: UpdateHistoryResponse) => {
            setVote(response.vote);
            setIssue(response.issue);
            setComment(response.voteFeedback);
            return response;
        });
    }

    const clearVote = (): Promise<UpdateHistoryResponse> => {
        setVote(VoteDirection.NoVote);
        setIssue(ThumbsDownIssue.None);
        setComment("");

        return clearVoteRequest(answerId).then((response: UpdateHistoryResponse) => {
            setVote(response.vote);
            setIssue(response.issue);
            setComment(response.voteFeedback);
            return response;
        });
    }


    return (
        // replace styles with prime flex
        <div style={{ display: 'flex', justifyContent: "space-evenly", alignItems: "center", width: "50px" }}>
            <ThumbsUpVote vote={vote} submitVote={submitVote} newAnswerStyles={newAnswerStyles} />
            <ThumbsDownDialog
                vote={vote}
                issue={issue} setIssue={setIssue}
                comment={comment} setComment={setComment}
                submitVote={submitVote} clearVote={clearVote}
                newAnswerStyles={newAnswerStyles}
            />
        </div>
    );
};
