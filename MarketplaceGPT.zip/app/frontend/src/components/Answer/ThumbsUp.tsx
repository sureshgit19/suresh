import { useState } from "react";
import { VoteDirection } from "./ThumbsDownDialog";
import likeActiveImage from "../../assets/images/thumsupactive.svg";
import likeInactiveImage from "../../assets/images/thumsup.svg";
import { UpdateHistoryResponse } from "../../hooks/useFeedback";
import { ProgressSpinner } from "primereact/progressspinner";
import { Tooltip } from "primereact/tooltip";


enum ControlState {
    Idle = "idle",
    Submitting = "submitting",
    Success = "success",
    Error = "error",
    Closed = "closed",
}

interface Props {
    vote: VoteDirection,
    newAnswerStyles: boolean
    submitVote: (vote: VoteDirection) => Promise<UpdateHistoryResponse>
}

export const ThumbsUpVote = ({
    vote,
    newAnswerStyles,
    submitVote,
}: Props) => {
    const [controlState, setControlState] = useState(ControlState.Idle);

    const handleClick = () => {
        submitVote(vote === VoteDirection.UpVote ? VoteDirection.NoVote : VoteDirection.UpVote).then(() => {
            setControlState(ControlState.Success);
        }).catch(() => {
            setControlState(ControlState.Error);
        });
    }

    return (
        <>
            {controlState === ControlState.Submitting ?
                (<span><ProgressSpinner />Loading...</span>)
                :
                vote === VoteDirection.NoVote || vote === VoteDirection.DownVote ?
                    (

                        <a className="cursor-on-hover"
                            onClick={handleClick}
                        >
                            <img src={likeInactiveImage} alt="UpVote Inactive" />
                        </a>

                    )
                    :
                    (
                        <>
                            <Tooltip target={'#upvote'} />
                            <a className="cursor-on-hover" id="upvote" data-pr-tooltip="Up Vote"
                                onClick={handleClick}
                            >
                                {vote === VoteDirection.UpVote ? <img src={likeActiveImage} alt="UpVote Active" /> : <img src={likeInactiveImage} alt="UpVote Inactive" />}
                            </a>
                        </>
                    )}
        </>
    );
};
