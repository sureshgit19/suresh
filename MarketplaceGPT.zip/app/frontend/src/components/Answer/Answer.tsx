import { useEffect, useMemo, useState, useRef } from "react";
import DOMPurify from "dompurify";
import styles from "./Answer.module.css";

import { AskResponse, getCitationFilePath, updateHistoryDetail, UpdateHistoryRequest } from "../../api";
import { parseAnswerToHtml } from "./AnswerParser";
import { AnswerIcon } from "./AnswerIcon";
import answerImage from "../../assets/images/answerIcon.svg";
import citationicon from "../../assets/images/citationicon.svg";
import dilikeActiveImage from "../../assets/images/thumsdownactive.svg";
import dislikeInactiveImage from "../../assets/images/thumsdown.svg";
import likeActiveImage from "../../assets/images/thumsupactive.svg";
import likeInactiveImage from "../../assets/images/thumsup.svg";
import favIcon from "../../assets/images/favourite.svg";
import editbutton from "../../assets/images/notesicon.svg";
import { getFileNameFromUrl, getUserId } from "../../api/api";
import iconshare from "../../assets/images/iconshare.svg";
import firstResponseImg from "../../assets/images/first-response.svg";
import secondResponseImg from "../../assets/images/second-response.svg";
import React from "react";
import { RadioButton } from "primereact/radiobutton";
import { Dialog } from "primereact/dialog";
import { Tooltip } from "primereact/tooltip";
import ThumbsDownDialog, { ThumbsDownIssue, VoteDirection } from "./ThumbsDownDialog";
import useFeedback from "../../hooks/useFeedback";
import { FeedbackVotes } from "./FeedbackVotes";

interface Props {
    answer: AskResponse;
    isSelected?: boolean;
    isStreaming: boolean;
    onCitationClicked: (filePath: string) => void;
    onThoughtProcessClicked: () => void;
    onSupportingContentClicked: () => void;
    onFollowupQuestionClicked?: (question: string) => void;
    showFollowupQuestions?: boolean;
    favListRefresh?: () => void;
    openNoteDialog?: (open: boolean) => void;
    shareClick?: (newAnswer: boolean) => void;
    onNotesClick?: (historyItemId: string) => void;
    onLikeDislikeClick?: (updateHistoryRequest: UpdateHistoryRequest) => void;
    answerLoading?: boolean;
    loadingStream?: boolean;
    voteOptions?: any;
}

export const Answer = ({
    answer,
    isSelected,
    isStreaming,
    onCitationClicked,
    onThoughtProcessClicked,
    onSupportingContentClicked,
    onFollowupQuestionClicked,
    showFollowupQuestions,
    favListRefresh,
    openNoteDialog,
    shareClick,
    onNotesClick,
    onLikeDislikeClick,
    answerLoading,
    loadingStream,
    voteOptions
}: Props) => {
    const [favRefresh, setFavRefresh] = useState(false);
    const [favActive, setFavActive] = useState(false);
    const [secondResponse, setSecondResponse] = useState(true);

    const config = {
        ADD_ATTR: ["target"]
    };
    let parsedAnswer = useMemo(
        () =>
            parseAnswerToHtml(
                secondResponse && !(!answer.new_answer_av || answer.new_answer_av.trim() === "") ? answer.new_answer_av ?? answer.answer : answer.answer,
                isStreaming,
                answer.data_points,
                onCitationClicked
            ),
        [answer, secondResponse]
    );
    let sanitizedAnswerHtml = DOMPurify.sanitize(parsedAnswer.answerHtml, config);
    const [vote, setVote] = useState<VoteDirection>(VoteDirection.NoVote);
    const firstRender = useRef(true);
    const [streamingQuestion, setStreamingQuestion] = useState(loadingStream);
    const [slideIn, setSlideIn] = useState(true);

    useEffect(() => {
        if (firstRender.current) {
            firstRender.current = false;
            if (answer.vote?.includes("UpVote")) {
                setVote(VoteDirection.UpVote);
            } else if (answer.vote?.includes("DownVote")) {
                setVote(VoteDirection.DownVote);
            } else {
                setVote(VoteDirection.NoVote);
            }
            if (answer.isFavourite) setFavActive(true);
            else setFavActive(false);
        }
    }, [answer]);

    const handleFavouriteClick = (history_item_id: string) => {
        if (history_item_id) {
            toggleFavourite(history_item_id);
        }
    };

    const toggleFavourite = async (history_item_id: string) => {
        const response = await fetch(`/toggle_favorite/${getUserId()}/${history_item_id}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({})
        });
        if (response.ok) {
            //console.log("Item Updated Successfully");
            const responseData = await response.json();
            if (typeof favListRefresh === "function") {
                favListRefresh();
            }
            if (responseData?.status && responseData?.status == "added") {
                setFavActive(true);
            } else {
                setFavActive(false);
            }
            setFavRefresh(!favRefresh);
        } else {
            console.error("Failed to update data. Status", response.status);
        }
    };

    const toggleResponse = () => {
        setSecondResponse(!secondResponse);
        setTimeout(() => {
            setSlideIn(false);
            //console.log("toggleresponse" + !secondResponse);
            setTimeout(() => {
                setSlideIn(true);
            }, 2000);
        }, 0);
    };

    const getformatedDate = (value?: string) => {
        if (value) {
            let dateArray = [];
            if (value.includes("T")) {
                dateArray = value.split("T")[0]?.split("-");
            } else {
                dateArray = value.split(" ")[0]?.split("-");
            }
            if (dateArray[2].length > 2) {
                dateArray = value.substring(0, 10).split("-");
            }
            if (dateArray) return dateArray[1] + "/" + dateArray[2] + "/" + dateArray[0];
        }
        return "";
    };

    const [upvoteOptions, setUpvoteOptions] = React.useState<any[]>([]);
    const [downvoteOptions, setDownvoteOptions] = React.useState<any[]>([]);
    const [downVoteTooltipVisible, setDownVoteTooltipVisible] = useState<boolean>(false);
    const [upvoteTooltipVisible, setUpvoteTooltipVisible] = useState<boolean>(false);


    const onVoteDialogClose = ({ issue, comment }: { issue: ThumbsDownIssue, comment?: string }) => {
        if (issue === ThumbsDownIssue.None) {
            setVote(VoteDirection.NoVote);
        } else {
            setVote(VoteDirection.DownVote);
        }
    };

    return (
        <div className={styles.answerbox}>
            <img src={answerImage} alt="" className={styles.ansimage} />
            <div
                className={`grid ${styles.answerContainer} ${isSelected && styles.selected} ${slideIn ? "" : "slideInClass"} 
                ${secondResponse && !(!answer.new_answer_av || answer.new_answer_av.trim() === "") ? styles.newAnswerStyles : ""}`}
            >
                <div className={`col-12`}>
                    <div className={`${styles.iconDiv} col-11`}>
                        <span className={styles.dateLabel}>
                            {secondResponse && !(!answer.new_answer_av || answer.new_answer_av.trim() === "")
                                ? getformatedDate(answer.new_answer_date)
                                : getformatedDate(answer.created)}
                        </span>
                        <FeedbackVotes answer={answer} newAnswerStyles={secondResponse && !(!answer.new_answer_av || answer.new_answer_av.trim() === "")} />
                    </div>
                </div>

                <div className="col-12">
                    <div className={styles.answerText} dangerouslySetInnerHTML={{ __html: sanitizedAnswerHtml }}></div>
                </div>
                <div className="col-12">
                    {answerLoading && streamingQuestion ? (
                        <div className={`${styles.tp} ${styles.loadingAnimation}`}>
                            <svg width="61" height="10" viewBox="0 0 61 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="4.88846" cy="4.88846" r="4.88846" fill="#23E292" />
                                <circle cx="17.6654" cy="4.88846" r="4.88846" fill="#48E7A4" />
                                <circle cx="30.4423" cy="4.88846" r="4.88846" fill="#6DECB6" />
                                <circle cx="43.2192" cy="4.88846" r="4.88846" fill="#94F1CA" />
                                <circle cx="55.9962" cy="4.88846" r="4.88846" fill="#94F1CA" fill-opacity="0.55" />
                            </svg>
                        </div>
                    ) : null}
                </div>

                {!!parsedAnswer.citations.length && (
                    <div className="col-12">
                        <div className="grid gap-1">
                            <img src={citationicon} alt="" />
                            <span className={styles.citationLearnMore}>Citations:</span>
                            {parsedAnswer.citations.map((x, i) => {
                                // const filename = getFileNameFromUrl(x);

                                return (
                                    <a key={i} className={styles.citation} title={x.Url} href={x.Url} target="_blank">
                                        {`${++i}. ${x.FileName}`}
                                    </a>
                                );
                            })}
                        </div>
                    </div>
                )}

                {!!parsedAnswer.followupQuestions.length && showFollowupQuestions && onFollowupQuestionClicked && (
                    <div className="col-12">
                        <div className={`${!!parsedAnswer.citations.length ? styles.followupQuestionsList : ""} grid gap-1`}>
                            <span className={styles.followupQuestionLearnMore}>Follow-up questions:</span>
                            {parsedAnswer.followupQuestions.map((x, i) => {
                                return (
                                    <a key={i} className={styles.followupQuestion} title={x} onClick={() => onFollowupQuestionClicked(x)}>
                                        {`${x}`}
                                    </a>
                                );
                            })}
                        </div>
                    </div>
                )}
                <div className={styles.ansBotSetction}>
                    <div className={styles.favEditIcon + " flex"}>
                        <a href="javascript:void(0);" onClick={() => handleFavouriteClick(answer.arhistory_id ?? "")}>
                            <i className="pi pi-star-fill" style={{ color: favActive ? '#13192E' : '#787D91', stroke: favActive ? '#13192E' : '#787D91', fontSize: '0.8rem', marginRight: '3px' }} />
                        </a>
                        <a href="javascript:void(0);" onClick={() => onNotesClick && onNotesClick(answer.arhistory_id ?? "")}>
                            <i className="pi pi-pen-to-square" style={{ color: '#787D91', stroke: '#787D91', fontSize: '0.8rem', marginRight: '3px' }} />
                        </a>
                        <a
                            href="javascript:void(0);"
                            onClick={() => shareClick && shareClick(secondResponse && !(!answer.new_answer_av || answer.new_answer_av.trim() === ""))}
                        >
                            <i className="pi pi-share-alt" style={{ color: '#787D91', stroke: '#787D91', fontSize: '0.8rem', marginRight: '3px' }} />
                        </a>
                    </div>
                    {!(!answer.new_answer_av || answer.new_answer_av.trim() === "") ? (
                        <div className={styles.responseName}>
                            {secondResponse ? (
                                <img src={firstResponseImg} alt="response 1" onClick={toggleResponse} style={{ cursor: "pointer" }} />
                            ) : (
                                <img src={secondResponseImg} alt="response 2" onClick={toggleResponse} style={{ cursor: "pointer" }} />
                            )}
                        </div>
                    ) : null}
                </div>
            </div>
        </div>
    );
};
