import styles from "./Answer.module.css";

interface Props {
    error: string;
    onRetry: () => void;
}

export const AnswerError = ({ error, onRetry }: Props) => {
    return (
        <div className={styles.answerContainer}>
            {/* <ErrorCircle24Regular aria-hidden="true" aria-label="Error icon" primaryFill="red" /> */}

            <div>
                <p className={styles.answerText}>{error}</p>
            </div>

            {/* <PrimaryButton className={styles.retryButton} onClick={onRetry} text="Retry" /> */}
        </div>
    );
};
