import * as React from 'react';
import { useState } from 'react';
import dislikeActiveImage from '../../assets/images/thumsdownactive.svg';
import dislikeInactiveImage from '../../assets/images/thumsdown.svg';
import './ThumbsDownDialog.css';
import useFeedback, { UpdateHistoryResponse } from '../../hooks/useFeedback';
import { AskResponse } from '../../api';
import { Dialog } from 'primereact/dialog';
import { Tooltip } from 'primereact/tooltip';
import { ProgressSpinner } from 'primereact/progressspinner';
import { Button } from 'primereact/button';
import { RadioButton } from 'primereact/radiobutton';
import { InputTextarea } from 'primereact/inputtextarea';


export enum ThumbsDownIssue {
    Incorrect = 'incorrect',
    OutOfDate = 'out_of_date',
    Irrelevant = 'irrelevant',
    Inappropriate = 'inappropriate',
    None = 'none',
}

export enum VoteDirection {
    UpVote = 'UpVote',
    DownVote = 'DownVote',
    NoVote = 'NoVote',
}
export enum DialogState {
    Idle = "idle",
    Loading = "loading",
    Submitting = "submitting",
    Success = "success",
    Error = "error",
    Closed = "closed",
}


interface ThumbsDownDialogProps {
    vote: string;
    issue: ThumbsDownIssue;
    newAnswerStyles: boolean;
    setIssue: (issue: ThumbsDownIssue) => void;
    comment: string;
    setComment: (comment: string) => void;
    submitVote: (vote: VoteDirection, issue: ThumbsDownIssue, comment: string) => Promise<UpdateHistoryResponse>;
    clearVote: () => Promise<UpdateHistoryResponse>;
}

const ThumbsDownDialog = ({ vote, issue, newAnswerStyles, setIssue, comment, setComment, submitVote, clearVote }: ThumbsDownDialogProps) => {

    const [dialogState, setDialogState] = useState(DialogState.Idle);
    const [dialogTitle, setDialogTitle] = useState("Tell us how to improve this response.");
    const [visible, setVisible] = useState(false);
    const handleClear = (ev: any) => {
        setDialogState(DialogState.Submitting);
        ev.stopPropagation();
        clearVote().then(() => {
            setDialogState(DialogState.Idle);
            setComment("");
        }).catch(() => {
            setDialogState(DialogState.Error);
        });
    };

    const handleSubmit = () => {
        setDialogState(DialogState.Submitting);
        submitVote(VoteDirection.DownVote, issue, comment).then(() => {
            setDialogState(DialogState.Success);
            changeDialogTitle();
        }).catch(() => {
            setDialogState(DialogState.Error);
        });
    };

    const handleOpenChange = (_: any, data: any) => {
        if (!data.open) {
            setDialogState(DialogState.Closed);
            setVisible(false);
        } else if (data.open) {
            setDialogState(DialogState.Idle);
        }

    }

    const formatIssue = (issue: ThumbsDownIssue) => {
        switch (issue) {
            case ThumbsDownIssue.Incorrect:
                return "Incorrect";
            case ThumbsDownIssue.OutOfDate:
                return "Out of Date";
            case ThumbsDownIssue.Irrelevant:
                return "Irrelevant";
            case ThumbsDownIssue.Inappropriate:
                return "Inappropriate";
            default:
                return "";
        }
    }
    function changeDialogTitle() {
        if (dialogState === DialogState.Success) {
            setDialogTitle("Thank you for your feedback.")
        } else {
            setDialogTitle("Tell us how to improve this response.")
        }
    }

    return (
        <>
            {issue && Object.values(ThumbsDownIssue).includes(issue) && issue !== ThumbsDownIssue.None ? (
                <>
                    <Tooltip target={`.thumbs-down`} />
                    <a className="thumbs-down" data-pr-tooltip={formatIssue(issue)} onClick={() => setVisible(true)}>
                        {vote === VoteDirection.DownVote ? (
                            <img src={dislikeActiveImage} alt="DownVote Active" />
                        ) : (
                            <img src={dislikeInactiveImage} alt="DownVote Inactive" />
                        )}
                    </a>
                </>
            ) : (
                <a className="thumbs-down" onClick={() => setVisible(true)}>
                    {vote === VoteDirection.DownVote ? (
                        <img src={dislikeActiveImage} alt="DownVote Active" />
                    ) : (
                        <img src={dislikeInactiveImage} alt="DownVote Inactive" />
                    )}
                </a>
            )
            }
            <Dialog onShow={() => handleOpenChange(null, { open: true })} header={dialogTitle}
                visible={visible} draggable={false} resizable={false}
                className='thumbsdowndialog w-full md:w-6'
                footer={<div className="additional-help-notice col-12">
                    <i className='pi pi-envelope' />
                    <span> Please contact <a href="mailto:MDEA-support@microsoft.com">MDEA support</a> for further assistance.</span>
                </div>}
                onHide={() => { handleOpenChange(null, { open: false }); changeDialogTitle(); }}>

                <div className="grid">
                    {
                        dialogState === DialogState.Error ? (
                            <div className="col-12 justify-content-center px-2">
                                <span>Something went wrong. Please try again.</span>
                            </div>
                        ) : dialogState === DialogState.Success ? (
                            <div className="col-12">
                                <div className="h-2rem">

                                </div>
                                <div className="col-12 justify-content-center">
                                    <span>Your feedback has been submitted successfully.</span>
                                </div>
                                <div className='dialog-actions justify-content-center'>
                                    <Button onClick={() => setVisible(false)}
                                        className="submit-button"
                                        severity="success"
                                        rounded
                                        label='Close'
                                    />
                                </div>
                            </div>
                        ) : dialogState === DialogState.Loading ? (
                            <div className="col-12 justify-content-center align-items-center">
                                <span>Loading...</span>
                                <ProgressSpinner className='m-0' />
                            </div>
                        ) : dialogState === DialogState.Submitting ? (
                            <div className="col-12 justify-content-center align-items-center">
                                <ProgressSpinner />
                            </div>
                        ) : (

                            <div className="dialog-content col-12">
                                <div className="flex align-items-center">
                                    <RadioButton inputId={ThumbsDownIssue.Incorrect} name="category" value={ThumbsDownIssue.Incorrect} onChange={(data) =>
                                        setIssue(data.value as ThumbsDownIssue)
                                    } checked={issue === ThumbsDownIssue.Incorrect} />
                                    <label className="ml-2" htmlFor={ThumbsDownIssue.Incorrect}>
                                        Incorrect
                                    </label>
                                </div>
                                <div className="flex align-items-center">
                                    <RadioButton inputId={ThumbsDownIssue.OutOfDate} name="category" value={ThumbsDownIssue.OutOfDate} onChange={(data) =>
                                        setIssue(data.value as ThumbsDownIssue)
                                    } checked={issue === ThumbsDownIssue.OutOfDate} />
                                    <label className="ml-2" htmlFor={ThumbsDownIssue.OutOfDate}>
                                        Out of Date
                                    </label>
                                </div>
                                <div className="flex align-items-center">
                                    <RadioButton name="category" inputId={ThumbsDownIssue.Irrelevant} value={ThumbsDownIssue.Irrelevant} onChange={(data) =>
                                        setIssue(data.value as ThumbsDownIssue)
                                    } checked={issue === ThumbsDownIssue.Irrelevant} />
                                    <label className="ml-2" htmlFor={ThumbsDownIssue.Irrelevant}>
                                        Irrelevant
                                    </label>
                                </div>
                                <div className="flex align-items-center">
                                    <RadioButton name="category" inputId={ThumbsDownIssue.Inappropriate} value={ThumbsDownIssue.Inappropriate} onChange={(data) =>
                                        setIssue(data.value as ThumbsDownIssue)
                                    } checked={issue === ThumbsDownIssue.Inappropriate} />
                                    <label className="ml-2" htmlFor={ThumbsDownIssue.Inappropriate}>
                                        Inappropriate
                                    </label>
                                </div>

                                <div className='col-12'>
                                    <InputTextarea
                                        placeholder={'Please Tell Us More'}
                                        value={comment}
                                        onChange={(data) => setComment(data.target.value)}
                                        className="feedback-textarea w-full"
                                    />
                                </div>
                                <div className='dialog-actions grid gap-2'>
                                    <Button label='Clear' className='col-fixed w-2' rounded onClick={(_) => handleClear(_)} disabled={dialogState !== DialogState.Idle}>

                                    </Button>

                                    <Button
                                        className="submit-button col-fixed w-2"
                                        severity='success'
                                        rounded
                                        disabled={dialogState !== DialogState.Idle}
                                        onClick={handleSubmit}
                                        label='Submit'
                                    >

                                    </Button>

                                </div>
                            </div>
                        )
                    }
                </div>

            </Dialog>
        </>
    );
};

export default ThumbsDownDialog;
