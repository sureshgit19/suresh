import { renderToStaticMarkup } from "react-dom/server";
import { getCitationFilePath } from "../../api";
import { createHyperlink, isTabularData, splitNestedBrackets, tabularToHtml } from "../../shared/common";

type citation = {
    FileName: string;
    Url: string;
};

type HtmlParsedAnswer = {
    answerHtml: string;
    citations: citation[];
    followupQuestions: string[];
};

export function parseAnswerToHtml(
    answer: string,
    isStreaming: boolean,
    data_points: string[],
    onCitationClicked: (citationFilePath: string) => void
): HtmlParsedAnswer {
    const citations: citation[] = [];
    const followupQuestions: string[] = [];

    // Extract any follow-up questions that might be in the answer
    let parsedAnswer = answer.replace(/<<([^>>]+)>>/g, (match, content) => {
        followupQuestions.push(content);
        return "";
    });

    // trim any whitespace from the end of the answer after removing follow-up questions
    parsedAnswer = parsedAnswer.trim();

    // Omit a citation that is still being typed during streaming
    if (isStreaming) {
        let lastIndex = parsedAnswer.length;
        for (let i = parsedAnswer.length - 1; i >= 0; i--) {
            if (parsedAnswer[i] === "]") {
                break;
            } else if (parsedAnswer[i] === "[") {
                lastIndex = i;
                break;
            }
        }
        const truncatedAnswer = parsedAnswer.substring(0, lastIndex);
        parsedAnswer = truncatedAnswer;
    }

    //const parts = parsedAnswer.split(/\[([^\]]+)\]/g);
    const formattedAnswer = removeLastSquareBrackets(parsedAnswer);

    const sentenceArray = formattedAnswer.split(". ");
    const fragments: string[] = [];
    if (sentenceArray.length) {
        sentenceArray.forEach(x => {
            const sentence = x[x.length - 1] === "." ? x.slice(0, -1) : x;
            fragments.push(removeLastSquareBrackets(sentence));
        });
    }
    function trim(s: string) {
        return s.replace(/[\["\]]/g, "");
    }

    function removeLastSquareBrackets(inputString: string) {
        // Regular expression to match the pattern [content]
        const bracketPattern = /\[([^\]]+)\]/g;
        // break input if there is line break e.g "\n"
        const splittedinput = inputString.split(/(?:\r\n|\r|\n)/);
        const formattedInput: string[] = [];
        splittedinput.forEach(x => {
            // Find all occurrences of the bracket pattern
            const matches: any = splitNestedBrackets(x);
            // Check if the last match is at the end of the string
            if (matches) {
                for (let i = matches.length - 1; i >= 0; i--) {
                    const lastMatch = matches[i];
                    const lastIndex = x.lastIndexOf(lastMatch.bracketSegment);
                    // mathces if square brackets are the last in sentence.
                    // if there is "." after the square brackets, and square brackets are at
                    // the last position of sentence, then too remove the brackets
                    const bracketEndPosition = lastIndex + lastMatch.bracketSegment.length;
                    if (bracketEndPosition === x.length) {
                        // Remove all occurrences of the last match along with its brackets
                        x = x.substring(0, lastIndex).trim();
                    } else if (bracketEndPosition + 1 === x.length && x[x.length - 1] == ".") {
                        x = x.substring(0, lastIndex).trim() + ".";
                    } else if (x[bracketEndPosition] == "(" && !lastMatch.isNestedBrackets) {
                        // if there is url in (urlpath) after square bracket, then make square brakets as hyperlink
                        x = createHyperlink(x, bracketEndPosition + 1, lastMatch.bracketSegment);
                    }
                }
            }
            formattedInput.push(x);
        });
        const matches = inputString.match(bracketPattern);
        if (!isStreaming) {
            createCitations(matches);
        }
        return formattedInput.join("\n");
    }
    function createCitations(matches: any[] | null) {
        if (data_points?.length > 0) {
            data_points.map((point, index) => {
                let point_split = point.split("~");
                if (point_split.length > 1) {
                    if (
                        point_split[1].trim() !== "" &&
                        point_split[1].toLowerCase() != "none" &&
                        point_split[0].trim() !== "" &&
                        point_split[0].toLowerCase() != "none"
                    ) {
                        let filename_split = point_split[0].split(".");
                        let filename = trim(filename_split[0]);
                        let isExists = citations.some(c => c.FileName == filename);
                        if (!isExists) {
                            let citation_item: citation = { FileName: filename, Url: point_split[1] };
                            citations.push(citation_item);
                        }
                    }
                }
            });
        } else if (matches && matches.length) {
            matches.forEach(part => {
                let point_split = part.split("~");
                if (point_split.length > 1) {
                    let trimmedStr = trim(point_split[1]);
                    if (trimmedStr.trim() !== "" && trimmedStr.toLowerCase() != "none") {
                        let filename_split = point_split[0].split(".");
                        let filename = trim(filename_split[0]);
                        if (filename != "" && filename.toLowerCase() != "none") {
                            let isExists = citations.some(c => c.FileName == filename);
                            if (!isExists) {
                                let citation_item: citation = { FileName: filename, Url: trimmedStr.trim() };
                                citations.push(citation_item);
                            }
                        }
                    }
                }
            });
        }
    }

    return {
        answerHtml: isStreaming
            ? fragments.length
                ? fragments.join(". ") + "."
                : formattedAnswer
            : tabularToHtml(fragments.length ? fragments.join(". ") + "." : formattedAnswer),
        citations,
        followupQuestions
    };
}
