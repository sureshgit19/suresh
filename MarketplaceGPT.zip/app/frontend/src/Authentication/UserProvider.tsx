import React, { createContext, useContext, useState, useEffect } from 'react';
import { useMsal } from '@azure/msal-react';
import { fetchResourceGroups } from '../api';

const UserContext = createContext({
    username: null,
    resourceGroups: null,
    setUsername: () => { },
    setResourceGroups: () => { },
} as any);

export const UserProvider = ({ children }: any) => {
    const { accounts } = useMsal();
    const [username, setUsername] = useState<string | null>(null);
    const [resourceGroups, setResourceGroups] = useState<any[] | null>(null);

    useEffect(() => {
        if (accounts.length > 0) {
            const account = accounts[0];
            setUsername(account.username);
        }
    }, [accounts]);

    useEffect(() => {
        if (username) {
            fetchResourceGroups(username).then((data) => {
                setResourceGroups(data);
            });
        }
    }, [username]);

    return (
        <UserContext.Provider value={{ username, resourceGroups, setUsername, setResourceGroups }} >
            {children}
        </UserContext.Provider>
    );
};

export const useUser = () => {
    return useContext(UserContext);
};
