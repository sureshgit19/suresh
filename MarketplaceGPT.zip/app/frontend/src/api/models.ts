import { VoteDirection } from "../components/Answer";

export const enum Approaches {
    RetrieveThenRead = "rtr",
    ReadRetrieveRead = "rrr",
    ReadDecomposeAsk = "rda"
}

export const enum RetrievalMode {
    Hybrid = "hybrid",
    Vectors = "vectors",
    Text = "text"
}

export type AskRequestOverrides = {
    retrievalMode?: RetrievalMode;
    semanticRanker?: boolean;
    semanticCaptions?: boolean;
    excludeCategory?: string;
    top?: number;
    temperature?: number;
    promptTemplate?: string;
    promptTemplatePrefix?: string;
    promptTemplateSuffix?: string;
    suggestFollowupQuestions?: boolean;
};

export type AskRequest = {
    question: string;
    approach: Approaches;
    overrides?: AskRequestOverrides;
};

export type AskResponse = {
    answer: string;
    thoughts: string | null;
    data_points: string[];
    error?: string;
    arhistory_id?: string;
    relatedTopics?: RelatedTopic;
    vote?: string;
    isFavourite?: boolean;
    new_answer_av?: string;
    toggleAnswer?: boolean;
    created?: string;
    updated?: string;
    new_answer_date?: string;
    reask_question?: string;
    notes?: string;
    response_vote_feedback?: string;
    showRegenerate?: boolean;
};

export type ChatTurn = {
    user: string;
    bot?: string;
    notes?: string;
    date: Date;
};

/* 
export type ChatTurn = {
    id: string;
    state: string;
    user: string;
    bot?: string;
    dateCreated?: Date;
    dateUpdated?: Date;
    note?: string;
     responseUpvoteButton: string;
}; */

export type RelatedTopicsRequest = {
    history: ChatTurn[];
    approach: Approaches;
    overrides?: AskRequestOverrides;
    parsedResponse?: AskResponse;
    question?: string;
    user_security_group?: any[];
};

export type ChatRequest = {
    history: ChatTurn[];
    approach: Approaches;
    overrides?: AskRequestOverrides;
    shouldStream?: boolean;
    user_security_group?: any[];
};
export type ChatItem = {
    _id: string;
    user_id: string;
    history_item_id: string;
    state: string;
    user: string;
    title: string;
    bot: string;
    created: string;
    updated?: string;
    response_upvote_button?: string;
    notes?: string;
    favorites?: string[];
    new_answer: string;
    new_answer_av: boolean;
    new_answer_date?: string;
    response_vote_feedback?: string;
};

export interface HistoryProps {
    onShare?: (text: any) => void;
    onItemClick?: (chatItem: ChatItem, source: string) => void;
    refreshComponent?: boolean;
    refreshLast30DaysComponent?: boolean;
    toggleFilter?: boolean;
    historyUpdatedData?: UpdateHistoryRequest;
    activeMenu?: SideBarIcon;
    className?: string;
}

export interface UpdateHistoryRequest {
    history_item_id: string | null;
    response_upvote_button: string | null;
    response_vote_feedback: string | null;
    state: string | null;
    title: string | null;
    notes: string | null;
}

export type RelatedTopic = {
    // ID: number;
    // RelatedTopicText: string;
    // RelatedTopicsQuestion: string;
    newquestions?: {
        keyword: string;
        question: string;
    }[];
};

export interface DocumentsModel {
    "Modified On": string;
    FileName: string;
    PathURL: string;
}
export interface ApiResponseModel {
    files: DocumentsModel[];
}
export interface UserDetails {
    id: string;
    department: string;
    displayName: string;
    userPrincipalName: string;
    companyName: string;
    givenName: string;
    jobTitle: any;
    mail: string;
}

export interface Department {
    displayName: string;
    name: string;
}

export interface NotificationData {
    content: string;
    icon: string;
    image: string;
    isNew: string;
    notificationDate: string;
    title: string;
    url: string;
}

export enum SideBarIcon {
    chathistory = "chathistory",
    settings = "settings",
    favorites = "favorites",
    open = "open",
    close = "close"
}

export interface IBentoModel {
    badgeImageUrl?: string;
    badgeClass: string;
    badgeText?: string;
    exampleClass: string;
    text: string;
    documentUrl: string;
}
