import { useMsal } from "@azure/msal-react";
import { AskRequest, AskResponse, ChatRequest, UpdateHistoryRequest, ApiResponseModel, RelatedTopic, RelatedTopicsRequest, DocumentsModel } from "./models";

export async function askApi(options: AskRequest): Promise<AskResponse> {
    const response = await fetch("/ask", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            question: options.question,
            approach: options.approach,
            overrides: {
                retrieval_mode: options.overrides?.retrievalMode,
                semantic_ranker: options.overrides?.semanticRanker,
                semantic_captions: options.overrides?.semanticCaptions,
                top: options.overrides?.top,
                temperature: options.overrides?.temperature,
                prompt_template: options.overrides?.promptTemplate,
                prompt_template_prefix: options.overrides?.promptTemplatePrefix,
                prompt_template_suffix: options.overrides?.promptTemplateSuffix,
                exclude_category: options.overrides?.excludeCategory
            }
        })
    });

    const parsedResponse: AskResponse = await response.json();
    if (response.status > 299 || !response.ok) {
        throw Error(parsedResponse.error || "Unknown error");
    }

    return parsedResponse;
}

export let user_id = ""; // Declare user_id in a higher scope to make it accessible

export function setUserid(userid: string) {
    user_id = userid;
}
export function getUserId() {
    //sessionStorage.get
    return user_id;
}




export async function getUserGroup() {
    return fetch(`/user_security_group/${user_id}`);
}

export async function chatApi(options: ChatRequest): Promise<Response> {
    const url = options.shouldStream ? "/chat_stream" : "/chat";
    return await fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-User-Email": getUserId()
        },
        body: JSON.stringify({
            history: options.history,
            approach: options.approach,
            overrides: {
                retrieval_mode: options.overrides?.retrievalMode,
                semantic_ranker: options.overrides?.semanticRanker,
                semantic_captions: options.overrides?.semanticCaptions,
                top: options.overrides?.top,
                temperature: options.overrides?.temperature,
                prompt_template: options.overrides?.promptTemplate,
                prompt_template_prefix: options.overrides?.promptTemplatePrefix,
                prompt_template_suffix: options.overrides?.promptTemplateSuffix,
                exclude_category: options.overrides?.excludeCategory,
                suggest_followup_questions: options.overrides?.suggestFollowupQuestions
            },
            user_security_group: options.user_security_group,
        })
    });
}

export function reaskApi(options: any): Promise<Response> {
    options["X-User-Email"] = getUserId();
    return fetch("/reask", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(options)
    });
}

export function getCitationFilePath(citation: string): string {
    return `/content/${citation}`;
}

export function getFileNameFromUrl(url: string): string {
    const decodedUrl = decodeURI(url).endsWith("/") ? decodeURI(url).slice(0, -1) : decodeURI(url);

    //console.log(decodedUrl);

    let fileName = decodedUrl.split("/").pop() ?? "";
    if (fileName !== "") {
        let paramArray = fileName.split("?");
        //console.log(paramArray);
        fileName = paramArray[0];
    }

    return fileName;
}

export async function getemail() {
    try {
        const response = await fetch("/.auth/me");
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        const userEmail = data[0]?.user_id || "";
        //console.log(userEmail, "here is the useremail");
        return userEmail;
    } catch (error) {
        console.error("Error:", error);
        return ""; // Return an empty string in case of any error
    }
}

export async function updateHistoryDetail(options: UpdateHistoryRequest): Promise<Response> {
    const url = "/update_history_detail";
    return fetch(url, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            history_item_id: options.history_item_id,
            response_upvote_button: options.response_upvote_button,
            response_vote_feedback: options.response_vote_feedback,
            notes: options.notes,
            title: options.title,
            state: options.state
        })
    });
}

export const fetchResourceGroups = async (username: string) => {
    const response = await fetch(`/user_security_group/${username}`);
    const data = await response.json();
    return data;
};

export const fetchBentoBoxData = async (resourceGroups?: string[]) => {
    try {
        const options = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ user_security_group: resourceGroups }),
        };
        const response = await fetch("/bento_data", options);
        if (response.ok) {
            let responseData = await response.json();
            if (Array.isArray(responseData)) {
                responseData = responseData.sort((a, b) => Number(a.exampleClass.split("-")[1] - b.exampleClass.split("-")[1] ?? 0))
                return responseData;
            }
        } else {
            console.error("Failed to fetch bento data");
            throw new Error("Failed to fetch bento data");
        }
    } catch (error) {
        console.error("Error fetching bento data", error);
        throw new Error("Failed to fetch bento data");
    }
};

export async function getdocuments(userGroups: any): Promise<DocumentsModel[]> {
    const options = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ user_security_group: userGroups }),
    };
    const url = "/document_data";
    var response = await fetch(url, options);
    var parsedresp: DocumentsModel[] = await response.json();
    return parsedresp;
}

export async function getRelatedTopics(options?: RelatedTopicsRequest): Promise<RelatedTopic> {
    const url = "/related_question";
    try {
        var response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(options)
        });
        const parsedresp: RelatedTopic = await response.json();
        parsedresp.newquestions = parsedresp.newquestions?.filter(x => {
            if (x.keyword.trim() == "" || x.keyword.trim() == "[]" || x.question.trim() == "" || x.question.trim() == "[]") {
                return false;
            }
            return true;
        });
        console.log(parsedresp);
        return parsedresp;
    } catch (error) {
        console.error("Error:", error);
        return {};
    }
}
export async function getNotifications() {
    const url1 = "/GetNotificationsJson";
    var response1 = await fetch(url1);
    const parsedresp1 = await response1.json();
    return parsedresp1;
}

export async function updateOriginalResponse(history_item_id: string) {
    fetch(`/update_original_response/${history_item_id}`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: null
    })
        .then(response => {
            if (response.ok) {
                //console.log("Item Updated Successfully");
            } else {
                console.error("Failed to update original_response. Status", response.status);
            }
            return response.json();
        })
        .catch(error => {
            console.error("Error updating data:", error);
        });
}
export async function createHistoryItem(body: any) {
    fetch("/create_history_item", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(body)
    }).then(res => {
        if (!res.ok) {
            console.error("error in saving history");
        }
    });
}

export async function regenerateAnswer(options?: ChatRequest) {
    const url = "/regenerate_response";
    try {
        var response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(options)
        });
        const parsedresp = await response.json();
        //console.log(parsedresp);
        return parsedresp;
    } catch (error) {
        console.error("Error:", error);
        return {};
    }
}