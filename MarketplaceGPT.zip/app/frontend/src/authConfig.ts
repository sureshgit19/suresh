import { LogLevel, PublicClientApplication } from "@azure/msal-browser";

export const msalConfig = {
    // change the redirect uri to dev and prod env while deployment.
    auth: {
        clientId: import.meta.env.VITE_APP_CLIENT_ID,
        authority: `https://login.microsoftonline.com/${import.meta.env.VITE_APP_TENANT_ID}`,
        redirectUri: import.meta.env.VITE_APP_REDIRECT_URI
        // postLogoutRedirectUri: "/" // Indicates the page to navigate after logout.
        //navigateToLoginRequestUrl: false // If "true", will navigate back to the original request location before processing the auth code response.
    },
    cache: {
        cacheLocation: "sessionStorage", // This configures where your cache will be stored
        storeAuthStateInCookie: false // Set this to "true" if you are having issues on IE11 or Edge
    },
    system: {
        loggerOptions: {
            loggerCallback: (level: any, message: any, containsPii: any) => {
                if (containsPii) {
                    return;
                }
                switch (level) {
                    case LogLevel.Error:
                        console.error(message);
                        return;
                    case LogLevel.Info:
                        //console.info(message);
                        return;
                    case LogLevel.Verbose:
                        //console.debug(message);
                        return;
                    case LogLevel.Warning:
                        //console.warn(message);
                        return;
                    default:
                        return;
                }
            }
        }
    }
};

export const loginRequest = {
    scopes: ["openid", `api://${import.meta.env.VITE_APP_CLIENT_ID}/Custom.Read`]
    // scopes: ["openid", "profile", "user.read"]
};

export const silentRequest = {
    scopes: ["openid", "profile", "user.read"]
};

export const msalInstance = new PublicClientApplication(msalConfig);
