import copy
import io
import json
import logging
import mimetypes
import os
import random
import time
import uuid
import json
import aiohttp
import openai
import re
import pymongo
import requests
import models
#import jwt
import logging
from datetime import timedelta, datetime
from typing import AsyncGenerator
from custom_encoder import custom_json_encoder
from bson.json_util import dumps
from pymongo import errors
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from Crypto.Random import get_random_bytes
import base64
from models import credential, telemetry_client_endpoint, telemetry_client_key
from azure.identity.aio import DefaultAzureCredential
from azure.monitor.opentelemetry import configure_azure_monitor
from azure.search.documents.aio import SearchClient
from azure.storage.blob.aio import BlobServiceClient
from azure.storage.blob import BlobServiceClient
from opentelemetry.instrumentation.aiohttp_client import AioHttpClientInstrumentor
from opentelemetry.instrumentation.asgi import OpenTelemetryMiddleware
from quart import (
    Blueprint,
    Quart,
    abort,
    current_app,
    jsonify,
    make_response,
    request,
    send_file,
    send_from_directory,
)
#from quart_cors import cors
from openai import AsyncAzureOpenAI

from approaches.chatreadretrieveread import ChatReadRetrieveReadApproach
# from approaches.readdecomposeask import ReadDecomposeAsk
# from approaches.readretrieveread import ReadRetrieveReadApproach
from approaches.retrievethenread import RetrieveThenReadApproach
import json
from jwksutils import rsa_pem_from_jwk
from urllib.request import urlopen
from jose import jwt

CONFIG_OPENAI_TOKEN = "openai_token"
CONFIG_CREDENTIAL = "azure_credential"
CONFIG_ASK_APPROACHES = "ask_approaches"
CONFIG_CHAT_APPROACHES = "chat_approaches"
CONFIG_BLOB_CONTAINER_CLIENT = "blob_container_client"

bp = Blueprint("routes", __name__, static_folder="static")
user_id = None
accessible_indexes:dict = {}
@bp.route("/")
async def index():
    return await bp.send_static_file("index.html")


@bp.route("/favicon.ico")
async def favicon():
    return await bp.send_static_file("favicon.ico")


@bp.route("/assets/<path:path>")
async def assets(path):
    return await send_from_directory("static/assets", path)


# Serve content files from blob storage from within the app to keep the example self-contained.
# *** NOTE *** this assumes that the content files are public, or at least that all users of the app
# can access all the files. This is also slow and memory hungry.
@bp.route("/content/<path>")
async def content_file(path):
    blob_container_client = current_app.config[CONFIG_BLOB_CONTAINER_CLIENT]
    blob = await blob_container_client.get_blob_client(path).download_blob()
    if not blob.properties or not blob.properties.has_key("content_settings"):
        abort(404)
    mime_type = blob.properties["content_settings"]["content_type"]
    if mime_type == "application/octet-stream":
        mime_type = mimetypes.guess_type(path)[0] or "application/octet-stream"
    blob_file = io.BytesIO()
    await blob.readinto(blob_file)
    blob_file.seek(0)
    return await send_file(blob_file, mimetype=mime_type, as_attachment=False, attachment_filename=path)


@bp.route("/ask", methods=["POST"])
async def ask():
    if not request.is_json:
        return jsonify({"error": "request must be json"}), 415
    request_json = await request.get_json()
    approach = request_json["approach"]
    try:
        impl = current_app.config[CONFIG_ASK_APPROACHES].get(approach)
        if not impl:
            return jsonify({"error": "unknown approach"}), 400
        # Workaround for: https://github.com/openai/openai-python/issues/371
        async with aiohttp.ClientSession() as s:
            openai.aiosession.set(s)
            r = await impl.run(request_json["question"], request_json.get("overrides") or {})
        return jsonify(r)
    except Exception as e:
        logging.exception("Exception in /ask")
        return jsonify({"error": str(e)}), 500


@bp.route("/chat", methods=["POST"])
async def chat():
    if not request.is_json:
        return jsonify({"error": "request must be json"}), 415
    request_json = await request.get_json()
    approach = request_json["approach"]
    try:
        impl = current_app.config[CONFIG_CHAT_APPROACHES].get(approach)
        if not impl:
            return jsonify({"error": "unknown approach"}), 400
        # Workaround for: https://github.com/openai/openai-python/issues/371
        async with aiohttp.ClientSession() as s:
            openai.aiosession.set(s)
            r = await impl.run_without_streaming(request_json["history"], request_json.get("overrides", {}))
            models.storeHitory(request_json["history"], r)
        return jsonify(r)
    except Exception as e:
        logging.exception("Exception in /chat")
        return jsonify({"error": str(e)}), 500

@bp.route("/reask", methods=["POST"])
async def reask():
    if not request.is_json:
        return jsonify({"error": "request must be json"}), 415
    request_json = await request.get_json()
    approach = request_json["approach"]
    userid = request.headers.get("X-User-Email", "")
    user_security_groups = request_json["user_security_group"]
    search_clients = await get_user_indexes(user_security_groups, userid)
    try:
        impl = current_app.config[CONFIG_CHAT_APPROACHES].get(approach)
        if not impl:
            return jsonify({"error": "unknown approach"}), 400  
        newprompt = await impl.generate_new_prompt_from_datapoint(request_json)
        print('newprompt', newprompt)
        # try to find asnwer
        if newprompt !='':
            request_json["request"]["history"].append({ 'user': newprompt, 'bot': "", 'date': datetime.now() })
            new_answer = await impl.run_without_streaming(
                request_json["request"]["history"], request_json["request"].get("overrides", {}), search_clients)
            print('newanswer',new_answer)
            #  analyse new answer 
            new_answer_analysis = await impl.analyse_question_response(new_answer['answer'])
            if(new_answer_analysis.lower()=='yes'):
                newprompt = ''

        return {'newquestion':newprompt}
    except Exception as e:
        logging.exception("Exception in /chat")
        return jsonify({"error": str(e)}), 500

async def format_as_ndjson(r: AsyncGenerator[dict, None]) -> AsyncGenerator[str, None]:
    async for event in r:
        yield json.dumps(event, ensure_ascii=False) + "\n"

async def consume_async_generator(gen):
    results = []
    async for item in gen:
        if isinstance(item, dict):
            results.append(item)
        elif isinstance(item, list) and all(isinstance(subitem, dict) for subitem in item):
            results.extend(item)
        elif hasattr(item, 'model_dump'):
            results.append(item.model_dump())
        else:
            pass
    return results

@bp.route('/update_original_response/<history_item_id>', methods=['POST'])
async def update_original_response(history_item_id):
    try:
        # Ensure the history_item_id is valid and not empty
        if not history_item_id:
            return jsonify({'error': 'History item ID is required'}), 400

        # Retrieve the specific document by history_item_id
        document = models.collection.find_one({"history_item_id": history_item_id})

        now = datetime.now()
        dt_string = now.isoformat()

        # Check if the document exists
        if not document:
            return jsonify({'error': 'Document not found'}), 404
        history_document = models.history_collection.find_one({"history_item_id": history_item_id})

        if history_document:
            # Append the new original_response to the existing array
            models.history_collection.update_one(
                {"history_item_id": history_item_id},
                {
                    "$push": {
                        "original_response": document.get("bot", ""),  # Appending current 'bot' response
                    },
                    "$set": {
                        "date": dt_string,  # Updating the date to now
                    }
                }
            )
        else:
            # Create a new history document for this history_item_id
            models.history_collection.insert_one({
                "history_item_id": history_item_id,
                "user": document.get("user", ""),
                "original_response": [document.get("bot", "")],  # Initializing with the current 'bot' response
                "date": dt_string,
            })
            
        # Prepare updates
        updates = {
            "$set": {
                "bot": document.get("new_answer", ""),  # Moving 'new_answer' to 'bot'
                "new_answer": "",  # Clearing out 'new_answer'
                "new_answer_av": False,
                "new_answer_date": ""
            }
        }

        # Perform the update operation
        models.collection.update_one({"history_item_id": history_item_id}, updates)

        return jsonify({'message': 'Document updated successfully'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bp.route("/related_question", methods=["POST"])
async def related_question():
    print('related questions called')
    if not request.is_json:
        return jsonify({"error": "request must be json"}), 415
    request_json = await request.get_json()
    approach = request_json["approach"]
    try:
        impl = current_app.config[CONFIG_CHAT_APPROACHES].get(approach)
        if not impl:
            return jsonify({"error": "unknown approach"}), 400
        
        newquestions = await impl.generate_related_questions(request_json)
        # Assuming newquestions is a list of two questions
        for newquestion in newquestions:
            if newquestion != '':
                request_json["history"].append({'user': newquestion, 'bot': "", 'date': datetime.now()})
        return {'newquestions': newquestions}
    except Exception as e:
        logging.exception("Exception in /related_question")
        return jsonify({"error": str(e)}), 500
    

@bp.route("/chat_stream", methods=["POST"])
async def chat_stream():
    global user_id, accessible_indexes
    if not request.is_json:
        return jsonify({"error": "request must be json"}), 415
    request_json = await request.get_json()
    approach = request_json["approach"]

    user_id = request.headers.get("X-User-Email", "")
    print("USERID:",user_id)
    user_security_groups = request_json["user_security_group"]

    search_clients = await get_user_indexes(user_security_groups, user_id)

    print('Search Clients', search_clients)
    try:
        impl = current_app.config[CONFIG_CHAT_APPROACHES].get(approach)
        if not impl:
            return jsonify({"error": "unknown approach"}), 400
        response_generator = impl.run_with_streaming(
            request_json["history"], request_json.get("overrides", {}), search_clients)
        formatted_responses = await consume_async_generator(response_generator)
        docs_received = formatted_responses[-3:]
        formatted_responses = formatted_responses[:-3]

        history_item_id = generate_history_item_id()
        chat_history_item = {
          "history_item_id": history_item_id 
        }
        formatted_responses.append(chat_history_item)
        # Storing docs with ID
        models.chat_stream_docs(history_item_id, docs_received)
        
        formatted_response1 = '\n'.join(json.dumps(item)
                                       for item in formatted_responses)

        response = await make_response(formatted_response1)
        response.headers['Content-Type'] = 'application/json'
        response.timeout = None  # type: ignore
        return response
    except Exception as e:
        logging.exception("Exception in /chat")
        return jsonify({"error": str(e)}), 500

async def get_user_indexes(user_security_groups, userid):
    SECURITY_GROUP_BLOB_NAME = os.getenv("SECURITY_GROUP_BLOB_NAME")
    # Setup Azure blob service client
    security_blob = BlobServiceClient(account_url="https://strgdevmarketplacegpt.blob.core.windows.net", credential=credential)
    container_name = "security-group-data"
    container_client = security_blob.get_container_client(container_name)
    blob_client = container_client.get_blob_client(SECURITY_GROUP_BLOB_NAME)
    stream = blob_client.download_blob()
    file_contents = stream.readall()
    security_groups = json.loads(file_contents.decode('utf-8'))
    print('User is in security groups:', user_security_groups)
    unique_indexes = []
    # Determine the indexes accessible to the user based on their security groups   accessible_indexes
    if user_security_groups:  
        unique_indexes = list({index for group in user_security_groups for index in security_groups.get(group, [])})
        if len(unique_indexes) == 0:
            unique_indexes = security_groups.get("default")
    else:  
        # If the user has no security groups or no indexes are found, use the default index  
        unique_indexes = security_groups.get("default")
    
    #print('Accessible Indexes:', unique_indexes)
    search_clients = initialize_search_clients(unique_indexes)
    return search_clients


@bp.route('/user_security_group/<user_id>', methods=['GET'])
async def user_security_group(user_id):
    GROUP_USER_MAPPING_BLOB_NAME = os.getenv("GROUP_USER_MAPPING_BLOB_NAME")
    try:
        if not request.is_json:
            return jsonify({"error": "request must be json"}), 415
        
        user_id = user_id 
        # Retrieve user security groups from blob storage  
        security_blob = BlobServiceClient(account_url="https://strgdevmarketplacegpt.blob.core.windows.net", credential=credential)  
        container_name = "security-group-data"  
        container_client = security_blob.get_container_client(container_name)  
        blob_client_map = container_client.get_blob_client(GROUP_USER_MAPPING_BLOB_NAME)  
        stream_map = blob_client_map.download_blob()  
        file_contents_map = stream_map.readall()  
        security_groups_map = json.loads(file_contents_map.decode('utf-8'))  
          
        user_security_groups = [group_name for group_name, users in security_groups_map.items() if user_id in users]  
        print('User is in security groups:', user_security_groups)  

        return jsonify(user_security_groups), 200

    except Exception as e:
        logging.exception("Exception in /user_security_group")  
        return jsonify({"error": str(e)}), 500  

@bp.route('/create_history_item', methods=['POST'])
async def create_history_item():
    try:
        if not request.is_json:
            return jsonify({"error": "request must be json"}), 415
        request_json = await request.get_json()
        citation_list = []
        data_poits = request_json["parsedResponse"]["data_points"]
        if isinstance(data_poits, list):
            for point in request_json["parsedResponse"]["data_points"]:
                point_split = point.split("~")
                if (len(point_split)>1):
                    citation = {"filename":point_split[0],"url":point_split[1]}
                    citation_list.append(citation)
        
        content_combined = request_json["parsedResponse"]["answer"]
        citation_format = "[" + "][".join([f'"{item["filename"]}"~"{item["url"]}"' for item in citation_list]) + "]"
        # database response ---
        final_output = f'{content_combined}{citation_format}'
        
        # Storing in MongoDB
        user_question = request_json["question"]
        bot_response = final_output
        user_id = request_json["userid"]
        history_item_id = request_json["parsedResponse"]["arhistory_id"]
        user_security_groups = request_json["user_security_group"]
        
        field_value = ", ".join(user_security_groups)
        
        print("field_value",field_value)
        print("hsitoryitem********",history_item_id)
        models.storeHistory(user_question, bot_response, history_item_id, user_id, field_value)
        return jsonify({"status": "added"}), 200 
    except errors.PyMongoError as e:
        return jsonify({'status': 500, 'error': 'Database error', 'details': str(e)})


def generate_history_item_id():
    # Generate a random UUID (version 4)
    random_guid = uuid.uuid4()
    random_guid_str = str(random_guid)
    return random_guid_str


@bp.route('/regenerate_response', methods=['POST'])  
async def regenerate_response():  
    if not request.is_json:  
        return jsonify({"error": "request must be json"}), 415  
    request_json = await request.get_json()  
    userid = request.headers.get("X-User-Email", "")
    history_item_id = request_json.get("history_item_id")  
    approach = request_json["approach"]
    user_security_groups = request_json["user_security_group"]
    search_clients = await get_user_indexes(user_security_groups, userid)

    print('Search Clients', search_clients)
    try:  
        # Extract the approach used for the response from the config  
        impl = current_app.config[CONFIG_CHAT_APPROACHES].get(approach)  
        if not impl:  
            return jsonify({"error": "unknown approach"}), 400  
        print("request_JSON*********",request_json)
        print("ovverries", request_json.get("overrides", {}))
        # Re-run the logic used to generate the initial response  
        response_generator = impl.run_with_streaming(  
            request_json["history"], request_json.get("overrides", {}),search_clients) 
        
        formatted_responses = await consume_async_generator(response_generator)
        docs_recieved = formatted_responses[-3:]
        regenerated_response = ""  
        is_first_chunk = True
        for entry in formatted_responses:  
            if is_first_chunk:  
                is_first_chunk = False 
                continue  
  
            # Process the subsequent chunks using the provided logic to extract content  
            if "choices" in entry and isinstance(entry["choices"], list) and entry["choices"]:  
                choice = entry["choices"][0]  
                if "delta" in choice and "content" in choice["delta"] and choice["delta"]["content"] is not None:  
                    content = choice["delta"]["content"]  
                    regenerated_response += content
         

        # Update the document with the regenerated_response using history_item_id  
        update_result = models.collection.update_one(  
            {"history_item_id": history_item_id},  
            {"$set": {"regenerated_response": regenerated_response}}  
        )  

        # Storing docs with ID
        models.reg_resp_docs(history_item_id, docs_recieved)

        if update_result.matched_count == 0:  
            return jsonify({"error": "No matching document found to update"}), 404  
  
        # Return the new response to the front end  
        return jsonify({  
            "history_item_id": history_item_id,  
            "regenerated_response": regenerated_response  
        }), 200  
    except Exception as e:  
        logging.exception("Exception in /regenerate_response")  
        return jsonify({"error": str(e)}), 500 

@bp.route('/get_history_item/<history_item_id>', methods=['GET'])
async def get_history_item(history_item_id):
    try:
        result = models.collection.find({'history_item_id': history_item_id})
        data_list = list(result)
        data_json = json.dumps(data_list, cls=custom_json_encoder)

        return data_json
    
    except errors.PyMongoError as e:
        return jsonify({'status': 500, 'error': 'Database error', 'details': str(e)})


@bp.route('/get_active_history_list_items/<user_id>', methods=['GET'])
async def get_active_history_list_items(user_id):
    try:
        result = models.collection.find({'user_id': user_id})
        data_list = list(result)
        
        data_json = json.dumps(data_list, cls=custom_json_encoder)

        return data_json
    
    except errors.PyMongoError as e:
        return jsonify({'status': 500, 'error': 'Database error', 'details': str(e)})


@bp.route('/get_login_data/<user_id>/<date_filter>', methods=['GET'])
def get_login_data(user_id, date_filter):
    current_date = datetime.now()
    cutoff_date = current_date - timedelta(days=30)
    try:
        operator = "$gte"
        if date_filter == 'last30days':
            operator = "$gte"
        elif date_filter == 'above30days':
            operator = "$lt"

        # Query MongoDB for data filtered by user_id and date
        login_data = models.collection.find({
            'user_id': user_id,
            'created': {operator: cutoff_date.isoformat()}
        })
        login_data_list = list(login_data)
        sorted_data = sorted(login_data_list, key=lambda x: x['created'], reverse=True)
        data_json = json.dumps(sorted_data, cls=custom_json_encoder)

        return data_json
    except errors.PyMongoError as e:
        return jsonify({'status': 500, 'error': 'Database error', 'details': str(e)})

@bp.route('/toggle_favorite/<user_id>/<history_item_id>', methods=['POST'])
async def toggle_favorite(user_id, history_item_id):
    try:
        existing_favorite = models.collection.find_one({
            "user_id": user_id,
            "favorites": history_item_id
        })

        if existing_favorite:
            # Remove from favorites
            models.collection.update_one(
                {"user_id": user_id},
                {"$pull": {"favorites": history_item_id}}
            )
            return jsonify({"status": "removed"}), 200
        else:
            # Add to favorites
            models.collection.update_one(
                {"user_id": user_id},
                {"$addToSet": {"favorites": history_item_id}}
            )
            return jsonify({"status": "added"}), 200
            
    except errors.PyMongoError as e:
        return jsonify({'error': 'Database error', 'details': str(e)}), 500


@bp.route('/get_user_favorites/<user_id>', methods=['GET'])
async def get_user_favorites(user_id):
    try:
        # Ensure the user_id is valid and not empty
        if not user_id:
            return jsonify({'error': 'User ID is required'}), 400

        # Retrieve the document containing the user's favorites
        user_document = models.collection.find_one(
            {"user_id": user_id},
            {"favorites": 1}
        )

        # Check if the user document with the given user_id exists
        if not user_document:
            return jsonify({'error': 'User not found'}), 404

        # Retrieve details for each favorite item, including the created date, history_item_id, title, and state
        favorites_details = []
        if "favorites" in user_document:
            favorites_ids = user_document['favorites']
            # Find all chat items with an ID that's in the favorites list and include the desired fields
            favorites_cursor = models.collection.find(
                {"history_item_id": {"$in": favorites_ids}},
                {"user": 1, "bot": 1, "response_upvote_button": 1, "notes": 1, "created": 1, "history_item_id": 1, "title": 1, "state": 1,"new_answer_av":1,"new_answer":1,"created":1,"updated":1,"new_answer_date":1}
            )
            favorites_details = list(favorites_cursor)

        # Sort the favorites details by the 'created' field in descending order
        favorites_details.sort(key=lambda x: x['created'], reverse=True)

        # Serialize to JSON using the custom JSON encoder and return the response
        data_json = json.dumps(favorites_details, cls=custom_json_encoder)

        return data_json

    except errors.PyMongoError as e:
        # Log the error for debugging purposes
        bp.logger.error(f"Database error occurred: {e}")
        return jsonify({'error': 'Database error', 'details': str(e)}), 500
    except Exception as e:
        # Catch any other unforeseen exceptions and log them
        bp.logger.error(f"An unexpected error occurred: {e}")
        return jsonify({'error': 'An unexpected error occurred', 'details': str(e)}), 500


@bp.route('/document_details/<history_item_id>', methods=['GET'])
async def document_details(history_item_id):
    try:
        result = models.doc_collection.find({'history_item_id': history_item_id})
        data_list = list(result)
        data_json = json.dumps(data_list, cls=custom_json_encoder)
        
        return jsonify(json.loads(data_json)) 
    
    except errors.PyMongoError as e:
        return jsonify({'status': 500, 'error': 'Database error', 'details': str(e)}), 500

@bp.route('/update_history_detail', methods=['PUT'])
async def update_history_detail():
    if not request.is_json:
        return jsonify({"error": "request must be json"}), 415

    request_json = await request.get_json()
    notes = request_json["notes"]
    title = request_json["title"]
    response_upvote_button = request_json["response_upvote_button"]
    state = request_json["state"]
    history_item_id = request_json["history_item_id"]
    response_vote_feedback = request_json.get("response_vote_feedback")
    
    if history_item_id is not None:
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        if notes is not None:
            filter_criteria = {"history_item_id": history_item_id}
            new_values = {"$set": {"notes": notes, "updated": current_time}}
            result = models.collection.update_one(filter_criteria, new_values)


        if title is not None:
            filter_criteria = {"history_item_id": history_item_id}
            new_values = {"$set": {"title": title, "updated": current_time}}
            result = models.collection.update_one(filter_criteria, new_values)


        if response_upvote_button is not None:
            filter_criteria = {"history_item_id": history_item_id}
            new_values = {
                "$set": {"response_upvote_button": response_upvote_button, "updated": current_time}}
            result = models.collection.update_one(filter_criteria, new_values)


        if state is not None:
            filter_criteria = {"history_item_id": history_item_id}
            new_values = {"$set": {"state": state, "updated": current_time}}
            result = models.collection.update_one(filter_criteria, new_values)

        if response_vote_feedback is not None:
            filter_criteria = {"history_item_id": history_item_id}
            new_values = {"$set": {"response_vote_feedback": response_vote_feedback, "updated": current_time}}
            result = models.collection.update_one(filter_criteria, new_values)

    else:
        return jsonify({"error": "HistoryItemID not found"}), 415

    return jsonify({"message": "Record updated successfully", 'status': 200})


@bp.route("/trending_question", methods=["POST"])
async def get_random_questions():
    '''Function for trending questions'''
    try:
        # Check for JSON payload  
        if not request.is_json:  
            return jsonify({"error": "Request must be JSON"}), 415  
  
        request_json = await request.get_json()  

        user_security_group = request_json["user_security_group"][0] if request_json["user_security_group"] else None  
        
        # Fetch questions from the blob
        questions = get_questions_from_blob()

        # Determine which group's data to retrieve based on the security group
        if user_security_group == 'Store KBC':
            group_questions = questions.get('Store KBC', [])
        else:
            group_questions = questions.get('field', [])

        if not group_questions:
            return jsonify({"error": f"No questions found for security group '{user_security_group}'"}), 404

        # Sort questions by their ID
        sorted_questions = sorted(group_questions, key=lambda x: x['id'])
        question_strings = [q['question'] for q in sorted_questions]
        return jsonify({"questions": question_strings})
    except Exception as e:
        # Log the exception
        logging.exception("Exception occurred while fetching questions from blob")

        # Return a JSON response with error details
        return jsonify({"error": str(e)}), 500
    

def get_questions_from_blob():
    
    # Create a BlobServiceClient using the connection string
    blob_service_client = BlobServiceClient(account_url="https://strgdevmarketplacegpt.blob.core.windows.net", credential=credential)

    container_name = "trendingquestion"
    container_client = blob_service_client.get_container_client(container_name)
    blob_client = container_client.get_blob_client('RightPanelQuestions_group.json')
    stream = blob_client.download_blob()
    file_contents = stream.readall()
    questions = json.loads(file_contents.decode('utf-8'))

    return questions


@bp.route("/bento_data", methods=["POST"])
async def get_bento_data():
    '''Function for fetching bento data'''
    try:
        # Check for JSON payload  
        if not request.is_json:  
            return jsonify({"error": "Request must be JSON"}), 415  
  
        request_json = await request.get_json()  

        user_security_group = request_json["user_security_group"][0] if request_json["user_security_group"] else None  
        
        blob_service_client = BlobServiceClient(
            account_url="https://strgdevmarketplacegpt.blob.core.windows.net", 
            credential=credential
        )
        container_name = "trendingquestion"
        container_client = blob_service_client.get_container_client(container_name)
        blob_client = container_client.get_blob_client('bento_group.json')
        stream = blob_client.download_blob()
        file_contents = stream.readall()
        bento_data = json.loads(file_contents.decode('utf-8'))

        # Determine which group data to return without changing the structure  
        group_data = bento_data['Store KBC'] if user_security_group == 'Store KBC' else bento_data['field']  
        return jsonify(group_data)  

    except Exception as e:
        # Log the exception
        logging.exception("Exception occurred while fetching bento data from blob")

        # Return a JSON response with error details
        return jsonify({"error": str(e)}), 500

@bp.route("/vote_options", methods=["GET"])
def get_vote_options():
    '''Function for fetching upvote and downvote options'''
    try:
        # Create a BlobServiceClient using the connection string
        blob_service_client = BlobServiceClient(account_url="https://strgdevmarketplacegpt.blob.core.windows.net", credential=credential)

        container_name = "upvote-downvote-options"
        container_client = blob_service_client.get_container_client(container_name)
        blob_client = container_client.get_blob_client('upvote_downvote_options.json')
        stream = blob_client.download_blob()
        file_contents = stream.readall()
        options = json.loads(file_contents.decode('utf-8'))

        return jsonify(options)
    except Exception as e:
        # Log the exception
        logging.exception("Exception occurred while fetching bento data from blob")

        # Return a JSON response with error details
        return jsonify({"error": str(e)}), 500


@bp.route('/document_data', methods=["POST"])
async def returndocs():

    if not request.is_json:
        return jsonify({"error": "Request must be JSON"}), 415

    request_json = await request.get_json()
    print("Request Received: ", request_json)

    user_security_group = request_json["user_security_group"][0] if request_json["user_security_group"] else None  
    
    # Create a BlobServiceClient using the connection string
    blob_service_client = BlobServiceClient(account_url="https://strgdevmarketplacegpt.blob.core.windows.net", credential=credential)
    container_name = "trendingquestion"
    container_client = blob_service_client.get_container_client(container_name)
    blob_list = container_client.list_blobs()
    for blob in blob_list:
        if blob.name == 'RightPanelNewDocs_group.json':
            blob_client = container_client.get_blob_client(blob)
            stream = blob_client.download_blob()
            file_contents = stream.readall()
            documents = json.loads(file_contents.decode('utf-8'))

            # Determine which group's data to retrieve based on the security group
            if user_security_group == 'Store KBC':
                group_data = documents.get('Store KBC', [])
            else:
                group_data = documents.get('field', [])

            if not group_data:
                return jsonify({"error": f"No documents found for security group '{user_security_group}'"}), 404
            
            return jsonify(group_data)
    
    # Return an error or empty response if the file is not found
    return jsonify({"error": "File not found"}), 404

@bp.route("/more_like_this", methods=["GET"])
def more_like_this():
    '''Function for fetching data more like this'''
    try:

        # Create a BlobServiceClient using the connection string
        blob_service_client = BlobServiceClient(account_url="https://strgdevmarketplacegpt.blob.core.windows.net", credential=credential)
        container_name = "trendingquestion"
        container_client = blob_service_client.get_container_client(container_name)
        blob_client = container_client.get_blob_client('RelatedQuestions.json')
        stream = blob_client.download_blob()
        file_contents = stream.readall()
        document_data = json.loads(file_contents.decode('utf-8'))

        return jsonify(document_data)
    except Exception as e:
        # Log the exception
        logging.exception("Exception occurred while fetching bento data from blob")

        # Return a JSON response with error details
        return jsonify({"error": str(e)}), 500

@bp.route("/GetNotificationsJson", methods=["GET"])
def GetNotificationsJson():
    try:
        
        # Replace with your Azure connection string
        blob_service_client = BlobServiceClient(account_url="https://rgmarketplaceintella03a.blob.core.windows.net", credential=credential)
        container_name = "notifications-data"  
        filename = "newnotifications.json"
        container_client = blob_service_client.get_container_client(container_name)
        blob_client = container_client.get_blob_client(filename)
        streamdownloader = blob_client.download_blob()
        file_content = streamdownloader.readall()
        json_data = json.loads(file_content)

        return jsonify(json_data)
    
    except Exception as e:
        # Log the exception
        logging.exception("Exception occurred while fetching bento data from blob")

        # Return a JSON response with error details
        return jsonify({"error": str(e)}), 500
    
def encrypt(data, key, iv):
    cipher = AES.new(key, AES.MODE_CBC, iv)
    ct_bytes = cipher.encrypt(pad(data.encode('utf-8'), AES.block_size))
    encrypted_data = base64.b64encode(ct_bytes).decode('utf-8')
    return encrypted_data

@bp.route("/get_telemetry_client_key", methods=["GET"])
def get_telemetry_client_key():
    try:
        
        encryption_key = get_random_bytes(16)
        iv = get_random_bytes(16)
        encrypted_client_key = encrypt(telemetry_client_key, encryption_key, iv)
        encrypted_client_endpoint = encrypt(telemetry_client_endpoint, encryption_key, iv)

        encoded_iv = base64.b64encode(iv).decode('utf-8')
        encoded_key = base64.b64encode(encryption_key).decode('utf-8')

        return jsonify({
            "encrypted_client_key": encrypted_client_key,
            "encrypted_client_endpoint": encrypted_client_endpoint,
            "iv": encoded_iv,
            "key": encoded_key
        }), 200
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

def initialize_search_clients(indexes):
    AZURE_SEARCH_SERVICE = os.environ["AZURE_SEARCH_SERVICE"]
    azure_credential = DefaultAzureCredential(exclude_shared_token_cache_credential=True)
    search_clients = {
        SearchClient(
            endpoint=f"https://{AZURE_SEARCH_SERVICE}.search.windows.net",
            index_name=index,
            credential=azure_credential,
        ) for index in indexes
    }
    return search_clients

@bp.before_request
async def ensure_openai_token():
    if request.path == "/" or request.path == "/favicon.ico" or "assets" in request.path or request.path=="/get_telemetry_client_key":
        return
    if openai.api_type != "azure_ad":
        return
    openai_token = current_app.config[CONFIG_OPENAI_TOKEN]
    if openai_token.expires_on < time.time() + 60:
        openai_token = await current_app.config[CONFIG_CREDENTIAL].get_token(
            "https://cognitiveservices.azure.com/.default"
        )
        current_app.config[CONFIG_OPENAI_TOKEN] = openai_token
        openai.api_key = openai_token.token
    if request.method == "OPTIONS":
        return
    try:
        token = get_token_auth_header()
        decode_token(token)
    except Exception as e:
        return jsonify({"message": str(e)}), 401
    
# Define a CORS middleware function
@bp.after_request
async def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "GET, PUT, POST, DELETE, HEAD, OPTIONS, PATCH"

    return response
# Error handler
class InvalidAuthorizationToken(Exception):
    def __init__(self, details):
        super().__init__('Invalid authorization token: ' + details)

def get_token_auth_header():
    """Obtains the Access Token from the Authorization Header
    """
    auth = request.headers.get("Authorization", None)
    if not auth:
        raise InvalidAuthorizationToken('Authorization header is expected')

    parts = auth.split()

    if parts[0].lower() != "bearer":
        raise InvalidAuthorizationToken('Authorization header must start with Bearer')
    elif len(parts) == 1:
        raise InvalidAuthorizationToken("Token not found")
    elif len(parts) > 2:
        raise InvalidAuthorizationToken("Authorization header must be Bearer token")

    token = parts[1]
    return token

def get_kid(token):
    headers = jwt.get_unverified_header(token)
    if not headers:
        raise InvalidAuthorizationToken('missing headers')
    try:
        return headers['kid']
    except KeyError:
        raise InvalidAuthorizationToken('missing kid')


def get_jwk(kid,jwks):
    for jwk in jwks.get('keys'):
        if jwk.get('kid') == kid:
            return jwk
    raise InvalidAuthorizationToken('kid not recognized')


def get_public_key(token):
    return rsa_pem_from_jwk(get_jwk(get_kid(token)))


def decode_token(token):
    """
    Decode a JWT token issued by Azure Active Directory.
    
    Parameters:
        token (str): The JWT token to decode.
        audience (str): The expected audience of the token. If provided, the token's audience will be verified against this value.
        issuer (str): The expected issuer of the token. If provided, the token's issuer will be verified against this value.
        verify (bool): Whether to perform signature verification. Defaults to True.
    
    Returns:
        dict: The decoded token payload as a dictionary.
    """
    try:
        client_id= os.getenv("AZURE_AUTH_CLIENT_ID")
        AZURE_TENANT_ID = os.getenv("AZURE_TENANT_ID")
        jwks_url = f"https://login.microsoftonline.com/{AZURE_TENANT_ID}/discovery/v2.0/keys"
        issuer_url = f"https://sts.windows.net/{AZURE_TENANT_ID}/"
        audience = f"api://{client_id}"

        jwks = json.loads(urlopen(jwks_url).read())
        unverified_header = jwt.get_unverified_header(token)
        rsa_key = get_jwk(unverified_header["kid"], jwks)
        public_key = rsa_pem_from_jwk(rsa_key)

        decode_token = jwt.decode(
        token,
        rsa_key,
        options={"verify_signature":True},
        algorithms=["RS256"],
        audience=audience,
        issuer=issuer_url
        )
        return decode_token
    except jwt.ExpiredSignatureError:
        raise InvalidAuthorizationToken("Token has expired.")
    except jwt.JWTError :
        raise InvalidAuthorizationToken("Invalid token.")
    except ValueError as ve:
        raise ve

@bp.before_app_serving
async def setup_clients():
    # Replace these with your own values, either in environment variables or directly here
    AZURE_STORAGE_ACCOUNT = os.environ["AZURE_STORAGE_ACCOUNT"]
    AZURE_STORAGE_CONTAINER = os.environ["AZURE_STORAGE_CONTAINER"]
    AZURE_SEARCH_SERVICE = os.environ["AZURE_SEARCH_SERVICE"]
    AZURE_SEARCH_INDEX = ""
    # Shared by all OpenAI deployments
    OPENAI_HOST = os.getenv("OPENAI_HOST", "azure")
    OPENAI_CHATGPT_MODEL = os.environ["AZURE_OPENAI_CHATGPT_MODEL"]
    OPENAI_EMB_MODEL = os.getenv(
        "AZURE_OPENAI_EMB_MODEL_NAME", "text-embedding-ada-002")
    # Used with Azure OpenAI deployments
    AZURE_OPENAI_SERVICE = os.getenv("AZURE_OPENAI_SERVICE")
    AZURE_OPENAI_CHATGPT_DEPLOYMENT = os.getenv(
        "AZURE_OPENAI_CHATGPT_DEPLOYMENT")
    AZURE_OPENAI_EMB_DEPLOYMENT = os.getenv("AZURE_OPENAI_EMB_DEPLOYMENT")
    # Used only with non-Azure OpenAI deployments
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    OPENAI_ORGANIZATION = os.getenv("OPENAI_ORGANIZATION")

    KB_FIELDS_CONTENT = os.getenv("KB_FIELDS_CONTENT", "content")
    KB_FIELDS_SOURCEPAGE = os.getenv("KB_FIELDS_SOURCEPAGE", "OriginalFileUrl")
    KB_FIELDS_SOURCEFILE = os.getenv("KB_FIELDS_SOURCEFILE", "sourcefile")
    AZURE_OPENAI_URI = os.getenv("AZURE_OPENAI_URI", "")
    AZURE_APIM_KEY = os.getenv("AZURE_APIM_KEY", "")
    if AZURE_OPENAI_URI == "":
        raise ValueError("AZURE_OPENAI_URI is blank. set this value in environment variable");
    
    
    azure_credential = DefaultAzureCredential(
        exclude_shared_token_cache_credential=True)
    search_clients = initialize_search_clients([])
    
    blob_client = BlobServiceClient(
        account_url=f"https://{AZURE_STORAGE_ACCOUNT}.blob.core.windows.net", credential=azure_credential
    )
    blob_container_client = blob_client.get_container_client(
        AZURE_STORAGE_CONTAINER)

    # Used by the OpenAI SDK
    if OPENAI_HOST == "azure":
        openai.api_type = "azure_ad"
        openai.api_base = f"{AZURE_OPENAI_URI}"
        openai.api_version = "2023-05-15"
        openai_token = await azure_credential.get_token("https://cognitiveservices.azure.com/.default")
        openai.api_key = openai_token.token
        client = AsyncAzureOpenAI(
        azure_endpoint= f"{AZURE_OPENAI_URI}",
        api_key=AZURE_APIM_KEY, 
        api_version="2023-12-01-preview"
        )
        # Store on app.config for later use inside requests
        current_app.config[CONFIG_OPENAI_TOKEN] = openai_token
        current_app.config['client'] = client
    else:
        openai.api_type = "openai"
        openai.api_key = OPENAI_API_KEY
        openai.organization = OPENAI_ORGANIZATION

    current_app.config[CONFIG_CREDENTIAL] = azure_credential
    current_app.config[CONFIG_BLOB_CONTAINER_CLIENT] = blob_container_client

    # Various approaches to integrate GPT and external knowledge, most applications will use a single one of these patterns
    # or some derivative, here we include several for exploration purposes
    current_app.config[CONFIG_ASK_APPROACHES] = {
        "rtr": RetrieveThenReadApproach(
            search_clients,
            OPENAI_HOST,
            AZURE_OPENAI_CHATGPT_DEPLOYMENT,
            OPENAI_CHATGPT_MODEL,
            AZURE_OPENAI_EMB_DEPLOYMENT,
            OPENAI_EMB_MODEL,
            KB_FIELDS_SOURCEPAGE,
            KB_FIELDS_CONTENT,
            KB_FIELDS_SOURCEFILE,
        ),
    }
    current_app.config[CONFIG_CHAT_APPROACHES] = {
        "rrr": ChatReadRetrieveReadApproach(
            search_clients,
            OPENAI_HOST,
            AZURE_OPENAI_CHATGPT_DEPLOYMENT,
            OPENAI_CHATGPT_MODEL,
            AZURE_OPENAI_EMB_DEPLOYMENT,
            OPENAI_EMB_MODEL,
            KB_FIELDS_SOURCEPAGE,
            KB_FIELDS_CONTENT,
            KB_FIELDS_SOURCEFILE,
            current_app.config['client']
        )
    }

def create_app():
    if os.getenv("APPLICATIONINSIGHTS_CONNECTION_STRING"):
        configure_azure_monitor()
        AioHttpClientInstrumentor().instrument()
    app = Quart(__name__)
    # app = cors(app)
    app.register_blueprint(bp)
    app.asgi_app = OpenTelemetryMiddleware(app.asgi_app)
    # Level should be one of https://docs.python.org/3/library/logging.html#logging-levels
    logging.basicConfig(level=os.getenv("APP_LOG_LEVEL", "ERROR"))
    return app
# praveen here
