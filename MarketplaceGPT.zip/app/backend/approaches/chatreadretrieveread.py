from typing import Any, AsyncGenerator

import openai
import asyncio
import random
import re
import time
from datetime import datetime
from azure.search.documents.aio import SearchClient
from azure.core.pipeline.policies import RetryPolicy, RetryMode 
from azure.search.documents.models import QueryType
from azure.core.exceptions import HttpResponseError

from core.messagebuilder import MessageBuilder
from core.modelhelper import get_token_limit
from text import nonewlines

from models import telemetry_client_key
from azure.monitor.opentelemetry.exporter import AzureMonitorTraceExporter
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from applicationinsights import TelemetryClient

# import logging
from openai import AzureOpenAI
import httpx

# # logging.basicConfig(level=logging.DEBUG)

import asyncio
from typing import List, Dict, Any

class SearchManager:
    def __init__(self, search_clients: List[SearchClient], openai_host: str, chatgpt_deployment: str, chatgpt_model: str, embedding_deployment: str, embedding_model: str, sourcepage_field: str, content_field: str):
        # Assuming search_clients is a list of SearchClient instances, each configured for a different index
        self.search_clients = search_clients
        self.openai_host = openai_host
        self.chatgpt_deployment = chatgpt_deployment
        self.chatgpt_model = chatgpt_model
        self.embedding_deployment = embedding_deployment
        self.embedding_model = embedding_model
        self.sourcepage_field = sourcepage_field
        self.content_field = content_field
        self.chatgpt_token_limit = get_token_limit(chatgpt_model)

    # Define retry parameters  
    retries = 3  
    backoff_factor = 1  
    max_backoff = 120
    async def search_index(self, client: SearchClient, query_text: str, filter: str, top: int, query_vector: Any, use_semantic_captions: bool) -> List[str]:
        if use_semantic_captions:
            results = [
                doc[self.sourcepage_field] + ": " + nonewlines(" . ".join([c.text for c in doc["@search.captions"]]))
                async for doc in client.search(
                    query_text,
                    filter=filter,
                    query_type=QueryType.SEMANTIC,
                    query_language="en-us",
                    query_speller="lexicon",
                    semantic_configuration_name="default",
                    top=top,
                    query_caption="extractive|highlight-false" if use_semantic_captions else None,
                    vector=query_vector,
                    top_k=50 if query_vector else None,
                    vector_fields="embedding" if query_vector else None,
                )
            ]
        else:
            results = [doc[self.sourcepage_field] + ": " + nonewlines(doc[self.content_field]) async for doc in client.search(
                query_text,
                filter=filter,
                top=top,
                vector=query_vector,
                top_k=50 if query_vector else None,
                vector_fields="embedding" if query_vector else None,
            )]
        return results


class ChatReadRetrieveReadApproach:
    # Chat roles
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"

    """
    Simple retrieve-then-read implementation, using the Cognitive Search and OpenAI APIs directly. It first retrieves
    top documents from search, then constructs a prompt with them, and then uses OpenAI to generate an completion
    (answer) with that prompt.
    """
    system_message_chat_conversation = """Assistant helps answer user questions. Be brief in your answers.
Answer ONLY with the facts listed in the list of sources below. If there isn't enough information below, say you don't know. Do not generate answers that don't use the sources below. If asking a clarifying question to the user would help, ask the question.
For tabular information return it as an html table. Do not return markdown format. If the question is not in English, answer in the language used in the question.
Each source has a name followed by colon and the actual information, always include the source file and source page for each fact you use in the response. Source file should be linked with the Source Page from your return. Use square brackets to reference the source, e.g. [info1.txt]. Don't combine sources, list each source separately, e.g. [info1.txt][info2.pdf]
{follow_up_questions_prompt}
{injected_prompt}
Follow below validation:
- Do not use expressions like 'According to the source', example:'According to the [info.txt]'
- Do not start answer with 'According to the [source_name]', example:'According to the [info.txt]'
"""
    follow_up_questions_prompt_content = """Generate three very brief follow-up questions that the user would likely ask next.
Use double angle brackets to reference the questions, e.g. <<Are there exclusions for prescriptions?>>.
Try not to repeat questions that have already been asked.
Only generate questions and do not generate any text before or after the questions, such as 'Next Questions'"""

    query_prompt_template = """Below is a history of the conversation so far, and a new question asked by the user that needs to be answered by searching in the knowledge base.
Generate a search query based on the conversation and the new question.
Do not include cited source filenames and document names e.g info.txt or doc.pdf in the search query terms.
Do not include any text inside [] or <<>> in the search query terms.
Do not include any special characters like '+'.
If the question is not in English, translate the question to English before generating the search query.
If you cannot generate a search query, return just the number 0.
"""
    keyword_prompt_template = """Explore the information available on the given topic and generate a concise question that aligns with the content.
    Ensure the question maintains relevance to the source material, allowing for variations in sources while staying consistent with the initial topic or inquiry.
    Question should be concise and short.
    - Follow Below Validtion:
    - Do not include the source content as it is.
    - Do not start the question which matches the below array [ {target_responses_with_below_text} ]
    - Do not start the question with 'Based on the provided sources, '.
    - Do not include sources at the end of the generated question.
    If unable to generate a question meeting the above criteria, return an empty string.
    """
    
    query_prompt_few_shots = [

    ]
    target_responses_with_below_text = [
        "There is not enough information",
        "There is no information",
        "I'm sorry, but the sources provided",
        "I'm sorry, but the provided sources do not contain any information",
        "I'm sorry, I am not able to understand the question",
        "I'm sorry, I cannot determine",
        "I apologize for the confusion",
        "Please provide more context or additional sources to better assist you.",
        "Based on the sources provided, I couldn't find any specific definition",
        "Unfortunately, without more context",
        "Without additional context, it is difficult",
        "I'm sorry, but I cannot answer this question"
    ]
    timeout = httpx.Timeout(connect=60,read=180,write=120,pool=180)

    def __init__(
        self,
        search_clients: List[SearchClient],
        openai_host: str,
        chatgpt_deployment: str,
        chatgpt_model: str,
        embedding_deployment: str,
        embedding_model: str,
        sourcepage_field: str,
        content_field: str,
        sourcefile_field: str,

        openAiclient: AzureOpenAI
    ):
        self.search_clients = search_clients
        self.openai_host = openai_host
        self.chatgpt_deployment = chatgpt_deployment
        self.chatgpt_model = chatgpt_model
        self.embedding_deployment = embedding_deployment
        self.embedding_model = embedding_model
        self.sourcepage_field = sourcepage_field
        self.content_field = content_field
        self.sourcefile_field = sourcefile_field
        self.chatgpt_token_limit = get_token_limit(chatgpt_model)
        self.openAiclient = openAiclient
    
    async def get_chat_completion_with_retry(self, messages, temperature, max_tokens, n, deployment_id):  
        retries = 3  # Maximum number of retries  
        backoff = 1  # Initial backoff interval in seconds  
    
        for i in range(retries):  
            try:  
                # Attempt the API call  
                chat_completion = await self.openAiclient.chat.completions.create(  
                    model=deployment_id,  
                    messages=messages,  
                    temperature=temperature,  
                    max_tokens=max_tokens,
                    n=n,
                    seed=42,
                    timeout=self.timeout  
                )  
                return chat_completion  
            except Exception as e:  # Replace with a more specific exception if possible  
                if i < retries - 1:  
                    # If not on the last retry, wait for a bit before retrying  
                    sleep_time = backoff * (2 ** i)  # Exponential backoff  
                    sleep_time += random.uniform(0, 0.1 * backoff)  # Adding jitter  
                    await asyncio.sleep(sleep_time)  
                else:  
                    # If on the last retry, log and re-raise the exception  
                    print(f"Failed to get chat completion after {retries} attempts: {e}")  
                    raise

    async def get_embedding_with_retry(self, input_text, deployment_id):  
        retries = 3  # Maximum number of retries  
        backoff = 1  # Initial backoff interval in seconds  
  
        for i in range(retries):  
            try:  
                # Attempt the API call  
                embedding = await self.openAiclient.embeddings.create(  
                    model=deployment_id,  
                    input=input_text,
                    timeout=self.timeout
                )  
                return embedding  
            except Exception as e:  # Replace with a more specific exception if possible  
                if i < retries - 1:  
                    # If not on the last retry, wait for a bit before retrying  
                    sleep_time = backoff * (2 ** i)  # Exponential backoff  
                    sleep_time += random.uniform(0, 0.1 * backoff)  # Adding jitter  
                    await asyncio.sleep(sleep_time)  
                else:  
                    # If on the last retry, log and re-raise the exception  
                    print(f"Failed to get embedding after {retries} attempts: {e}")  
                    raise
    
    async def run_until_final_call(
        self, history: list[dict[str, str]], overrides: dict[str, Any], search_clients: List[SearchClient], should_stream: bool = False
    ) -> tuple:
        # # logging.info("Processing Query variables...........")
        has_text = overrides.get("retrieval_mode") in ["text", "hybrid", None]
        #if has_text: #print("has_text is true")
        has_vector = overrides.get("retrieval_mode") in ["vectors", "hybrid", None]
        #if has_vector: #print("has_vector is true")
        use_semantic_captions = True if overrides.get("semantic_captions") and has_text else False
        #if use_semantic_captions: #print("use_semantic_captions is true");
        top = overrides.get("top") or 3
        #print("top is " + str(top))
        exclude_category = overrides.get("exclude_category") or None
        filter = "category ne '{}'".format(exclude_category.replace("'", "''")) if exclude_category else None
        #print("filter is" + str(filter))
        # here we have the user's question
        chatgpt_args = {"deployment_id": self.chatgpt_deployment} if self.openai_host == "azure" else {}
        semantic_ranker = True if overrides.get("semantic_ranker")!= None and overrides.get("semantic_ranker")==True  else False


        user_q = "Summarize Above conversation question and answer"
        query_text = history[-1]["user"]
        print('the search client in the approach', search_clients)
        if len(history)>1:
            # user_q = "Generate search query for following question: " + "\n" + history[-1]["user"]
            # STEP 1: Generate an optimized keyword search query based on the chat history and the last question
            messages = self.get_messages_from_history(
                self.query_prompt_template,
                self.chatgpt_model,
                history,
                user_q,
                self.query_prompt_few_shots,
                self.chatgpt_token_limit - len(user_q),
            )

            chat_completion = await self.get_chat_completion_with_retry(
                messages=messages,  
                temperature=0.7,  
                max_tokens=100,  
                n=1,  
                deployment_id=self.chatgpt_deployment
            )
            
            query_text = query_text + "\n" + chat_completion.choices[0].message.content
        
        
        # Use the last user input and summay of previous question
        # query_text = history[-1]["user"] + "\n" +chat_completion.choices[0].message.content 
        # print("............query_text (Previous history + user question) is........\n" + query_text)

        # STEP 2: Retrieve relevant documents from the search index with the GPT optimized query
        # If retrieval mode includes vectors, compute an embedding for the query
        if has_vector:
            embedding_args = {"deployment_id": self.embedding_deployment} if self.openai_host == "azure" else {}
            embedding = await self.get_embedding_with_retry(  
                input_text=query_text,  
                deployment_id=self.embedding_deployment,  
            )
            query_vector = embedding.data[0].embedding
            #print("query_vector is \n")
            #print(query_vector)
        else:
            query_vector = None

        # Only keep the text query if the retrieval mode uses text, otherwise drop it
        if not has_text:
            query_text = None

        
        # Telemetry Client Key
        telemetry_client = TelemetryClient(telemetry_client_key)
        docs = []
        # MIN_SCORE_THRESHOLD = 1.0
        # Perform searches across all indexes
        search_tasks = [
            self.perform_search_on_index(client, query_text, filter, top, query_vector, use_semantic_captions,has_text,semantic_ranker)
            for client in search_clients
        ]
        search_results = await asyncio.gather(*search_tasks)

        # Interleaving results from different indexes
        interleaved_results = self.interleave_search_results(search_results, top)

        sorted_results = sorted(interleaved_results, key=lambda x: (x['@search.score']), reverse=True)
        top_results = sorted_results[:top]
        r = None
        # Use semantic L2 reranker if requested and if retrieval mode is text or hybrid (vectors + text)
        # if overrides.get("semantic_ranker") and has_text:
        #     print("............semantic search user question query text..............")
        #     r = await self.search_client.search(
        #        query_text,
        #         filter=filter,
        #         query_type=QueryType.SEMANTIC,
        #         query_language="en-us",
        #         query_speller="lexicon",
        #         semantic_configuration_name="default",
        #         top=top,
        #         query_caption="extractive|highlight-false" if use_semantic_captions else None,
        #         vector=query_vector,
        #         top_k=50 if query_vector else None,
        #         vector_fields="embedding" if query_vector else None,
        #     )
        # else:
        #     print("............direct search user question query text..............")
        #     r = await self.search_client.search(
        #         query_text,
        #         filter=filter,
        #         top=top,
        #         vector=query_vector,
        #         top_k=50 if query_vector else None,
        #         vector_fields="embedding" if query_vector else None,
        #     )
        
        # if use_semantic_captions:
        #     results = [
        #         doc[self.sourcepage_field] + ": " + nonewlines(" . ".join([c.text for c in doc["@search.captions"]]))
        #         async for doc in r
        #     ]
        #     print("use_semantic_captions\n")
        
        # else:
        results = []
        now = datetime.now()
        dt_string = now.isoformat()
        doc_read_start_time = time.perf_counter()
        for doc in top_results:
                source_page = doc.get(self.sourcepage_field, 'None')  # Replace 'None' with a default value if needed
                content = nonewlines(doc.get(self.content_field, 'None'))  # Replace 'None' with a default value if needed
                source_file = nonewlines(doc.get(self.sourcefile_field, 'None'))
                search_score = doc.get("@search.score", 0)
                reranker_score = doc.get("@search.reranker_score", 0)

                doc_item = {
                    "content": content,
                    "source_page": source_page,
                    "source_file":source_file,
                    "search_score": search_score,
                    "reranker_score": reranker_score,
                    "Created_date": dt_string
                }
                docs.append(doc_item)

                results.append(f"{source_file}~ {source_page}~ {content}")

           # Printing the results
        print("..........................Not Use_semantic_captions Results:\n")
        # top_results_to_print = 3
        # print("\nTop 3 Results:")
        # for i, result in enumerate(results):
        #     if i < top_results_to_print:
        #         print(f"Result {i+1}: {result}")
        #     else:
        #         break
        # for element in results:
        #     print(element)
        doc_read_end_time = time.perf_counter()  # End timer for reading documents
        doc_processing_duration = (doc_read_end_time - doc_read_start_time)
        print("DOCUMENT DURATION *******", doc_processing_duration)
        telemetry_client.track_event('DocumentProcessing', {'Operation': 'process_documents'}, {'Duration': doc_processing_duration})
        telemetry_client.flush()  

        content = "\n".join(results)
        #print("..............searched contents are \n" + content)
        follow_up_questions_prompt = (
            self.follow_up_questions_prompt_content if overrides.get("suggest_followup_questions") else ""
        )

        # STEP 3: Generate a contextual and content specific answer using the search results and chat history

        # Allow client to replace the entire prompt, or to inject into the exiting prompt using >>>
        prompt_override = overrides.get("prompt_template")
        if prompt_override is None:
            system_message = self.system_message_chat_conversation.format(
                injected_prompt="", follow_up_questions_prompt=follow_up_questions_prompt
            )
            #print("prompt_override is none and system_message is \n"+system_message)
        elif prompt_override.startswith(">>>"):
            system_message = self.system_message_chat_conversation.format(
                injected_prompt=prompt_override[3:] + "\n", follow_up_questions_prompt=follow_up_questions_prompt
            )
            #print("prompt_override startswith >>> and system_message is \n"+system_message)
        else:
            system_message = prompt_override.format(follow_up_questions_prompt=follow_up_questions_prompt)
            #print("system_message is \n"+system_message)

        messages = self.get_messages_from_history(
            system_message,
            self.chatgpt_model,
            history,
            # Model does not handle lengthy system messages well.
            # Moved sources to latest user conversation to solve follow up questions prompt.
            history[-1]["user"] + "\n\nSources:\n" + content,
            max_tokens=self.chatgpt_token_limit,
        )
        msg_to_display = "\n\n".join([str(message) for message in messages])
        #print("msg_to_display is \n" + msg_to_display)

        extra_info = {
            "data_points": results,
            "thoughts": f"Searched for:<br>{query_text}<br><br>Conversations:<br>"
            + msg_to_display.replace("\n", "<br>"),
        }
        #print("extra_info is \n")
        #print(extra_info)
        chat_coroutine = self.openAiclient.chat.completions.create(
            model=self.chatgpt_deployment,
            messages=messages,
            temperature=overrides.get("temperature") or 0.1,
            max_tokens=1024,
            n=1,
            stream=should_stream,
            seed=42,
            timeout=self.timeout
        )

        # print(extra_info)
        # print("..................extra info above and chat response below")    

        print("Docs to be returned from run_until_final_call:", docs)
        return (extra_info, chat_coroutine, docs)

    
    async def perform_search_on_index(self, client:SearchClient, query_text, filter, top, query_vector, use_semantic_captions,has_text,semantic_ranker):
        search_options = {
            "top": top,
            "filter": filter,
        }
         # Use semantic L2 reranker if requested and if retrieval mode is text or hybrid (vectors + text)
        if semantic_ranker and has_text:
            print("............semantic search user question query text..............")
            search_options = {
                "top": top,
                "filter": filter,
                "query_type": QueryType.SEMANTIC,
                "query_language": "en-us",
                "query_speller": "lexicon",
                "semantic_configuration_name": "default",
                "query_caption": "extractive|highlight-false" if use_semantic_captions else None,
                "vector": query_vector,
                "top_k": 50 if query_vector else None,
                "vector_fields": "embedding" if query_vector else None,
            }
        else:
            print("............direct search user question query text..............")
            search_options = {
                "top": top,
                "filter": filter,
                "vector": query_vector,
                "top_k": 50 if query_vector else None,
                "vector_fields": "embedding" if query_vector else None,
            }
           
        
        # Initiate the search
        async_paged_results = await client.search(search_text=query_text, **search_options)
        
        # Collect results asynchronously
        collected_results = []
        async for result in async_paged_results:
            # Depending on your requirements, you might want to extract specific fields from each result
            collected_results.append(result)

        return collected_results

    async def run_without_streaming(self, history: list[dict[str, str]], overrides: dict[str, Any], search_clients: list) -> dict[str, Any]:
        extra_info, chat_coroutine, docs = await self.run_until_final_call(history, overrides, search_clients, should_stream=False)
        chat_content = (await chat_coroutine).choices[0].message.content
        extra_info["answer"] = chat_content
        extra_info["docs"] = docs
        print("............run without stream answer \n"+ chat_content)
        return extra_info

    async def run_with_streaming(
        self, history: list[dict[str, str]], overrides: dict[str, Any], search_clients: list
    ) -> AsyncGenerator[dict, None]:
        extra_info, chat_coroutine, docs = await self.run_until_final_call(history, overrides, search_clients, should_stream=True)
        yield extra_info
        # print("extra_info********", extra_info)
        async for event in await chat_coroutine:
            yield event
        print("Docs to be yielded from run_with_streaming:", docs)
        yield docs
        print("run with streaming answer is \n")

    def get_messages_from_history(
        self,
        system_prompt: str,
        model_id: str,
        history: list[dict[str, str]],
        user_conv: str,
        few_shots=[],
        max_tokens: int = 4096,
    ) -> list:
        message_builder = MessageBuilder(system_prompt, model_id)

        # Add examples to show the chat what responses we want.
        # It will try to mimic any responses and make sure they match the rules laid out in the system message.
        for shot in few_shots:
            message_builder.append_message(shot.get("role"), shot.get("content"))

        user_content = user_conv
        append_index = len(few_shots) + 1

        message_builder.append_message(self.USER, user_content, index=append_index)

        for h in reversed(history[:-1]):
            if bot_msg := h.get("bot"):
                message_builder.append_message(self.ASSISTANT, bot_msg, index=append_index)
            if user_msg := h.get("user"):
                message_builder.append_message(self.USER, user_msg, index=append_index)
            if message_builder.token_length > max_tokens:
                break

        messages = message_builder.messages
        #print(".............message history is \n" )
        #print(messages)
        return messages
    
    def interleave_search_results(self, search_results: List[List[Any]], top: int) -> List[Any]:
        """
        Interleaves search results from multiple indexes.
        
        Parameters:
        - search_results: A list of lists, where each sublist contains results from a different index.
        - top: The number of top results to consider from each index.

        Returns:
        - A list of interleaved results.
        """
        interleaved = []
        for i in range(top):
            for results in search_results:
                if i < len(results):
                    interleaved.append(results[i])
        return interleaved
    
    async def analyse_question_response(self,
        response_anaylysis_text: str) ->str:
        # response analysis
        
        response_analysis_prompt = """
        Evaluate the provided content and respond with 'yes' if it suggests uncertainty or a lack of knowledge;
          otherwise, respond with 'no'. Do not include '.' in your response. Additionally, consider the following array of 
          statements and treat them as instances of uncertainty: [ """ + "\n".join(self.target_responses_with_below_text) + "]"
        
        response_analysis_messages = self.get_messages_from_history(
            response_analysis_prompt,
            self.chatgpt_model,
            [],
            response_anaylysis_text,
            [],
            self.chatgpt_token_limit - len(response_anaylysis_text),
        )
        
        response_analysis = await self.openAiclient.chat.completions.create(
            model=self.chatgpt_deployment,
            messages=response_analysis_messages,
            temperature=0.1,
            max_tokens=10,
            n=1,
            seed=42 ,
            timeout=self.timeout
        )
        response_analysis_ans = response_analysis.choices[0].message.content
        return response_analysis_ans.rstrip('.') if response_analysis_ans.endswith('.') else response_analysis_ans
    
    async def generate_new_prompt_from_datapoint(self,request_json) -> str:
        #print("----reask----")
        answer = request_json["parsedResponse"]["answer"]
        content = request_json["parsedResponse"]["data_points"]
        response_analysis_ans =  await self.analyse_question_response(answer)
        user_ques = request_json["question"]
        print('---response_analysis_ans result----')
        print(response_analysis_ans)
        if(response_analysis_ans.lower()=='yes'):
            formattedPrompt = self.keyword_prompt_template.format(
                target_responses_with_below_text="\n".join(self.target_responses_with_below_text)
            )
            messages = self.get_messages_from_history(
                formattedPrompt,
                self.chatgpt_model,
                request_json["request"]["history"],
                "Question\n"+user_ques + "\n\nSources:\n" + "\n".join(content),
                max_tokens=self.chatgpt_token_limit,
            )
            response = await self.openAiclient.chat.completions.create(
                model=self.chatgpt_deployment,
                messages=messages,
                temperature=0.1,
                max_tokens=1024,
                n=1,
                stream=False,
                seed=42,
                timeout=self.timeout
            ) 
            new_question = response.choices[0].message.content
            return new_question
        return ""
    
    related_question_prompt_template = """Explore the information available on the given topic and generate 2 concise questions that align with the content.  
    Ensure the questions maintain relevance to the source material, allowing for variations in sources while staying consistent with the initial topic or inquiry.  
    Questions should be concise, short, and presented as a seamless list without explicit identifiers such as "Question", or numerical prefixes.
    - Follow Below Validation:  
    - Do not include the source content as it is.  
    - Do not start the question with 'Based on the provided sources, '.  
    - Do not include sources at the end of the generated questions.  
    - Avoid explicit question identifiers in the presentation of the questions.
    If unable to generate questions meeting the above criteria, return an empty list.  
    """  

    async def generate_related_questions(self, request_json) -> tuple:
        try:  
            content = request_json["parsedResponse"]["data_points"]  
        except KeyError as e:  
            # Return a more informative error message  
            return ({"error": f"Missing key in request JSON: {str(e)}"}), 400
        
        user_ques = request_json["question"]  
        formattedPrompt = self.related_question_prompt_template.format()
        invalid_responses = [  
        "Apologies, I couldn't find any questions in the provided information.",  
        ]
        messages = self.get_messages_from_history(  
            formattedPrompt,  
            self.chatgpt_model,  
            request_json["history"],  
            "Question\n"+user_ques + "\n\nSources:\n" + "\n".join(content),  
            max_tokens=self.chatgpt_token_limit,  
        )            
        response = await self.openAiclient.chat.completions.create(  
            model=self.chatgpt_deployment,  
            messages=messages,  
            temperature=0.5,  
            max_tokens=1024,  
            n=2,  
            stream=False,  
        )   
        generated_text = response.choices[0].message.content  
        potential_questions = [q.strip() for q in generated_text.split('?') if q.strip()]  

        # Remove question 1: and Question 2: from each question
        cleaned_questions = []
        for question in potential_questions[:2]:
            cleaned_question = re.sub(r'Question \d+: ', '', question)  # Remove the prefixes using regex  
            cleaned_questions.append(cleaned_question)  
    
        new_questions = cleaned_questions
        # new_questions = potential_questions[:2] 
        while len(new_questions) < 2:
            new_questions.append(new_questions[0])  
        print('new_questions', new_questions) 

        new_questions = [q for q in cleaned_questions if q not in invalid_responses]
        if not new_questions or all(q == '' for q in new_questions):
            return []
        
        keywords = []  
        for question in new_questions:
            if question:
                messages = [
                {"role": "system", "content": """
                For the following question, extract the main topic of the question. The topic should be a concise phrase that captures the essence of the question, ideally 2-3 words long.   
                Avoid common nouns and punctuation. If the question contains acronyms, consider them as potential topics. If there are no acronyms, identify the most specific noun or noun phrase that represents the main focus of the question.   
                Provide only one topic for the question and ensure it is no longer than 3 words.   
                For example, for the question 'How can I get support for this metric?', the topic would be 'metric support'.   
                For the question 'How do I view MBS actuals in MINT?', the topic would be 'MBS actuals'. """},
                {"role": "user", "content": question}
                ]          
                response = await self.openAiclient.chat.completions.create(  
                    model=self.chatgpt_deployment,  
                    messages=messages,  
                    temperature=0.3,  
                    max_tokens=1024,  
                    n=1,  
                    stream=False,  
                )  
                generated_text = response.choices[0].message.content.strip()  
                keywords.append(generated_text)  

        # Filter out any questions or keywords containing "Empty List"
        filtered_response = [pair for pair in zip(cleaned_questions, keywords) if "Empty List" not in pair[0]]

        # Pair each filtered question with its corresponding keyword
        formatted_response = [{"question": question, "keyword": keyword} for question, keyword in filtered_response] 
             
        return formatted_response 
