def nonewlines(s: str) -> str:
    if s is None:
        return ''
    return s.replace("\n", " ").replace("\r", " ")
