import pymongo
from pymongo import MongoClient
from datetime import datetime
import os
from azure.storage.blob.aio import BlobServiceClient
from azure.storage.blob import BlobServiceClient
from azure.identity import ManagedIdentityCredential, AzureCliCredential
from azure.keyvault.secrets import SecretClient

# Initialize the Key Vault client
vault_url = "https://mdea-openai-devkv.vault.azure.net/"

#Change to ManagedIdentityCredential to before deploying.
devenv = os.getenv("devEnv","")
credential = AzureCliCredential() if devenv=="local" else ManagedIdentityCredential()
secret_client = SecretClient(vault_url=vault_url, credential=credential)

# Retrieve Cosmos DB credentials from Azure Key Vault
cosmos_db_url = "mongodb://cosmodbformongodbdev.mongo.cosmos.azure.com:10255/?ssl=true&replicaSet=globaldb&retrywrites=false"
cosmos_db_username = secret_client.get_secret("db-dev-username-secret-name").value
cosmos_db_password = secret_client.get_secret("db-dev-password-secret-name").value
telemetry_client_endpoint = os.getenv("AZURE_APPINSIGHT_KEY","")
telemetry_client_key = telemetry_client_endpoint.split(";")[0].split("=")[1] if telemetry_client_endpoint!="" else ""
database_name = "mongoDB-openapi-dev-DB"

connection_string = BlobServiceClient(account_url="https://strgdevmarketplacegpt.blob.core.windows.net", credential=credential)
# Retrieve Storage dev marketplacegpt Connection Str
# connection_string = secret_client.get_secret("strgdevmarketplacegpt-connection-str").value

# Create a connection to Azure Cosmos DB
client = MongoClient(cosmos_db_url)

# Authenticate to the database
client = MongoClient(cosmos_db_url, username=cosmos_db_username, password=cosmos_db_password)

# Access a specific collection within the database
db = client[database_name]

collection = db["HistoryItemDetails"]
doc_collection = db["DocumentDetails"]

history_collection = db["ResponseHistoryCollection"]

def storeHistory(user_question, bot_response, history_item_id, user_id, field_value):
    """Inserts chat stream details into the MongoDB collection."""
    now = datetime.now()
    dt_string = now.isoformat()
    document = {
        "history_item_id": history_item_id,
        "user_id": user_id,
        "title": user_question,
        "created": dt_string,
        "updated": dt_string,
        "user": user_question,
        "original_response":"",
        "bot": bot_response,
        "response_upvote_button": "NOVOTE",
        "response_vote_feedback": "",
        "security_group": field_value,
        "notes": "",
        "state": "Active",
        "favorites": [],
        "new_answer_av": "False",
        "new_answer":"",
        "new_answer_date":""
    }
    collection.insert_one(document)


def chat_stream_docs(history_item_id, docs):
    """Inserts document details into the MongoDB collection."""
    for doc in docs:
        doc["Document_info"] = "Chat_stream"

    document_entry = {
        "history_item_id": history_item_id,
        "documents": docs
    }
    doc_collection.insert_one(document_entry)


def reg_resp_docs(history_item_id, docs):
    """Updates existing document details in the MongoDB collection."""
    for doc in docs:
        doc["Document_info"] = "Re-generate"
        doc["status"] = "updated"
    
    doc_collection.update_one(
        {"history_item_id": history_item_id},
        {"$push": {"documents": {"$each": docs}}}
    )